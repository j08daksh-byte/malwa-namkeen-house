/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        background: '#08141A', nav: '#0B1921', card: '#122832', elevated: '#18333E',
        'code-surface': '#0A1820', border: '#244550', primary: '#FF6846', secondary: '#35D0BA',
        tertiary: '#F6C453', error: '#FF526D', success: '#39D98A',
        'text-primary': '#F4F7F8', 'text-body': '#C4D0D4', 'text-secondary': '#91A7AF'
      },
      fontFamily: { sans: ['Manrope','sans-serif'], mono: ['JetBrains Mono','monospace'] },
      fontSize: {
        'headline-lg': ['2rem',{lineHeight:'2.5rem',fontWeight:'700'}],
        'headline-md': ['1.5rem',{lineHeight:'2rem',fontWeight:'600'}],
        'headline-sm': ['1.25rem',{lineHeight:'1.75rem',fontWeight:'600'}],
        'body-lg': ['1rem',{lineHeight:'1.5rem'}], 'body-md': ['0.875rem',{lineHeight:'1.25rem'}],
        'body-sm': ['0.75rem',{lineHeight:'1rem'}], 'code-lg': ['1rem',{lineHeight:'1.5rem'}],
        'code-md': ['0.875rem',{lineHeight:'1.25rem'}], 'code-sm': ['0.75rem',{lineHeight:'1rem'}],
        'label-caps': ['0.75rem',{lineHeight:'1rem',fontWeight:'600'}]
      },
      spacing: { xs:'0.25rem', sm:'0.5rem', md:'1rem', lg:'1.5rem', xl:'2rem', touch:'2.75rem' },
      minHeight: { touch:'2.75rem' }
    }
  },
  plugins: []
};
