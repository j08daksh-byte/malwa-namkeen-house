/**
 * IconButton — 44×44 touch target (WCAG 2.5.5), rounded variants.
 * Pass an aria-label on every usage.
 *
 * shape: 'square' (rounded-md) | 'circle' (rounded-full)
 * size:  'sm' (32px) | 'md' (44px, default) | 'lg' (56px)
 */

const SIZE = {
  sm: 'w-8  h-8  min-w-[32px]  min-h-[32px]',
  md: 'w-11 h-11 min-w-[44px]  min-h-[44px]',
  lg: 'w-14 h-14 min-w-[56px]  min-h-[56px]',
};

const SHAPE = {
  square:  'rounded-md',
  circle:  'rounded-full',
};

export default function IconButton({
  shape = 'square',
  size = 'md',
  active = false,
  disabled = false,
  className = '',
  children,
  ...props
}) {
  return (
    <button
      disabled={disabled}
      className={[
        'inline-flex items-center justify-center shrink-0',
        'text-text-body border border-transparent',
        'transition-all duration-150 select-none',
        'hover:bg-elevated hover:text-text-primary',
        'active:scale-90',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background',
        'disabled:opacity-40 disabled:pointer-events-none',
        active && 'text-primary',
        SIZE[size],
        SHAPE[shape],
        className,
      ]
        .filter(Boolean)
        .join(' ')}
      {...props}
    >
      {children}
    </button>
  );
}
