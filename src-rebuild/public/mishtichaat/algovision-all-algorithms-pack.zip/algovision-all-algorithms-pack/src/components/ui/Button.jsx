/**
 * Button — three variants:
 *   primary  — coral fill (#FF6846), dark text
 *   secondary — transparent, coral border + text
 *   ghost    — no border, muted text; used for low-emphasis actions
 *
 * Sizes: sm | md (default) | lg
 */

const SIZE = {
  sm: 'h-8  px-sm  text-body-md',
  md: 'h-11 px-md  text-body-md',
  lg: 'h-14 px-lg  text-body-lg',
};

const VARIANT = {
  primary:
    'bg-primary text-background border-transparent ' +
    'hover:brightness-110 active:scale-95 ' +
    'disabled:opacity-40 disabled:pointer-events-none',
  secondary:
    'bg-transparent text-primary border border-primary ' +
    'hover:bg-primary/10 active:scale-95 ' +
    'disabled:opacity-40 disabled:pointer-events-none',
  ghost:
    'bg-transparent text-text-body border-transparent ' +
    'hover:bg-elevated active:scale-95 ' +
    'disabled:opacity-40 disabled:pointer-events-none',
};

export default function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  className = '',
  children,
  ...props
}) {
  return (
    <button
      disabled={disabled}
      className={[
        'inline-flex items-center justify-center gap-2 rounded font-semibold',
        'transition-all duration-150 select-none',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background',
        SIZE[size],
        VARIANT[variant],
        className,
      ].join(' ')}
      {...props}
    >
      {children}
    </button>
  );
}
