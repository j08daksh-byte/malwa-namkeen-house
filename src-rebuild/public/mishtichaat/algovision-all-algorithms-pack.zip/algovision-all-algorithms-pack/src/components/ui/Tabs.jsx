import { createContext, useContext, useState } from 'react';

/**
 * Tabs — compound component.
 *
 * Usage:
 *   <Tabs defaultTab="code">
 *     <TabList>
 *       <Tab id="visualizer" icon={<BarChart2 size={18} />}>Visualizer</Tab>
 *       <Tab id="code"       icon={<Code2 size={18} />}>Code</Tab>
 *       <Tab id="complexity" icon={<Info size={18} />}>Complexity</Tab>
 *     </TabList>
 *     <TabPanel id="visualizer">…</TabPanel>
 *     <TabPanel id="code">…</TabPanel>
 *     <TabPanel id="complexity">…</TabPanel>
 *   </Tabs>
 */

const TabCtx = createContext(null);

export function Tabs({ defaultTab, children, className = '' }) {
  const [active, setActive] = useState(defaultTab);
  return (
    <TabCtx.Provider value={{ active, setActive }}>
      <div className={className}>{children}</div>
    </TabCtx.Provider>
  );
}

export function TabList({ children, className = '' }) {
  return (
    <div
      role="tablist"
      className={[
        'flex w-full shrink-0 border-b border-border',
        className,
      ].join(' ')}
    >
      {children}
    </div>
  );
}

export function Tab({ id, icon, children }) {
  const { active, setActive } = useContext(TabCtx);
  const isActive = active === id;

  return (
    <button
      role="tab"
      aria-selected={isActive}
      aria-controls={`tabpanel-${id}`}
      id={`tab-${id}`}
      onClick={() => setActive(id)}
      className={[
        'flex-1 flex flex-col items-center justify-center gap-1.5 py-4',
        'min-h-[64px] text-label-caps font-semibold uppercase tracking-widest',
        'transition-colors duration-150',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-inset',
        isActive
          ? 'text-secondary bg-code-surface border-b-[3px] border-secondary'
          : 'text-text-body border-b-[3px] border-transparent hover:text-text-primary',
      ].join(' ')}
    >
      {icon && <span aria-hidden>{icon}</span>}
      {children}
    </button>
  );
}

export function TabPanel({ id, children, className = '' }) {
  const { active } = useContext(TabCtx);
  if (active !== id) return null;

  return (
    <div
      role="tabpanel"
      id={`tabpanel-${id}`}
      aria-labelledby={`tab-${id}`}
      className={className}
    >
      {children}
    </div>
  );
}
