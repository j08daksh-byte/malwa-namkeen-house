/**
 * Card — base container.
 * variant: 'default' (#122832) | 'elevated' (#18333E) | 'code' (#0A1820)
 * hoverable: adds border-primary/40 on hover (used on Explore cards)
 */

const VARIANT = {
  default:  'bg-card border-border',
  elevated: 'bg-elevated border-border',
  code:     'bg-code-surface border-border',
};

export default function Card({
  variant = 'default',
  hoverable = false,
  className = '',
  children,
  ...props
}) {
  return (
    <div
      className={[
        'rounded-lg border',
        VARIANT[variant],
        hoverable &&
          'transition-colors duration-200 hover:border-primary/40 cursor-pointer',
        className,
      ]
        .filter(Boolean)
        .join(' ')}
      {...props}
    >
      {children}
    </div>
  );
}
