/**
 * ProgressBar — thin horizontal fill bar.
 * value: 0–100
 * color: 'primary' | 'secondary' | 'success'
 */

const COLORS = {
  primary:   'bg-primary',
  secondary: 'bg-secondary',
  success:   'bg-success',
};

export default function ProgressBar({
  value = 0,
  color = 'primary',
  className = '',
  label,
}) {
  const clamped = Math.min(100, Math.max(0, value));

  return (
    <div
      role="progressbar"
      aria-valuenow={clamped}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={label}
      className={['w-full h-2 rounded-full bg-elevated overflow-hidden', className].join(' ')}
    >
      <div
        className={['h-full rounded-full transition-all duration-500', COLORS[color]].join(' ')}
        style={{ width: `${clamped}%` }}
      />
    </div>
  );
}
