/**
 * Badge — small status / difficulty chip.
 *
 * variant: 'easy' | 'medium' | 'hard' | 'completed' | 'in-progress' | 'default'
 *
 * Uses label-caps typography, 8px radius, tinted border.
 */

const VARIANT = {
  easy:        'bg-secondary/10  text-secondary border-secondary/20',
  medium:      'bg-primary/10    text-primary   border-primary/20',
  hard:        'bg-error/10      text-error      border-error/20',
  completed:   'bg-success/10   text-success    border-success/20',
  'in-progress':'bg-tertiary/10 text-tertiary   border-tertiary/20',
  default:     'bg-elevated      text-text-secondary border-border',
};

export default function Badge({ variant = 'default', className = '', children, ...props }) {
  return (
    <span
      className={[
        'inline-flex items-center gap-1.5 px-2 py-0.5',
        'rounded text-label-caps font-semibold uppercase tracking-widest',
        'border',
        VARIANT[variant],
        className,
      ].join(' ')}
      {...props}
    >
      {children}
    </span>
  );
}
