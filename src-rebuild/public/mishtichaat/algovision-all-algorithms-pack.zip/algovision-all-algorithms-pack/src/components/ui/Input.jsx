/**
 * Input — labelled text input.
 * On focus: primary (coral) border.
 * Passes all native input props through.
 */

export default function Input({
  label,
  id,
  className = '',
  ...props
}) {
  return (
    <div className="flex flex-col gap-xs">
      {label && (
        <label htmlFor={id} className="text-label-caps text-text-secondary uppercase tracking-widest">
          {label}
        </label>
      )}
      <input
        id={id}
        className={[
          'h-11 w-full rounded px-md',
          'bg-code-surface border border-border text-text-primary',
          'text-body-md font-sans placeholder:text-text-secondary',
          'transition-colors duration-150',
          'hover:border-text-secondary',
          'focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary',
          'disabled:opacity-40 disabled:pointer-events-none',
          className,
        ].join(' ')}
        {...props}
      />
    </div>
  );
}
