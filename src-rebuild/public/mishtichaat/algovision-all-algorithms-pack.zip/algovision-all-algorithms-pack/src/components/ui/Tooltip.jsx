import { useState } from 'react';

/**
 * Tooltip — hover/focus tooltip wrapper.
 * Wraps a single trigger child and shows a label above it.
 *
 * position: 'top' (default) | 'bottom'
 */

export default function Tooltip({ label, position = 'top', children }) {
  const [visible, setVisible] = useState(false);

  const posClass =
    position === 'bottom'
      ? 'top-full mt-2 bottom-auto'
      : 'bottom-full mb-2 top-auto';

  return (
    <div
      className="relative inline-flex"
      onMouseEnter={() => setVisible(true)}
      onMouseLeave={() => setVisible(false)}
      onFocus={() => setVisible(true)}
      onBlur={() => setVisible(false)}
    >
      {children}

      {visible && (
        <div
          role="tooltip"
          className={[
            'absolute left-1/2 -translate-x-1/2 z-50 pointer-events-none',
            'whitespace-nowrap px-sm py-xs',
            'bg-elevated border border-border rounded text-label-caps text-text-body',
            posClass,
          ].join(' ')}
        >
          {label}
        </div>
      )}
    </div>
  );
}
