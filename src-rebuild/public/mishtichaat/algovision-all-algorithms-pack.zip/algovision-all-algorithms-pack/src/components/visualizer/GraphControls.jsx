/**
 * GraphControls — input panel for graph traversal visualizers (BFS and DFS).
 *
 * Independent of all other controls.
 *
 * Props:
 *   initialNodesString   string   — pre-filled nodes input
 *   initialEdgesString   string   — pre-filled edges input
 *   initialStartString   string   — pre-filled start node
 *   onLoadGraph(input)   function — called with { graphData, startLabel } on Apply
 *   onPause              function — called before loading when playing
 *   isPlaying            boolean  — playback state
 */

import { useState } from 'react';
import { parseBfsInput } from '../../lib/graphBfs';

function randomGraph() {
  const n = Math.floor(Math.random() * 5) + 3; // 3–7 nodes
  const labels = Array.from({ length: n }, (_, i) => i);
  // Ensure connectivity: chain 0-1-2-...(n-1)
  const edges = [];
  for (let i = 0; i < n - 1; i++) edges.push(`${i}:${i + 1}`);
  // Add a few random extra edges
  const extra = Math.floor(Math.random() * 3);
  for (let k = 0; k < extra; k++) {
    const a = Math.floor(Math.random() * n);
    const b = Math.floor(Math.random() * n);
    const lo = Math.min(a, b); const hi = Math.max(a, b);
    if (lo !== hi && !edges.includes(`${lo}:${hi}`)) edges.push(`${lo}:${hi}`);
  }
  return {
    nodes: labels.join(', '),
    edges: edges.join(', '),
    start: '0',
  };
}

const EXAMPLES = [
  {
    label:    'Default tree-like graph',
    desc:     '6 nodes, tree-like structure',
    nodes:    '0, 1, 2, 3, 4, 5',
    edges:    '0:1, 0:2, 1:3, 1:4, 2:5',
    start:    '0',
  },
  {
    label:    'Cycle graph',
    desc:     '4 nodes in a cycle',
    nodes:    '0, 1, 2, 3',
    edges:    '0:1, 1:2, 2:3, 3:0',
    start:    '0',
  },
  {
    label:    'Disconnected graph',
    desc:     'Nodes 3 and 4 are unreachable',
    nodes:    '0, 1, 2, 3, 4',
    edges:    '0:1, 1:2, 3:4',
    start:    '0',
  },
  {
    label:    'Single node',
    desc:     'No edges',
    nodes:    '7',
    edges:    '',
    start:    '7',
  },
];

export default function GraphControls({
  initialNodesString,
  initialEdgesString,
  initialStartString,
  onLoadGraph,
  onPause,
  isPlaying,
  controlHelp,    // optional: overrides the default help text
}) {
  const [nodesInput, setNodesInput] = useState(initialNodesString ?? '0, 1, 2, 3, 4, 5');
  const [edgesInput, setEdgesInput] = useState(initialEdgesString ?? '0:1, 0:2, 1:3, 1:4, 2:5');
  const [startInput, setStartInput] = useState(initialStartString ?? '0');
  const [errors,     setErrors]     = useState({ nodes: '', edges: '', start: '', general: '' });

  // ── Apply ─────────────────────────────────────────────────────────────────

  function applyGraph(n, e, s) {
    if (isPlaying) onPause();
    const result = parseBfsInput(n, e, s);
    if (result.error) {
      // Route error to best-fit field
      const msg = result.error;
      if (msg.includes('Node') && (msg.includes('not a valid') || msg.includes('Duplicate') || msg.includes('out of range') || msg.includes('at least') || msg.includes('Maximum'))) {
        setErrors({ nodes: msg, edges: '', start: '', general: '' });
      } else if (msg.includes('Edge') || msg.includes('endpoint')) {
        setErrors({ nodes: '', edges: msg, start: '', general: '' });
      } else if (msg.includes('Start')) {
        setErrors({ nodes: '', edges: '', start: msg, general: '' });
      } else {
        setErrors({ nodes: '', edges: '', start: '', general: msg });
      }
      return;
    }
    setErrors({ nodes: '', edges: '', start: '', general: '' });
    onLoadGraph(result);
  }

  // ── Random ────────────────────────────────────────────────────────────────

  function handleRandom() {
    const g = randomGraph();
    setNodesInput(g.nodes);
    setEdgesInput(g.edges);
    setStartInput(g.start);
    setErrors({ nodes: '', edges: '', start: '', general: '' });
    applyGraph(g.nodes, g.edges, g.start);
  }

  // ── Reset ─────────────────────────────────────────────────────────────────

  function handleReset() {
    const n = '0, 1, 2, 3, 4, 5';
    const e = '0:1, 0:2, 1:3, 1:4, 2:5';
    const s = '0';
    setNodesInput(n); setEdgesInput(e); setStartInput(s);
    setErrors({ nodes: '', edges: '', start: '', general: '' });
    applyGraph(n, e, s);
  }

  const inputBase = [
    'w-full rounded-lg bg-code-surface border font-mono text-code-md',
    'text-text-primary px-3 py-2',
    'focus:outline-none focus:ring-2 focus:ring-primary',
    'placeholder:text-text-secondary/50',
  ].join(' ');

  return (
    <div className="flex flex-col gap-md overflow-y-auto p-md">

      {/* ── Nodes ────────────────────────────────────────────────────────── */}
      <div className="flex flex-col gap-xs">
        <label htmlFor="graph-nodes-input"
          className="text-label-caps font-semibold text-text-secondary uppercase tracking-widest">
          Nodes
        </label>
        <input
          id="graph-nodes-input"
          type="text"
          value={nodesInput}
          onChange={e => { setNodesInput(e.target.value); setErrors(p => ({ ...p, nodes: '' })); }}
          onKeyDown={e => { if (e.key === 'Enter') applyGraph(nodesInput, edgesInput, startInput); }}
          placeholder="e.g. 0, 1, 2, 3"
          aria-describedby="graph-nodes-help graph-nodes-error"
          className={`${inputBase} ${errors.nodes ? 'border-error' : 'border-border'}`}
        />
        <p id="graph-nodes-help" className="text-body-sm text-text-secondary">
          Comma-separated unique integers (0–99). Max 12 nodes.
        </p>
        {errors.nodes && (
          <p id="graph-nodes-error" role="alert" className="text-body-sm text-error">{errors.nodes}</p>
        )}
      </div>

      {/* ── Edges ────────────────────────────────────────────────────────── */}
      <div className="flex flex-col gap-xs">
        <label htmlFor="graph-edges-input"
          className="text-label-caps font-semibold text-text-secondary uppercase tracking-widest">
          Edges
        </label>
        <input
          id="graph-edges-input"
          type="text"
          value={edgesInput}
          onChange={e => { setEdgesInput(e.target.value); setErrors(p => ({ ...p, edges: '' })); }}
          onKeyDown={e => { if (e.key === 'Enter') applyGraph(nodesInput, edgesInput, startInput); }}
          placeholder="e.g. 0:1, 0:2, 1:3"
          aria-describedby="graph-edges-help graph-edges-error"
          className={`${inputBase} ${errors.edges ? 'border-error' : 'border-border'}`}
        />
        <p id="graph-edges-help" className="text-body-sm text-text-secondary">
          Colon-separated pairs (A:B). Undirected — 0:1 and 1:0 are the same edge. Leave blank for no edges.
        </p>
        {errors.edges && (
          <p id="graph-edges-error" role="alert" className="text-body-sm text-error">{errors.edges}</p>
        )}
      </div>

      {/* ── Start node ───────────────────────────────────────────────────── */}
      <div className="flex flex-col gap-xs">
        <label htmlFor="graph-start-input"
          className="text-label-caps font-semibold text-text-secondary uppercase tracking-widest">
          Start Node
        </label>
        <input
          id="graph-start-input"
          type="text"
          value={startInput}
          onChange={e => { setStartInput(e.target.value); setErrors(p => ({ ...p, start: '' })); }}
          onKeyDown={e => { if (e.key === 'Enter') applyGraph(nodesInput, edgesInput, startInput); }}
          placeholder="e.g. 0"
          aria-describedby="graph-start-help graph-start-error"
          className={`${inputBase} ${errors.start ? 'border-error' : 'border-border'}`}
        />
        <p id="graph-start-help" className="text-body-sm text-text-secondary">
          Must be one of the nodes listed above.
        </p>
        {errors.start && (
          <p id="graph-start-error" role="alert" className="text-body-sm text-error">{errors.start}</p>
        )}
      </div>

      {errors.general && (
        <p role="alert" className="text-body-sm text-error">{errors.general}</p>
      )}

      {/* ── Action buttons ────────────────────────────────────────────────── */}
      <div className="flex gap-2 flex-wrap">
        <button
          onClick={() => applyGraph(nodesInput, edgesInput, startInput)}
          className="px-md py-xs rounded-lg text-label-caps font-semibold uppercase tracking-widest bg-primary text-background hover:bg-primary/80 active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary transition-colors duration-150"
        >
          Apply Graph
        </button>
        <button
          onClick={handleRandom}
          className="px-md py-xs rounded-lg text-label-caps font-semibold uppercase tracking-widest bg-elevated border border-border text-text-primary hover:border-primary hover:text-primary active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary transition-colors duration-150"
        >
          Random
        </button>
        <button
          onClick={handleReset}
          className="px-md py-xs rounded-lg text-label-caps font-semibold uppercase tracking-widest bg-elevated border border-border text-text-secondary hover:border-border hover:text-text-primary active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary transition-colors duration-150"
        >
          Reset
        </button>
      </div>

      {/* ── Examples ─────────────────────────────────────────────────────── */}
      <div className="flex flex-col gap-xs">
        <p className="text-label-caps font-semibold text-text-secondary uppercase tracking-widest">
          Examples
        </p>
        <div className="flex flex-col gap-xs">
          {EXAMPLES.map(ex => (
            <button
              key={ex.label}
              onClick={() => {
                setNodesInput(ex.nodes);
                setEdgesInput(ex.edges);
                setStartInput(ex.start);
                setErrors({ nodes: '', edges: '', start: '', general: '' });
                applyGraph(ex.nodes, ex.edges, ex.start);
              }}
              className="flex flex-col items-start text-left rounded-lg border border-border bg-card px-3 py-2 gap-0.5 hover:border-primary hover:bg-elevated/30 transition-colors duration-150 active:scale-[0.99] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
            >
              <span className="text-body-md font-semibold text-text-primary">{ex.label}</span>
              <span className="text-body-sm text-text-secondary">{ex.desc}</span>
              <span className="font-mono text-code-sm text-text-secondary/80 mt-0.5">
                Nodes: {ex.nodes || '—'} · Edges: {ex.edges || '(none)'} · Start: {ex.start}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* ── Help ─────────────────────────────────────────────────────────── */}
      <div className="rounded-lg border border-border bg-code-surface px-3 py-2">
        <p className="text-body-sm text-text-secondary leading-relaxed">
          <span className="font-semibold text-text-primary">How it works:</span>{' '}
          {controlHelp ?? (
            'Graph traversal algorithms explore all nodes reachable from a start node. ' +
            'Nodes are marked visited to prevent revisiting. Disconnected nodes outside ' +
            'the starting component remain unvisited.'
          )}
        </p>
      </div>
    </div>
  );
}
