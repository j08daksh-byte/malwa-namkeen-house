/**
 * LinkedListCycleControls
 *
 * Controls for Detect Cycle (Floyd's Algorithm).
 * Props:
 *   values       — number[]
 *   cycleEntry   — number | -1 (index of node where tail points back, -1 = no cycle)
 *   onValuesChange
 *   onCycleEntryChange
 *   onRun
 *   disabled
 */

import { useState } from 'react';

function parseValues(str) {
  const parts = str.split(',').map(s => s.trim()).filter(Boolean);
  if (!parts.length) return { valid: false, error: 'List cannot be empty.' };
  if (parts.length > 10) return { valid: false, error: 'Max 10 nodes for cycle detection.' };
  const nums = [];
  for (const p of parts) {
    const n = Number(p);
    if (!Number.isInteger(n) || n < -999 || n > 999) {
      return { valid: false, error: 'Values must be integers from -999 to 999.' };
    }
    nums.push(n);
  }
  return { valid: true, value: nums };
}

export default function LinkedListCycleControls({
  values = [],
  cycleEntry = 1,
  onValuesChange,
  onCycleEntryChange,
  onRun,
  disabled = false,
}) {
  const [valStr, setValStr]       = useState(values.join(', '));
  const [entryStr, setEntryStr]   = useState(String(cycleEntry));
  const [error, setError]         = useState('');

  function handleRun() {
    const valResult = parseValues(valStr);
    if (!valResult.valid) { setError(valResult.error); return; }

    const entry = parseInt(entryStr, 10);
    const n = valResult.value.length;
    if (entry !== -1 && (!Number.isInteger(entry) || entry < 0 || entry >= n)) {
      setError(`Cycle entry must be -1 (no cycle) or a valid index 0–${n - 1}.`);
      return;
    }
    setError('');
    onValuesChange?.(valResult.value);
    onCycleEntryChange?.(entry);
    onRun?.();
  }

  return (
    <div className="flex flex-col gap-3">
      {/* List values */}
      <div className="flex flex-col gap-1">
        <label className="text-label-caps text-text-secondary uppercase tracking-widest text-[10px]">
          List Values (comma-separated)
        </label>
        <input
          className="input-field font-mono"
          type="text"
          value={valStr}
          onChange={e => { setValStr(e.target.value); setError(''); }}
          onKeyDown={e => e.key === 'Enter' && handleRun()}
          disabled={disabled}
          placeholder="e.g. 3, 2, 0, -4"
          aria-label="List values"
        />
      </div>

      {/* Cycle entry */}
      <div className="flex flex-col gap-1">
        <label className="text-label-caps text-text-secondary uppercase tracking-widest text-[10px]">
          Cycle Entry Index (-1 = no cycle)
        </label>
        <input
          className="input-field font-mono w-24"
          type="number"
          min={-1}
          value={entryStr}
          onChange={e => { setEntryStr(e.target.value); setError(''); }}
          onKeyDown={e => e.key === 'Enter' && handleRun()}
          disabled={disabled}
          aria-label="Cycle entry index"
        />
        <p className="text-[10px] text-text-secondary">
          Tail points back to this node index. -1 means no cycle.
        </p>
      </div>

      {error && <p className="text-error text-code-sm" role="alert">{error}</p>}

      <button className="btn-primary mt-1" onClick={handleRun} disabled={disabled}>
        Visualize
      </button>
    </div>
  );
}
