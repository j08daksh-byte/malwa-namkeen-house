/**
 * LinkedListCanvas — horizontal singly linked list renderer.
 *
 * Layout per node:
 *   HEAD / CURR labels above the node
 *   ┌──────┬──────┐
 *   │ DATA │  →   │──► next node  (or NULL for last)
 *   └──────┴──────┘
 *
 * Visual states (approved palette):
 *   default   — muted blue-grey   (bg-elevated / border-border)
 *   current   — amber/tertiary    (bg-tertiary  / border-tertiary)
 *   visited   — mint/secondary    (bg-secondary / border-secondary)
 *   completed — green/success     (bg-success   / border-success)
 *   null-current — indicated by showing CURR arrow above NULL box
 *
 * Meaning is conveyed via color AND text labels (HEAD, CURR, VISITED, NULL).
 * Horizontal scrolling is contained within this component only.
 */

const LABEL_H = 52; // px — fixed height of the label area above each node

// ── Per-state style helpers ───────────────────────────────────────────────

function getNodeStyle(nodeId, step) {
  const { type, currentNodeId, visitedNodeIds, prevNodeId, slowNodeId, fastNodeId, newNodeId, highlightNodeId } = step ?? {};

  if (type === 'completed') {
    return 'border-success bg-success/15 text-success';
  }
  if (nodeId === newNodeId) {
    return 'border-secondary bg-secondary/15 text-secondary';
  }
  if (nodeId === highlightNodeId) {
    return 'border-error bg-error/15 text-error';
  }
  // slow and fast can overlap — show error if they meet, else primary for slow, tertiary for fast
  if (nodeId === slowNodeId && nodeId === fastNodeId) {
    return 'border-error bg-error/15 text-error';
  }
  if (nodeId === slowNodeId) {
    return 'border-primary bg-primary/15 text-primary';
  }
  if (nodeId === fastNodeId) {
    return 'border-tertiary bg-tertiary/15 text-tertiary';
  }
  if (nodeId === prevNodeId) {
    return 'border-secondary/70 bg-secondary/10 text-secondary';
  }
  if (nodeId === currentNodeId) {
    return 'border-tertiary bg-tertiary/15 text-tertiary';
  }
  if (visitedNodeIds?.includes(nodeId)) {
    return 'border-secondary bg-secondary/15 text-secondary';
  }
  return 'border-border bg-elevated text-text-primary';
}

function getNextPointerStyle(nodeId, step) {
  if (nodeId === step?.currentNodeId) return 'border-tertiary/50 text-tertiary/80';
  if (step?.visitedNodeIds?.includes(nodeId)) return 'border-secondary/50 text-secondary/80';
  return 'border-border text-text-secondary';
}

// ── Sub-components ────────────────────────────────────────────────────────

function NodeBox({ node, step }) {
  const boxStyle = getNodeStyle(node.id, step);
  const ptrStyle = getNextPointerStyle(node.id, step);
  const isCurrent  = node.id === step?.currentNodeId;
  const isVisited  = step?.visitedNodeIds?.includes(node.id) && !isCurrent;
  const isCompleted = step?.type === 'completed';
  const isNew      = node.id === step?.newNodeId;
  const isHighlight = node.id === step?.highlightNodeId;
  const isSlow     = node.id === step?.slowNodeId;
  const isFast     = node.id === step?.fastNodeId;
  const isPrev     = node.id === step?.prevNodeId;

  const statusLabel = isCompleted
    ? 'VISITED'
    : isCurrent
      ? 'CURRENT'
      : isVisited
        ? 'VISITED'
        : null;

  return (
    <div
      className={[
        'flex border-2 rounded-lg overflow-hidden transition-colors duration-200 shrink-0',
        boxStyle,
      ].join(' ')}
      role="listitem"
      aria-label={[
        node.id === step?.headId ? 'Head node, ' : '',
        statusLabel ? `${statusLabel}, ` : '',
        `value ${node.value}, `,
        node.nextId ? `next points to node containing ${step?.nodes?.find(n => n.id === node.nextId)?.value ?? 'next'}` : 'next is NULL',
      ].join('')}
    >
      {/* Data cell */}
      <div className="w-12 h-12 flex items-center justify-center font-mono font-bold border-r-2 border-inherit">
        {node.value}
      </div>
      {/* Next pointer cell */}
      <div className={`w-10 h-12 flex items-center justify-center text-xs font-mono border-l border-white/10 transition-colors duration-200 ${ptrStyle}`}>
        {node.nextId ? '→' : 'null'}
      </div>
    </div>
  );
}

function ArrowConnector() {
  return (
    <div
      className="flex items-center px-1.5 text-text-secondary shrink-0"
      style={{ height: 48, marginTop: LABEL_H }}
      aria-hidden
    >
      <span className="text-sm select-none">──►</span>
    </div>
  );
}

function NullTerminal({ isCurrentHere }) {
  return (
    <div className="flex items-start shrink-0" style={{ marginTop: 0 }}>
      {/* Arrow to NULL */}
      <div
        className="flex items-center px-1.5 text-text-secondary"
        style={{ height: 48, marginTop: LABEL_H }}
        aria-hidden
      >
        <span className="text-sm select-none">──►</span>
      </div>
      {/* NULL box with optional CURR label above */}
      <div className="flex flex-col items-center">
        {/* Label area — same height as node label area */}
        <div
          className="flex flex-col items-center justify-end pb-1"
          style={{ height: LABEL_H }}
        >
          {isCurrentHere && (
            <>
              <span className="text-[10px] font-bold uppercase tracking-widest text-primary leading-none">
                CURR
              </span>
              <span className="text-primary text-[11px] leading-none mt-0.5" aria-hidden>▼</span>
            </>
          )}
        </div>
        {/* NULL box */}
        <div
          className={[
            'h-12 flex items-center justify-center px-3 rounded-lg border-2 border-dashed font-mono text-code-sm transition-colors duration-200',
            isCurrentHere
              ? 'border-primary/60 bg-primary/10 text-primary'
              : 'border-border text-text-secondary',
          ].join(' ')}
          aria-label="NULL — end of list"
        >
          NULL
        </div>
      </div>
    </div>
  );
}

// ── Output bar ────────────────────────────────────────────────────────────

function OutputBar({ values }) {
  if (values == null) return null;

  return (
    <div className="mt-4 flex items-start gap-2 flex-wrap">
      <span className="text-label-caps font-semibold text-text-secondary uppercase tracking-widest shrink-0 pt-0.5">
        Output:
      </span>
      {values.length === 0 ? (
        <span className="text-body-md text-text-secondary italic">( empty )</span>
      ) : (
        <div className="flex items-center gap-1.5 flex-wrap">
          {values.map((val, i) => (
            <span key={i} className="flex items-center gap-1.5">
              <span className="font-mono text-code-md font-semibold text-success">
                {val}
              </span>
              {i < values.length - 1 && (
                <span className="text-text-secondary text-xs" aria-hidden>→</span>
              )}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Empty list display ────────────────────────────────────────────────────

function EmptyListDisplay({ step }) {
  const isCurrentHere = step?.currentNodeId === null && step?.type !== 'initial';

  return (
    <div className="flex items-start">
      {/* HEAD label + arrow + NULL */}
      <div className="flex flex-col items-center">
        <div
          className="flex flex-col items-center justify-end pb-1"
          style={{ height: LABEL_H }}
        >
          <span className="text-[10px] font-bold uppercase tracking-widest text-primary leading-none">
            HEAD
          </span>
          {isCurrentHere && (
            <span className="text-[10px] font-bold uppercase tracking-widest text-primary leading-none mt-0.5">
              CURR
            </span>
          )}
          <span className="text-primary text-[11px] leading-none mt-0.5" aria-hidden>▼</span>
        </div>
        {/* Arrow to NULL */}
        <div className="flex items-center gap-1.5">
          <div
            className="h-12 flex items-center px-3 rounded-lg border-2 border-dashed font-mono text-code-sm border-border text-text-secondary"
            aria-label="HEAD points to NULL — empty list"
          >
            NULL
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────

export default function LinkedListCanvas({ step }) {
  const nodes          = step?.nodes ?? [];
  const headId         = step?.headId ?? null;
  const currentNodeId  = step?.currentNodeId ?? null;
  const visitedNodeIds = step?.visitedNodeIds ?? [];
  const outputValues   = step?.outputValues ?? [];
  const type           = step?.type ?? 'initial';

  // When current is null (reached-null / completed), show CURR label over NULL
  const currentIsAtNull = currentNodeId === null && type !== 'initial';

  return (
    <div
      className="flex flex-col flex-1 min-h-0 overflow-y-auto bg-background px-md py-md"
      aria-label="Linked list visualization"
    >
      {/* ── Description ──────────────────────────────────────────────────── */}
      <p
        className="text-body-md text-text-secondary leading-snug mb-4 min-h-[1.5rem]"
        aria-live="polite"
        aria-atomic="true"
      >
        {step?.description ?? ''}
      </p>

      {/* ── List display ─────────────────────────────────────────────────── */}
      <div className="overflow-x-auto scrollbar-thin pb-2" role="list" aria-label="Linked list nodes">
        <div className="flex items-start" style={{ minWidth: 'max-content' }}>

          {/* HEAD label + downward arrow — always shown */}
          {nodes.length > 0 && (
            <div
              className="flex flex-col items-center shrink-0"
              style={{ marginRight: 0 }}
              aria-hidden
            >
              <div
                className="flex flex-col items-center justify-end pb-1"
                style={{ height: LABEL_H }}
              >
                <span className="text-[10px] font-bold uppercase tracking-widest text-primary leading-none">
                  HEAD
                </span>
                <span className="text-primary text-[11px] leading-none mt-0.5">▼</span>
              </div>
              {/* Invisible spacer matching node height so the column aligns */}
              <div style={{ height: 48 }} />
            </div>
          )}

          {nodes.length === 0 ? (
            <EmptyListDisplay step={step} />
          ) : (
            nodes.map((node, i) => {
              const isCurrent = node.id === currentNodeId;
              const isHead    = node.id === headId;
              const isVisited = visitedNodeIds.includes(node.id) && !isCurrent;
              const isCompleted = type === 'completed';

              // Labels shown above this node
              const showHeadLabel    = false; // HEAD already shown separately on left
              const showCurrentLabel = isCurrent;
              const showVisitedLabel = (isVisited || isCompleted) && !isCurrent;
              const hasLabel         = showCurrentLabel;

              return (
                <div key={node.id} className="flex items-start shrink-0">
                  {/* Node column */}
                  <div className="flex flex-col items-center">
                    {/* Label area — fixed height */}
                    <div
                      className="flex flex-col items-center justify-end pb-1"
                      style={{ height: LABEL_H }}
                    >
                      {/* NEW node label */}
                      {step?.newNodeId === node.id && (
                        <span className="text-[9px] font-bold uppercase tracking-widest text-secondary leading-none">NEW</span>
                      )}
                      {/* PREV pointer */}
                      {step?.prevNodeId === node.id && !step?.slowNodeId && (
                        <span className="text-[9px] font-bold uppercase tracking-widest text-secondary leading-none">PREV</span>
                      )}
                      {/* SLOW pointer */}
                      {step?.slowNodeId === node.id && step?.fastNodeId !== node.id && (
                        <span className="text-[9px] font-bold uppercase tracking-widest text-primary leading-none">SLOW</span>
                      )}
                      {/* FAST pointer */}
                      {step?.fastNodeId === node.id && step?.slowNodeId !== node.id && (
                        <span className="text-[9px] font-bold uppercase tracking-widest text-tertiary leading-none">FAST</span>
                      )}
                      {/* SLOW+FAST meeting */}
                      {step?.slowNodeId === node.id && step?.fastNodeId === node.id && (
                        <span className="text-[9px] font-bold uppercase tracking-widest text-error leading-none">MEET</span>
                      )}
                      {/* TARGET label (delete) */}
                      {step?.highlightNodeId === node.id && (
                        <span className="text-[9px] font-bold uppercase tracking-widest text-error leading-none">TARGET</span>
                      )}
                      {showCurrentLabel && !step?.slowNodeId && !step?.fastNodeId && !step?.newNodeId && (
                        <>
                          <span className="text-[10px] font-bold uppercase tracking-widest text-tertiary leading-none">
                            CURR
                          </span>
                          <span className="text-tertiary text-[11px] leading-none mt-0.5" aria-hidden>▼</span>
                        </>
                      )}
                      {showVisitedLabel && (
                        <span className="text-[9px] uppercase tracking-widest text-secondary/80 leading-none">
                          VISITED
                        </span>
                      )}
                    </div>

                    <NodeBox node={node} step={step} />
                  </div>

                  {/* Arrow to next node */}
                  {node.nextId && <ArrowConnector />}

                  {/* NULL terminal after last node */}
                  {!node.nextId && (
                    <NullTerminal isCurrentHere={currentIsAtNull} />
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* ── Output ───────────────────────────────────────────────────────── */}
      <OutputBar values={outputValues} />
    </div>
  );
}
