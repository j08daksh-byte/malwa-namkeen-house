/**
 * BinaryTreeCanvas — renders a binary tree with node states + recursion stack panel.
 *
 * Props:
 *   step  — current step from generateTreePreorderSteps
 */

import { useMemo } from 'react';

// ── Layout constants ────────────────────────────────────────────────────────

const NODE_R   = 22;   // node circle radius
const H_GAP    = 64;   // horizontal gap between node centres (inorder index)
const V_GAP    = 76;   // vertical gap between levels
const PAD_X    = 48;
const PAD_Y    = 44;

// ── Layout computation ──────────────────────────────────────────────────────

function computeLayout(treeMap, rootId) {
  if (!rootId || !treeMap[rootId]) return { positions: {}, svgW: 200, svgH: 100 };

  let counter = 0;
  const xIndex = {};

  function inorder(id) {
    if (!id || !treeMap[id]) return;
    inorder(treeMap[id].left);
    xIndex[id] = counter++;
    inorder(treeMap[id].right);
  }
  inorder(rootId);

  const n = counter;
  const maxDepth = Math.max(...Object.values(treeMap).map(nd => nd.depth));

  const positions = {};
  for (const id of Object.keys(xIndex)) {
    positions[id] = {
      cx: PAD_X + xIndex[id] * H_GAP,
      cy: PAD_Y + treeMap[id].depth * V_GAP,
    };
  }

  const svgW = PAD_X * 2 + (n - 1) * H_GAP;
  const svgH = PAD_Y * 2 + maxDepth * V_GAP;

  return { positions, svgW: Math.max(svgW, 200), svgH: Math.max(svgH, 100) };
}

// ── Node state → colors ─────────────────────────────────────────────────────

function nodeColors(state, isActive) {
  if (isActive) {
    return { fill: '#F6C453', stroke: '#F6C453', text: '#08141A' }; // tertiary
  }
  switch (state) {
    case 'current':   return { fill: '#F6C453', stroke: '#F6C453', text: '#08141A' };
    case 'visited':   return { fill: '#35D0BA', stroke: '#35D0BA', text: '#08141A' };
    case 'completed': return { fill: '#39D98A', stroke: '#39D98A', text: '#08141A' };
    default:          return { fill: '#18333E', stroke: '#244550', text: '#C4D0D4' };
  }
}

// ── Tree empty state ────────────────────────────────────────────────────────

function EmptyTreeDisplay() {
  return (
    <div className="flex flex-col items-center justify-center gap-2 py-8">
      <div className="px-4 py-2 rounded border border-dashed border-border text-text-secondary text-body-md font-mono">
        NULL
      </div>
      <span className="text-body-sm text-text-secondary">Empty tree</span>
    </div>
  );
}

// ── Recursion stack panel ───────────────────────────────────────────────────

function RecursionStack({ stack }) {
  return (
    <div className="flex flex-col gap-xs p-sm border-l border-border min-w-[140px] max-w-[180px] overflow-y-auto">
      <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary shrink-0">
        Call Stack
      </p>
      {stack.length === 0 ? (
        <span className="text-body-sm text-text-secondary italic">(empty)</span>
      ) : (
        <div className="flex flex-col-reverse gap-0.5">
          {stack.map((frame, i) => {
            const isTop = i === stack.length - 1;
            return (
              <div
                key={i}
                style={{ paddingLeft: i * 8 }}
                className={[
                  'rounded px-2 py-1 font-mono text-code-sm truncate',
                  isTop
                    ? 'bg-tertiary/20 border border-tertiary/40 text-tertiary'
                    : 'bg-elevated border border-border text-text-secondary',
                ].join(' ')}
              >
                {frame}
              </div>
            );
          })}
        </div>
      )}
      {stack.length > 0 && (
        <p className="text-[9px] text-text-secondary mt-0.5 shrink-0">
          ↑ most recent
        </p>
      )}
    </div>
  );
}

// ── Output bar ──────────────────────────────────────────────────────────────

function OutputBar({ output }) {
  return (
    <div className="flex items-center gap-sm px-md py-sm border-t border-border bg-nav shrink-0 overflow-x-auto scrollbar-thin">
      <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary shrink-0">
        Output
      </span>
      {output.length === 0 ? (
        <span className="text-body-sm text-text-secondary italic">—</span>
      ) : (
        <div className="flex items-center gap-1">
          {output.map((val, i) => (
            <span key={i} className="flex items-center gap-1">
              <span className="font-mono text-code-md px-2 py-0.5 rounded bg-secondary/15 border border-secondary/40 text-secondary">
                {val}
              </span>
              {i < output.length - 1 && (
                <span className="text-text-secondary text-xs" aria-hidden>→</span>
              )}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Main component ──────────────────────────────────────────────────────────

export default function BinaryTreeCanvas({ step }) {
  const treeMap     = step?.treeMap     ?? {};
  const rootId      = step?.rootId      ?? null;
  const nodeStates  = step?.nodeStates  ?? {};
  const activeId    = step?.activeNodeId ?? null;
  const callStack   = step?.recursionStack ?? [];
  const output      = step?.output      ?? [];
  const description = step?.description ?? '';

  const { positions, svgW, svgH } = useMemo(
    () => computeLayout(treeMap, rootId),
    [treeMap, rootId],
  );

  const nodeIds = Object.keys(treeMap);
  const hasTree = rootId != null;

  return (
    <div className="flex flex-col bg-code-surface border-b border-border" style={{ minHeight: 260 }}>

      {/* Description */}
      <p
        aria-live="polite"
        aria-atomic="true"
        className="px-md py-xs text-body-sm text-text-secondary border-b border-border shrink-0"
      >
        {description}
      </p>

      {/* Tree + recursion stack */}
      <div className="flex flex-1 overflow-hidden">

        {/* SVG tree canvas */}
        <div className="flex-1 overflow-auto scrollbar-thin p-2">
          {!hasTree ? (
            <EmptyTreeDisplay />
          ) : (
            <svg
              viewBox={`0 0 ${svgW} ${svgH}`}
              width={svgW}
              height={svgH}
              aria-hidden
              className="overflow-visible"
            >
              {/* Edges */}
              {nodeIds.map((id) => {
                const node = treeMap[id];
                const p    = positions[id];
                if (!p) return null;
                return [node.left, node.right]
                  .filter(Boolean)
                  .map((childId) => {
                    const cp = positions[childId];
                    if (!cp) return null;
                    return (
                      <line
                        key={`${id}-${childId}`}
                        x1={p.cx} y1={p.cy}
                        x2={cp.cx} y2={cp.cy}
                        stroke="#244550"
                        strokeWidth={2}
                      />
                    );
                  });
              })}

              {/* Nodes */}
              {nodeIds.map((id) => {
                const node   = treeMap[id];
                const p      = positions[id];
                if (!p) return null;
                const state  = nodeStates[id] ?? 'default';
                const isAct  = id === activeId;
                const colors = nodeColors(state, isAct);

                return (
                  <g key={id}>
                    <circle
                      cx={p.cx}
                      cy={p.cy}
                      r={NODE_R}
                      fill={colors.fill}
                      stroke={colors.stroke}
                      strokeWidth={isAct ? 3 : 2}
                    />
                    <text
                      x={p.cx}
                      y={p.cy}
                      textAnchor="middle"
                      dominantBaseline="central"
                      fontSize={12}
                      fontFamily="monospace"
                      fontWeight="600"
                      fill={colors.text}
                    >
                      {node.val}
                    </text>
                  </g>
                );
              })}
            </svg>
          )}
        </div>

        {/* Recursion stack */}
        <RecursionStack stack={callStack} />
      </div>

      {/* Output bar */}
      <OutputBar output={output} />
    </div>
  );
}
