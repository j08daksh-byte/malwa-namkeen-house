/**
 * GraphCanvas — renders an undirected graph for BFS, DFS, and Cycle Detection.
 *
 * Layout: circular, deterministic (sorted by label).
 * Primary: SVG graph. Below: algorithm-specific supporting panel + result/output bar.
 *
 * Supporting panel is chosen from step data (no algorithm-ID checks):
 *   step.supportingStructure  → SupportingPanel  (Cycle Detection)
 *   step.recursionStack       → RecursionStack   (DFS)
 *   (none)                    → BfsQueue         (BFS)
 *
 * Props:
 *   step — current step from generateBfsSteps, generateDfsSteps,
 *           or generateCycleDetectionSteps
 */

import { useMemo } from 'react';

// ── Layout ───────────────────────────────────────────────────────────────────

const NODE_R  = 22;   // circle radius (44px diameter — accessible touch target)
const LABEL_H = 18;   // space above node for state label

function computeLayout(nodes) {
  if (!nodes.length) return { positions: {}, svgW: 200, svgH: 200, cx: 100, cy: 100 };

  const sorted = [...nodes].sort((a, b) => a.label - b.label);
  const n = sorted.length;

  if (n === 1) {
    const cx = 130; const cy = 130;
    return {
      positions: { [sorted[0].id]: { x: cx, y: cy } },
      svgW: 260, svgH: 260, cx, cy,
    };
  }

  const R = Math.max(80, Math.min(160, 22 * n));
  const PAD = NODE_R + LABEL_H + 28;
  const cx = R + PAD;
  const cy = R + PAD;

  const positions = {};
  sorted.forEach((node, i) => {
    const angle = (2 * Math.PI * i / n) - Math.PI / 2;
    positions[node.id] = {
      x: cx + R * Math.cos(angle),
      y: cy + R * Math.sin(angle),
    };
  });

  return { positions, svgW: (R + PAD) * 2, svgH: (R + PAD) * 2, cx, cy };
}

// ── Node visual config ────────────────────────────────────────────────────────

function nodeStyle(nodeId, nodeStates, activeNeighborId, startNodeId, currentNodeId) {
  if (nodeId === activeNeighborId && nodeId !== currentNodeId) {
    return { fill: 'rgba(246,196,83,0.15)', stroke: '#F6C453', text: '#F6C453', ring: true };
  }
  const s = nodeStates?.[nodeId] ?? 'default';
  switch (s) {
    case 'start':     return { fill: 'rgba(255,104,70,0.15)', stroke: '#FF6846', text: '#FF6846', ring: false };
    case 'queued':    return { fill: 'rgba(53,208,186,0.2)',  stroke: '#35D0BA', text: '#35D0BA', ring: false };
    case 'current':   return { fill: 'rgba(246,196,83,0.2)',  stroke: '#F6C453', text: '#F6C453', ring: false };
    case 'processed': return { fill: 'rgba(53,208,186,0.2)',  stroke: '#35D0BA', text: '#35D0BA', ring: false };
    case 'completed': return { fill: 'rgba(57,217,138,0.2)',  stroke: '#39D98A', text: '#39D98A', ring: false };
    case 'unreached': return { fill: 'rgba(36,69,80,0.5)',    stroke: '#244550', text: '#5A7A88', ring: false };
    default:          return { fill: '#18333E',               stroke: '#244550', text: '#C4D0D4', ring: false };
  }
}

// ── State badge above node ────────────────────────────────────────────────────
// Priority: CURRENT > INSPECT > COMP ROOT > PARENT > START > UNREACHED

function stateBadge(nodeId, nodeStates, startNodeId, currentNodeId, activeNeighborId,
                    componentRootId, parentNodeId, isCycleDetection) {
  if (nodeId === currentNodeId) return 'CURRENT';
  if (nodeId === activeNeighborId && nodeId !== currentNodeId) return 'INSPECT';
  if (isCycleDetection && componentRootId && nodeId === componentRootId) return 'COMP ROOT';
  if (isCycleDetection && parentNodeId && nodeId === parentNodeId) return 'PARENT';
  const s = nodeStates?.[nodeId] ?? 'default';
  if (s === 'start' && nodeId === startNodeId) return 'START';
  if (s === 'unreached') return 'UNREACHED';
  return '';
}

// ── BFS Queue panel ───────────────────────────────────────────────────────────

function BfsQueue({ queue, nodes }) {
  return (
    <div className="flex flex-col gap-xs p-sm border-t border-border bg-nav shrink-0">
      <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary">
        BFS Queue
      </p>
      {queue.length === 0 ? (
        <span className="text-body-sm text-text-secondary italic font-mono">empty</span>
      ) : (
        <div className="flex items-center gap-1 overflow-x-auto scrollbar-thin pb-1">
          <span className="text-[9px] text-secondary font-bold shrink-0">FRONT →</span>
          {queue.map((nodeId, i) => {
            const node    = nodes.find(n => n.id === nodeId);
            const isFront = i === 0;
            const isRear  = i === queue.length - 1;
            return (
              <div key={nodeId} className="flex items-center gap-1 shrink-0">
                <div
                  className={[
                    'w-10 h-10 rounded-lg flex items-center justify-center font-mono text-code-md font-bold border-2',
                    isFront
                      ? 'bg-secondary/20 border-secondary text-secondary'
                      : isRear
                        ? 'bg-primary/20 border-primary text-primary'
                        : 'bg-elevated border-border text-text-primary',
                  ].join(' ')}
                  aria-label={`${isFront ? 'Front, ' : ''}${isRear && !isFront ? 'Rear, ' : ''}node ${node?.label ?? '?'}`}
                >
                  {node?.label ?? '?'}
                </div>
                {i < queue.length - 1 && (
                  <span className="text-text-secondary text-xs" aria-hidden>→</span>
                )}
              </div>
            );
          })}
          <span className="text-[9px] text-primary font-bold shrink-0">← REAR</span>
        </div>
      )}
    </div>
  );
}

// ── DFS Recursion Stack panel ─────────────────────────────────────────────────

function RecursionStack({ stack, nodes }) {
  return (
    <div className="flex flex-col gap-xs p-sm border-t border-border bg-nav shrink-0"
         aria-label="DFS recursion stack">
      <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary">
        Recursion Stack
      </p>
      {stack.length === 0 ? (
        <span className="text-body-sm text-text-secondary italic font-mono">empty</span>
      ) : (
        <div className="flex flex-col gap-0.5 overflow-y-auto max-h-28 scrollbar-thin">
          {stack.map((nodeId, i) => {
            const node  = nodes.find(n => n.id === nodeId);
            const isTop = i === stack.length - 1;
            return (
              <div
                key={nodeId + '-' + i}
                className="flex items-center gap-1"
                style={{ paddingLeft: i * 10 }}
              >
                <div
                  className={[
                    'px-2 py-0.5 rounded font-mono text-code-sm font-bold border',
                    isTop
                      ? 'bg-tertiary/20 border-tertiary text-tertiary'
                      : 'bg-elevated border-border text-text-secondary',
                  ].join(' ')}
                  aria-label={`${isTop ? 'Active, ' : ''}dfs(${node?.label ?? '?'})`}
                >
                  dfs({node?.label ?? '?'})
                </div>
                {isTop && (
                  <span className="text-[9px] font-bold text-tertiary uppercase tracking-wider" aria-hidden>
                    ← ACTIVE
                  </span>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ── Generic Supporting Panel (Cycle Detection DFS call stack) ─────────────────

function SupportingPanel({ structure, nodes }) {
  const { label, items } = structure;
  return (
    <div className="flex flex-col gap-xs p-sm border-t border-border bg-nav shrink-0"
         aria-label={label}>
      <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary">
        {label}
      </p>
      {items.length === 0 ? (
        <span className="text-body-sm text-text-secondary italic font-mono">empty</span>
      ) : (
        <div className="flex flex-col gap-0.5 overflow-y-auto max-h-28 scrollbar-thin">
          {items.map((entry, i) => {
            const node   = nodes.find(n => n.id === entry.nodeId);
            const parent = nodes.find(n => n.id === entry.parentNodeId);
            const isTop  = i === items.length - 1;
            return (
              <div
                key={entry.nodeId + '-' + i}
                className="flex items-center gap-1"
                style={{ paddingLeft: (entry.depth ?? i) * 10 }}
              >
                <div
                  className={[
                    'px-2 py-0.5 rounded font-mono text-code-sm font-bold border',
                    isTop
                      ? 'bg-tertiary/20 border-tertiary text-tertiary'
                      : 'bg-elevated border-border text-text-secondary',
                  ].join(' ')}
                  aria-label={`${isTop ? 'Active, ' : ''}dfs(${node?.label ?? '?'}, parent=${parent?.label ?? 'NONE'})`}
                >
                  dfs({node?.label ?? '?'}, p={parent !== undefined ? parent?.label : 'NONE'})
                </div>
                {isTop && (
                  <span className="text-[9px] font-bold text-tertiary uppercase tracking-wider" aria-hidden>
                    ← ACTIVE
                  </span>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ── Cycle Detection Result Panel ──────────────────────────────────────────────

function ResultPanel({ result, cycleEdgeId, edges, nodes }) {
  if (result === null) {
    return (
      <div className="flex items-center gap-sm px-md py-sm border-t border-border bg-nav shrink-0">
        <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary shrink-0">
          Result
        </span>
        <span className="text-body-sm text-text-secondary italic">Checking…</span>
      </div>
    );
  }

  let cycleDesc = result ? 'A back edge was found during DFS traversal.' : '';
  if (result === true && cycleEdgeId) {
    const cycleEdge = edges?.find(e => e.id === cycleEdgeId);
    if (cycleEdge) {
      const nA = nodes?.find(n => n.id === cycleEdge.sourceId);
      const nB = nodes?.find(n => n.id === cycleEdge.targetId);
      if (nA && nB) {
        cycleDesc = nA.id === nB.id
          ? `Node ${nA.label} has a self-loop.`
          : `Edge ${nA.label} — ${nB.label} connects to an already-visited non-parent node.`;
      }
    }
  }

  return (
    <div
      className="flex items-start gap-sm px-md py-sm border-t border-border bg-nav shrink-0"
      aria-live="polite"
      aria-atomic="true"
    >
      <span
        className={['w-2 h-2 rounded-full mt-1.5 shrink-0', result ? 'bg-error' : 'bg-success'].join(' ')}
        aria-hidden
      />
      <div>
        <p className={[
          'text-[10px] font-bold uppercase tracking-[0.15em]',
          result ? 'text-error' : 'text-success',
        ].join(' ')}>
          {result ? 'Cycle Found' : 'No Cycle Found'}
        </p>
        <p className="text-body-sm text-text-secondary mt-0.5">
          {result ? cycleDesc : 'Every connected component is acyclic.'}
        </p>
      </div>
    </div>
  );
}

// ── Output bar ────────────────────────────────────────────────────────────────

function OutputBar({ output }) {
  return (
    <div className="flex items-center gap-sm px-md py-sm border-t border-border bg-nav shrink-0 overflow-x-auto scrollbar-thin">
      <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary shrink-0">
        Output
      </span>
      {output.length === 0 ? (
        <span className="text-body-sm text-text-secondary italic">—</span>
      ) : (
        <div className="flex items-center gap-1">
          {output.map((val, i) => (
            <span key={i} className="flex items-center gap-1">
              <span className="font-mono text-code-md px-2 py-0.5 rounded bg-success/15 border border-success/40 text-success">
                {val}
              </span>
              {i < output.length - 1 && (
                <span className="text-text-secondary text-xs" aria-hidden>→</span>
              )}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────

export default function GraphCanvas({ step }) {
  const nodes              = step?.nodes              ?? [];
  const edges              = step?.edges              ?? [];
  const nodeStates         = step?.nodeStates         ?? {};
  const startNodeId        = step?.startNodeId        ?? step?.selectedStartNodeId ?? null;
  const currentNodeId      = step?.currentNodeId      ?? null;
  const activeNeighborId   = step?.activeNeighborId   ?? null;
  const activeEdgeId       = step?.activeEdgeId       ?? null;
  const queue              = step?.queue              ?? [];
  const recursionStack     = step?.recursionStack;            // array of nodeIds (DFS)
  const supportingStructure = step?.supportingStructure;      // object (Cycle Detection)
  const cycleEdgeId        = step?.cycleEdgeId        ?? null;
  const componentRootId    = step?.componentRootId    ?? null;
  const parentNodeId       = step?.parentNodeId       ?? null;
  const traversalOutput    = step?.traversalOutput    ?? [];
  const result             = step?.result;                    // undefined|null|bool
  const description        = step?.description        ?? '';

  // Distinguish algorithm from step data alone (no algorithm-ID checks)
  const isCycleDetection = step?.selectedStartNodeId !== undefined;
  const isDfs            = Array.isArray(recursionStack) && !supportingStructure;

  const { positions, svgW, svgH } = useMemo(
    () => computeLayout(nodes),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [nodes.map(n => n.id).join(',')],
  );

  return (
    <div className="flex flex-col bg-code-surface border-b border-border" style={{ minHeight: 280 }}>

      {/* Description */}
      <p
        aria-live="polite"
        aria-atomic="true"
        className="px-md py-xs text-body-sm text-text-secondary border-b border-border shrink-0"
      >
        {description}
      </p>

      {/* SVG graph canvas */}
      <div
        className="flex-1 overflow-auto scrollbar-thin"
        role="img"
        aria-label={`Graph with ${nodes.length} nodes`}
        style={{ minHeight: 200 }}
      >
        {nodes.length === 0 ? (
          <div className="flex items-center justify-center h-full py-8">
            <span className="text-body-md text-text-secondary italic">No graph loaded.</span>
          </div>
        ) : (
          <svg
            viewBox={`0 0 ${svgW} ${svgH}`}
            width={svgW}
            height={svgH}
            className="overflow-visible"
            aria-hidden
          >
            {/* Edges */}
            {edges.map(edge => {
              const pA = positions[edge.sourceId];
              const pB = positions[edge.targetId];
              const isSelfLoop = edge.sourceId === edge.targetId;
              const isCycleEdge = edge.id === cycleEdgeId;
              const isActive    = edge.id === activeEdgeId;

              // Self-loops: only render when they are the cycle edge
              if (isSelfLoop) {
                if (!isCycleEdge) return null;
                const p = positions[edge.sourceId];
                if (!p) return null;
                const ox = p.x + NODE_R * 0.65;
                const oy = p.y - NODE_R * 0.65;
                return (
                  <g key={edge.id}>
                    <path
                      d={`M ${ox} ${oy - 8}
                          C ${ox + 32} ${oy - 36}
                            ${ox + 36} ${oy + 12}
                            ${ox} ${oy + 10}`}
                      fill="none"
                      stroke="#FF526D"
                      strokeWidth={3}
                      strokeLinecap="round"
                    />
                    <text
                      x={ox + 30}
                      y={oy - 22}
                      textAnchor="middle"
                      fontSize={8}
                      fontFamily="sans-serif"
                      fontWeight="700"
                      fill="#FF526D"
                      letterSpacing="0.05em"
                    >
                      CYCLE
                    </text>
                  </g>
                );
              }

              if (!pA || !pB) return null;

              const edgeColor = isCycleEdge ? '#FF526D' : isActive ? '#FF6846' : '#244550';
              const edgeWidth = (isCycleEdge || isActive) ? 3 : 1.5;
              const edgeOpacity = (isCycleEdge || isActive) ? 1 : 0.7;

              return (
                <g key={edge.id}>
                  <line
                    x1={pA.x} y1={pA.y}
                    x2={pB.x} y2={pB.y}
                    stroke={edgeColor}
                    strokeWidth={edgeWidth}
                    strokeLinecap="round"
                    opacity={edgeOpacity}
                  />
                  {isCycleEdge && (
                    <text
                      x={(pA.x + pB.x) / 2}
                      y={(pA.y + pB.y) / 2 - 10}
                      textAnchor="middle"
                      fontSize={8}
                      fontFamily="sans-serif"
                      fontWeight="700"
                      fill="#FF526D"
                      letterSpacing="0.05em"
                    >
                      CYCLE
                    </text>
                  )}
                </g>
              );
            })}

            {/* Nodes */}
            {nodes.map(node => {
              const p    = positions[node.id];
              if (!p) return null;
              const style = nodeStyle(node.id, nodeStates, activeNeighborId, startNodeId, currentNodeId);
              const badge = stateBadge(
                node.id, nodeStates, startNodeId, currentNodeId, activeNeighborId,
                componentRootId, parentNodeId, isCycleDetection,
              );
              const isAct = node.id === currentNodeId || node.id === activeNeighborId;

              return (
                <g key={node.id} aria-label={`Node ${node.label}${badge ? ', ' + badge : ''}`}>
                  {style.ring && (
                    <circle
                      cx={p.x} cy={p.y} r={NODE_R + 5}
                      fill="none" stroke="#F6C453" strokeWidth={2} opacity={0.4}
                    />
                  )}
                  <circle
                    cx={p.x} cy={p.y} r={NODE_R}
                    fill={style.fill}
                    stroke={style.stroke}
                    strokeWidth={isAct ? 3 : 2}
                  />
                  <text
                    x={p.x} y={p.y}
                    textAnchor="middle"
                    dominantBaseline="central"
                    fontSize={13}
                    fontFamily="monospace"
                    fontWeight="700"
                    fill={style.text}
                  >
                    {node.label}
                  </text>
                  {badge && (
                    <text
                      x={p.x}
                      y={p.y - NODE_R - 6}
                      textAnchor="middle"
                      dominantBaseline="auto"
                      fontSize={badge.length > 7 ? 7 : 8}
                      fontFamily="sans-serif"
                      fontWeight="700"
                      fill={style.stroke}
                      letterSpacing="0.05em"
                    >
                      {badge}
                    </text>
                  )}
                </g>
              );
            })}
          </svg>
        )}
      </div>

      {/* Supporting panel — chosen from step data, not algorithm ID */}
      {supportingStructure
        ? <SupportingPanel structure={supportingStructure} nodes={nodes} />
        : isDfs
          ? <RecursionStack stack={recursionStack} nodes={nodes} />
          : <BfsQueue queue={queue} nodes={nodes} />
      }

      {/* Result panel (Cycle Detection) OR Output bar (BFS / DFS) */}
      {result !== undefined
        ? <ResultPanel result={result} cycleEdgeId={cycleEdgeId} edges={edges} nodes={nodes} />
        : <OutputBar output={traversalOutput} />
      }
    </div>
  );
}
