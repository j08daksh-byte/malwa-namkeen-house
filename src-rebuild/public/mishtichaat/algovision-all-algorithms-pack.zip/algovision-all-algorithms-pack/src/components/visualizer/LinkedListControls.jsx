/**
 * LinkedListControls — input panel for Linked List visualizer.
 *
 * Independent of StackControls and QueueControls.
 *
 * Props:
 *   initialValuesString  string   — pre-filled input content
 *   onLoadValues(values) function — called with parsed number[] on Apply
 *   onPause              function — called before loading when playing
 *   isPlaying            boolean  — playback state
 */

import { useState } from 'react';
import { parseListValues } from '../../lib/linkedListTraversal';

function randomValues() {
  const count  = Math.floor(Math.random() * 4) + 3; // 3–6 nodes
  const result = [];
  for (let i = 0; i < count; i++) {
    result.push(Math.floor(Math.random() * 90) + 10); // 10–99
  }
  return result.join(', ');
}

const EXAMPLES = [
  {
    label:    'Default list',
    desc:     '4-node list',
    sequence: '10, 20, 30, 40',
  },
  {
    label:    'Single node',
    desc:     'Only one node',
    sequence: '5',
  },
  {
    label:    'Empty list',
    desc:     'HEAD points to NULL',
    sequence: '',
  },
  {
    label:    'Duplicates & negatives',
    desc:     'Duplicates are allowed',
    sequence: '7, 7, -2, 99',
  },
];

export default function LinkedListControls({
  initialValuesString,
  onLoadValues,
  onPause,
  isPlaying,
}) {
  const [input,  setInput]  = useState(initialValuesString ?? '10, 20, 30, 40');
  const [error,  setError]  = useState('');

  // ── Apply ─────────────────────────────────────────────────────────────────

  function applyValues(seq) {
    if (isPlaying) onPause();
    const result = parseListValues(seq);
    if (result.error) {
      setError(result.error);
      return;
    }
    setError('');
    onLoadValues(result.values);
  }

  // ── Random ────────────────────────────────────────────────────────────────

  function handleRandom() {
    const seq = randomValues();
    setInput(seq);
    setError('');
    applyValues(seq);
  }

  return (
    <div className="flex flex-col gap-md overflow-y-auto p-md">

      {/* ── Values input ────────────────────────────────────────────────── */}
      <div className="flex flex-col gap-xs">
        <label
          htmlFor="ll-values-input"
          className="text-label-caps font-semibold text-text-secondary uppercase tracking-widest"
        >
          Node Values
        </label>
        <input
          id="ll-values-input"
          type="text"
          value={input}
          onChange={(e) => { setInput(e.target.value); setError(''); }}
          onKeyDown={(e) => { if (e.key === 'Enter') applyValues(input); }}
          aria-describedby="ll-values-help ll-values-error"
          placeholder="e.g. 10, 20, 30 (leave empty for empty list)"
          className={[
            'w-full rounded-lg bg-code-surface border font-mono text-code-md',
            'text-text-primary px-3 py-2',
            'focus:outline-none focus:ring-2 focus:ring-primary',
            'placeholder:text-text-secondary/50',
            error ? 'border-error' : 'border-border',
          ].join(' ')}
        />
        <p id="ll-values-help" className="text-body-sm text-text-secondary">
          Comma-separated integers (−99 to 999). Leave blank for an empty list. Max 15 nodes. Duplicates allowed.
        </p>
        {error && (
          <p id="ll-values-error" role="alert" className="text-body-sm text-error">
            {error}
          </p>
        )}

        {/* Action buttons */}
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => applyValues(input)}
            className={[
              'px-md py-xs rounded-lg text-label-caps font-semibold uppercase tracking-widest',
              'bg-primary text-background transition-colors duration-150',
              'hover:bg-primary/80 active:scale-95',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary',
            ].join(' ')}
          >
            Apply
          </button>
          <button
            onClick={handleRandom}
            className={[
              'px-md py-xs rounded-lg text-label-caps font-semibold uppercase tracking-widest',
              'bg-elevated border border-border text-text-primary transition-colors duration-150',
              'hover:border-primary hover:text-primary active:scale-95',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary',
            ].join(' ')}
          >
            Random
          </button>
          <button
            onClick={() => {
              setInput('');
              setError('');
              applyValues('');
            }}
            className={[
              'px-md py-xs rounded-lg text-label-caps font-semibold uppercase tracking-widest',
              'bg-elevated border border-border text-text-secondary transition-colors duration-150',
              'hover:border-border hover:text-text-primary active:scale-95',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary',
            ].join(' ')}
          >
            Empty List
          </button>
        </div>
      </div>

      {/* ── Examples ─────────────────────────────────────────────────────── */}
      <div className="flex flex-col gap-xs">
        <p className="text-label-caps font-semibold text-text-secondary uppercase tracking-widest">
          Examples
        </p>
        <div className="flex flex-col gap-xs">
          {EXAMPLES.map((ex) => (
            <button
              key={ex.label}
              onClick={() => {
                setInput(ex.sequence);
                setError('');
                applyValues(ex.sequence);
              }}
              className="flex flex-col items-start text-left rounded-lg border border-border bg-card
                         px-3 py-2 gap-0.5 hover:border-primary hover:bg-elevated/30
                         transition-colors duration-150 active:scale-[0.99]
                         focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
            >
              <span className="text-body-md font-semibold text-text-primary">{ex.label}</span>
              <span className="text-body-sm text-text-secondary">{ex.desc}</span>
              <span className="font-mono text-code-sm text-text-secondary/80 mt-0.5">
                {ex.sequence === '' ? '(empty)' : ex.sequence}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* ── Help ─────────────────────────────────────────────────────────── */}
      <div className="rounded-lg border border-border bg-code-surface px-3 py-2">
        <p className="text-body-sm text-text-secondary leading-relaxed">
          <span className="font-semibold text-text-primary">How it works:</span>{' '}
          Values are converted into a singly linked list where each node stores a value
          and a pointer to the next node. The visualizer then steps through the list
          from HEAD to NULL, simulating the traversal pointer.
        </p>
      </div>
    </div>
  );
}
