/**
 * StackCanvas
 *
 * Renders the current state of a Stack step.
 * Stack grows upward visually (bottom element at bottom of screen, top at top).
 *
 * Props:
 *   step   — current step object from generateStackSteps()
 *   legend — array of { state, color, label } (received but rendered in legend section)
 */

// ── Cell visual state ──────────────────────────────────────────────────────

function getCellState(i, step, stackLen) {
  if (!step || stackLen === 0) return 'default';
  const isTop  = i === stackLen - 1;
  const { type, activeIndex } = step;

  switch (type) {
    case 'push':
      return isTop ? 'push' : 'default';
    case 'pop-check':
      return isTop ? 'pop-highlight' : 'default';
    case 'pop':
      return 'default';
    case 'peek-check':
    case 'peek':
      return isTop ? 'peek' : 'default';
    case 'is-empty':
      return 'default';
    case 'underflow':
      return 'underflow';
    case 'completed':
      return isTop ? 'completed' : 'default';
    default:
      // operation-read, initial: highlight top in primary
      return isTop ? 'top' : 'default';
  }
}

const CELL_CLASSES = {
  default:       'bg-elevated border-border text-text-secondary',
  top:           'bg-card border-primary/40 text-text-primary',
  push:          'bg-secondary/20 border-secondary text-secondary',       // mint/teal — new element
  'pop-highlight': 'bg-error/15 border-error/60 text-error',             // about to pop
  peek:          'bg-tertiary/20 border-tertiary text-tertiary',          // amber — being peeked
  completed:     'bg-success/10 border-success/30 text-success',
  underflow:     'bg-error/10 border-error text-error',
};

// ── Operation label ────────────────────────────────────────────────────────

function operationLabel(step) {
  if (!step?.operation) return null;
  const { type, value } = step.operation;
  switch (type) {
    case 'push':     return `PUSH ${value}`;
    case 'pop':      return 'POP';
    case 'peek':     return 'PEEK';
    case 'is-empty': return 'IS EMPTY';
    default:         return null;
  }
}

// ── Result pill ────────────────────────────────────────────────────────────

function ResultPanel({ step }) {
  if (!step) return null;

  if (step.type === 'pop' && step.poppedValue != null) {
    return (
      <div className="flex items-center gap-xs px-md py-sm rounded-lg bg-error/10 border border-error/30">
        <span className="text-label-caps text-error uppercase tracking-widest font-semibold">Popped:</span>
        <span className="font-mono text-code-lg text-error font-bold">{step.poppedValue}</span>
      </div>
    );
  }

  if (step.type === 'peek' && step.peekedValue != null) {
    return (
      <div className="flex items-center gap-xs px-md py-sm rounded-lg bg-tertiary/10 border border-tertiary/30">
        <span className="text-label-caps text-tertiary uppercase tracking-widest font-semibold">Peeked:</span>
        <span className="font-mono text-code-lg text-tertiary font-bold">{step.peekedValue}</span>
      </div>
    );
  }

  if (step.type === 'is-empty' && step.result != null) {
    const isTrue = step.result;
    return (
      <div className={[
        'flex items-center gap-xs px-md py-sm rounded-lg border',
        isTrue ? 'bg-success/10 border-success/30' : 'bg-primary/10 border-primary/30',
      ].join(' ')}>
        <span className={[
          'text-label-caps uppercase tracking-widest font-semibold',
          isTrue ? 'text-success' : 'text-primary',
        ].join(' ')}>Is Empty:</span>
        <span className={[
          'font-mono text-code-lg font-bold',
          isTrue ? 'text-success' : 'text-primary',
        ].join(' ')}>{isTrue ? 'true' : 'false'}</span>
      </div>
    );
  }

  if (step.type === 'underflow') {
    const opLabel = step.errorState === 'peek' ? 'Peek' : 'Pop';
    return (
      <div
        className="flex items-center gap-xs px-md py-sm rounded-lg bg-error/10 border border-error"
        role="alert"
      >
        <span className="text-label-caps text-error uppercase tracking-widest font-semibold">
          ⚠ {opLabel} Underflow: stack is empty
        </span>
      </div>
    );
  }

  return null;
}

// ── Main component ─────────────────────────────────────────────────────────

export default function StackCanvas({ step }) {
  const stack    = step?.stack ?? [];
  const stackLen = stack.length;
  const isEmpty  = stackLen === 0;

  const opLabel = operationLabel(step);

  // Render stack top-to-bottom (reverse the bottom-indexed array)
  const reversed = [...stack].reverse(); // index 0 = visual top = array bottom stack[stackLen-1]

  return (
    <div className="flex-1 flex flex-col items-center justify-start gap-md p-md overflow-hidden min-h-0">

      {/* ── Operation info ─────────────────────────────────────────── */}
      <div className="w-full max-w-xs flex flex-col items-center gap-xs shrink-0">
        {opLabel && (
          <div className="px-md py-xs rounded-full bg-primary/10 border border-primary/20">
            <span className="font-mono text-code-md text-primary font-semibold tracking-widest">
              {opLabel}
            </span>
          </div>
        )}
        <p
          aria-live="polite"
          aria-atomic="true"
          className="text-body-md text-text-body text-center min-h-[1.5rem]"
        >
          {step?.description ?? ''}
        </p>
      </div>

      {/* ── Stack visual ───────────────────────────────────────────── */}
      <div className="flex flex-col items-center gap-0 flex-1 min-h-0 w-full max-w-xs">

        {isEmpty ? (
          /* ── Empty state ── */
          <div className="flex flex-col items-center justify-center flex-1 gap-md">
            <div
              className={[
                'w-20 h-20 rounded-xl border-2 border-dashed flex items-center justify-center',
                step?.type === 'underflow'
                  ? 'border-error/50 bg-error/5'
                  : 'border-border bg-elevated/40',
              ].join(' ')}
              aria-label="Empty stack"
            >
              <span className="text-label-caps text-text-secondary uppercase tracking-widest text-xs">
                Empty
              </span>
            </div>
            <span className="text-body-md text-text-secondary">Stack is empty</span>
          </div>
        ) : (
          <div className="flex flex-col items-center w-full overflow-y-auto min-h-0 max-h-full scrollbar-thin pb-2">

            {/* TOP marker */}
            <div
              className="flex items-center gap-xs mb-1 shrink-0"
              aria-hidden
            >
              <span className="text-label-caps text-primary font-bold uppercase tracking-widest text-xs">
                TOP
              </span>
              <span className="text-primary text-xs">↓</span>
            </div>

            {/* Stack cells — top to bottom */}
            {reversed.map((val, revIdx) => {
              const actualIdx = stackLen - 1 - revIdx; // original index in stack array
              const state     = getCellState(actualIdx, step, stackLen);
              const cellCls   = CELL_CLASSES[state] ?? CELL_CLASSES.default;
              const isTopCell = revIdx === 0;

              return (
                <div
                  key={actualIdx}
                  className={[
                    'w-20 h-14 flex items-center justify-center',
                    'font-mono text-code-lg font-semibold',
                    'border-x border-b transition-colors duration-200',
                    isTopCell ? 'border-t rounded-t-sm' : '',
                    revIdx === reversed.length - 1 ? 'rounded-b-sm' : '',
                    cellCls,
                  ].join(' ')}
                  aria-label={`Stack element ${val}${isTopCell ? ', top' : ''}`}
                >
                  {val}
                </div>
              );
            })}

            {/* BOTTOM label */}
            <div
              className="flex items-center gap-xs mt-1 shrink-0"
              aria-hidden
            >
              <span className="text-label-caps text-text-secondary uppercase tracking-widest text-xs">
                bottom
              </span>
            </div>
          </div>
        )}
      </div>

      {/* ── Result / underflow panel ────────────────────────────────── */}
      <div className="shrink-0 w-full max-w-xs">
        <ResultPanel step={step} />
      </div>

    </div>
  );
}
