/**
 * LinkedListMutateControls
 *
 * Controls for Insert and Delete node operations.
 * Props:
 *   mode          — 'insert' | 'delete'
 *   values        — number[]
 *   position      — number (insert only)
 *   newValue      — number (insert only)
 *   deleteIndex   — number (delete only)
 *   onValuesChange
 *   onPositionChange
 *   onNewValueChange
 *   onDeleteIndexChange
 *   onRun
 *   disabled
 */

import { useState } from 'react';

function parseValues(str) {
  const parts = str.split(',').map(s => s.trim()).filter(Boolean);
  if (!parts.length) return { valid: false, error: 'List cannot be empty.' };
  if (parts.length > 12) return { valid: false, error: 'Max 12 nodes allowed.' };
  const nums = [];
  for (const p of parts) {
    const n = Number(p);
    if (!Number.isInteger(n) || n < -999 || n > 999) {
      return { valid: false, error: 'Values must be integers from -999 to 999.' };
    }
    nums.push(n);
  }
  return { valid: true, value: nums };
}

export default function LinkedListMutateControls({
  mode = 'insert',
  values = [],
  position = 0,
  newValue = 0,
  deleteIndex = 0,
  onValuesChange,
  onPositionChange,
  onNewValueChange,
  onDeleteIndexChange,
  onRun,
  disabled = false,
}) {
  const [valStr, setValStr]     = useState(values.join(', '));
  const [posStr, setPosStr]     = useState(String(position));
  const [newValStr, setNewValStr] = useState(String(newValue));
  const [delIdxStr, setDelIdxStr] = useState(String(deleteIndex));
  const [error, setError]       = useState('');

  function handleRun() {
    const valResult = parseValues(valStr);
    if (!valResult.valid) { setError(valResult.error); return; }

    if (mode === 'insert') {
      const pos = parseInt(posStr, 10);
      if (!Number.isInteger(pos) || pos < 0 || pos > valResult.value.length) {
        setError(`Position must be 0 to ${valResult.value.length} (insert at end).`);
        return;
      }
      const nv = parseInt(newValStr, 10);
      if (!Number.isInteger(nv) || nv < -999 || nv > 999) {
        setError('New value must be an integer from -999 to 999.');
        return;
      }
      setError('');
      onValuesChange?.(valResult.value);
      onPositionChange?.(pos);
      onNewValueChange?.(nv);
    } else {
      const idx = parseInt(delIdxStr, 10);
      if (!Number.isInteger(idx) || idx < 0 || idx >= valResult.value.length) {
        setError(`Index must be 0 to ${valResult.value.length - 1}.`);
        return;
      }
      setError('');
      onValuesChange?.(valResult.value);
      onDeleteIndexChange?.(idx);
    }
    onRun?.();
  }

  return (
    <div className="flex flex-col gap-3">
      {/* List values */}
      <div className="flex flex-col gap-1">
        <label className="text-label-caps text-text-secondary uppercase tracking-widest text-[10px]">
          List Values (comma-separated)
        </label>
        <input
          className="input-field font-mono"
          type="text"
          value={valStr}
          onChange={e => { setValStr(e.target.value); setError(''); }}
          onKeyDown={e => e.key === 'Enter' && handleRun()}
          disabled={disabled}
          placeholder="e.g. 1, 2, 4, 5"
          aria-label="List values"
        />
      </div>

      {mode === 'insert' ? (
        <>
          {/* Position */}
          <div className="flex flex-col gap-1">
            <label className="text-label-caps text-text-secondary uppercase tracking-widest text-[10px]">
              Insert at Position (0-indexed)
            </label>
            <input
              className="input-field font-mono w-24"
              type="number"
              min={0}
              value={posStr}
              onChange={e => { setPosStr(e.target.value); setError(''); }}
              onKeyDown={e => e.key === 'Enter' && handleRun()}
              disabled={disabled}
              aria-label="Insert position"
            />
          </div>

          {/* New value */}
          <div className="flex flex-col gap-1">
            <label className="text-label-caps text-text-secondary uppercase tracking-widest text-[10px]">
              New Node Value
            </label>
            <input
              className="input-field font-mono w-24"
              type="number"
              min={-999}
              max={999}
              value={newValStr}
              onChange={e => { setNewValStr(e.target.value); setError(''); }}
              onKeyDown={e => e.key === 'Enter' && handleRun()}
              disabled={disabled}
              aria-label="New node value"
            />
          </div>
        </>
      ) : (
        /* Delete index */
        <div className="flex flex-col gap-1">
          <label className="text-label-caps text-text-secondary uppercase tracking-widest text-[10px]">
            Delete at Index (0-indexed)
          </label>
          <input
            className="input-field font-mono w-24"
            type="number"
            min={0}
            value={delIdxStr}
            onChange={e => { setDelIdxStr(e.target.value); setError(''); }}
            onKeyDown={e => e.key === 'Enter' && handleRun()}
            disabled={disabled}
            aria-label="Delete index"
          />
        </div>
      )}

      {error && <p className="text-error text-code-sm" role="alert">{error}</p>}

      <button className="btn-primary mt-1" onClick={handleRun} disabled={disabled}>
        Visualize
      </button>
    </div>
  );
}
