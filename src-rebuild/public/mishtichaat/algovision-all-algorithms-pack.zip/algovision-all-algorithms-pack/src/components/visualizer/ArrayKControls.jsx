/**
 * ArrayKControls
 *
 * Array + K (integer) input for Left Rotate by K.
 * Props: array, k, onArrayChange, onKChange, onRun, disabled, signed
 */

import { useState } from 'react';

function parseArray(str, signed = false) {
  const min = signed ? -100 : 1;
  const max = 100;
  const parts = str.split(',').map(s => s.trim()).filter(Boolean);
  if (!parts.length) return { valid: false, error: 'Array cannot be empty.' };
  const nums = [];
  for (const p of parts) {
    const n = Number(p);
    if (!Number.isInteger(n) || n < min || n > max) {
      return { valid: false, error: `Values must be integers from ${min} to ${max}.` };
    }
    nums.push(n);
  }
  if (nums.length > 20) return { valid: false, error: 'Maximum 20 elements allowed.' };
  return { valid: true, value: nums };
}

export default function ArrayKControls({
  array = [],
  k = 2,
  onArrayChange,
  onKChange,
  onRun,
  disabled = false,
  signed = false,
}) {
  const [arrStr, setArrStr] = useState(array.join(', '));
  const [kStr, setKStr]     = useState(String(k));
  const [error, setError]   = useState('');

  function handleRun() {
    const arrResult = parseArray(arrStr, signed);
    if (!arrResult.valid) { setError(arrResult.error); return; }
    const kVal = parseInt(kStr, 10);
    if (!Number.isInteger(kVal) || kVal < 0 || kVal > 100) {
      setError('K must be an integer from 0 to 100.');
      return;
    }
    setError('');
    onArrayChange?.(arrResult.value);
    onKChange?.(kVal);
    onRun?.();
  }

  return (
    <div className="flex flex-col gap-3">
      {/* Array input */}
      <div className="flex flex-col gap-1">
        <label className="text-label-caps text-text-secondary uppercase tracking-widest text-[10px]">
          Array (comma-separated{signed ? ', negatives OK' : ', 1–100'})
        </label>
        <input
          className="input-field font-mono"
          type="text"
          value={arrStr}
          onChange={e => { setArrStr(e.target.value); setError(''); }}
          onKeyDown={e => e.key === 'Enter' && handleRun()}
          disabled={disabled}
          placeholder="e.g. 1, 2, 3, 4, 5"
          aria-label="Array values"
        />
      </div>

      {/* K input */}
      <div className="flex flex-col gap-1">
        <label className="text-label-caps text-text-secondary uppercase tracking-widest text-[10px]">
          K (rotate left by)
        </label>
        <input
          className="input-field font-mono w-24"
          type="number"
          min={0}
          max={100}
          value={kStr}
          onChange={e => { setKStr(e.target.value); setError(''); }}
          onKeyDown={e => e.key === 'Enter' && handleRun()}
          disabled={disabled}
          aria-label="Rotate by K"
        />
      </div>

      {error && <p className="text-error text-code-sm" role="alert">{error}</p>}

      <button
        className="btn-primary mt-1"
        onClick={handleRun}
        disabled={disabled}
      >
        Visualize
      </button>
    </div>
  );
}
