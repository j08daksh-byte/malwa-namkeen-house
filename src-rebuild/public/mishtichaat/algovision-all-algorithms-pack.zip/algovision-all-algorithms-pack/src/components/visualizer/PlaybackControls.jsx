import {
  RotateCcw,
  SkipBack,
  Play,
  Pause,
  SkipForward,
  ChevronsRight,
} from 'lucide-react';
import Tooltip from '../ui/Tooltip';
import IconButton from '../ui/IconButton';

const SPEEDS = [0.25, 0.5, 1, 2, 4];

/**
 * PlaybackControls
 *
 * Props: player — the full object returned by useAlgorithmPlayer
 *
 * Layout (mobile-first):
 *   Row 1 — progress slider + step counter
 *   Row 2 — [Restart] [←|Play/Pause|→] [SkipEnd | Speed]
 */
export default function PlaybackControls({ player }) {
  const {
    stepIndex,
    steps,
    isPlaying,
    isComplete,
    speed,
    togglePlay,
    nextStep,
    previousStep,
    restart,
    skipToEnd,
    jumpToStep,
    setSpeed,
  } = player;

  const total = steps.length;
  const atStart = stepIndex === 0;
  const atEnd = total > 0 && stepIndex >= total - 1;

  return (
    <footer
      className="shrink-0 bg-nav border-t border-border pb-safe"
      aria-label="Playback controls"
    >
      {/* ── Row 1: Progress ───────────────────────────────────── */}
      <div className="flex items-center gap-sm px-md pt-sm">
        <span
          className="font-mono text-label-caps text-text-secondary shrink-0 w-28 text-right"
          aria-live="polite"
          aria-atomic="true"
        >
          {total > 0 ? `Step ${stepIndex + 1} of ${total}` : '—'}
        </span>

        <input
          type="range"
          min={0}
          max={Math.max(0, total - 1)}
          value={stepIndex}
          onChange={(e) => jumpToStep(Number(e.target.value))}
          disabled={total === 0}
          aria-label="Seek to step"
          className="flex-1 h-1.5 rounded-full appearance-none cursor-pointer bg-elevated accent-primary disabled:opacity-40 disabled:cursor-not-allowed"
        />
      </div>

      {/* ── Row 2: Controls ───────────────────────────────────── */}
      <div className="h-16 flex items-center justify-around px-md">

        {/* Restart */}
        <Tooltip label="Restart (R)">
          <IconButton
            shape="square"
            aria-label="Restart"
            onClick={restart}
            disabled={atStart}
          >
            <RotateCcw size={20} />
          </IconButton>
        </Tooltip>

        {/* Step cluster */}
        <div className="flex items-center gap-sm">
          <Tooltip label="Previous step (←)">
            <IconButton
              shape="square"
              aria-label="Previous step"
              onClick={previousStep}
              disabled={atStart}
              className="w-12 h-12 min-w-[48px] border border-border"
            >
              <SkipBack size={20} />
            </IconButton>
          </Tooltip>

          {/* Primary play / pause */}
          <Tooltip label={isPlaying ? 'Pause (Space)' : 'Play (Space)'}>
            <button
              onClick={togglePlay}
              disabled={atEnd && !isPlaying}
              aria-label={isPlaying ? 'Pause' : 'Play'}
              className={[
                'w-16 h-16 rounded-xl flex items-center justify-center shrink-0',
                'transition-all duration-150 active:scale-95 select-none',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background',
                'shadow-lg disabled:opacity-40 disabled:pointer-events-none',
                isPlaying
                  ? 'bg-tertiary text-background shadow-tertiary/20'
                  : 'bg-primary  text-background shadow-primary/20',
              ].join(' ')}
            >
              {isPlaying
                ? <Pause size={28} fill="currentColor" aria-hidden />
                : <Play  size={28} fill="currentColor" aria-hidden />
              }
            </button>
          </Tooltip>

          <Tooltip label="Next step (→)">
            <IconButton
              shape="square"
              aria-label="Next step"
              onClick={nextStep}
              disabled={atEnd}
              className="w-12 h-12 min-w-[48px] border border-border"
            >
              <SkipForward size={20} />
            </IconButton>
          </Tooltip>
        </div>

        {/* Right cluster: Skip to end + Speed */}
        <div className="flex items-center gap-xs">
          <Tooltip label="Skip to end">
            <IconButton
              shape="square"
              aria-label="Skip to end"
              onClick={skipToEnd}
              disabled={atEnd}
            >
              <ChevronsRight size={20} />
            </IconButton>
          </Tooltip>

          {/* Speed selector */}
          <div className="relative">
            <select
              value={speed}
              onChange={(e) => setSpeed(Number(e.target.value))}
              aria-label="Playback speed"
              className={[
                'h-11 pl-sm pr-6 rounded text-label-caps font-semibold',
                'bg-elevated border border-border text-text-body',
                'appearance-none cursor-pointer',
                'focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary',
                'transition-colors duration-150',
              ].join(' ')}
            >
              {SPEEDS.map((s) => (
                <option key={s} value={s}>
                  {s}×
                </option>
              ))}
            </select>
            {/* Custom dropdown arrow */}
            <span className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-text-secondary text-xs">
              ▾
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
