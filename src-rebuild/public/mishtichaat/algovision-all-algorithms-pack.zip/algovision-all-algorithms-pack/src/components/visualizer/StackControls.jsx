/**
 * StackControls
 *
 * Controls panel for Stack Operations.
 * Parses an operation sequence string and calls onLoadOps with the
 * normalized array of operations on a successful apply.
 *
 * Props:
 *   initialOpsString — starting sequence string shown in the input
 *   onLoadOps        — (ops: [{type, value?}][]) => void
 *   onPause          — () => void
 *   isPlaying        — boolean
 */

import { useState } from 'react';
import { RotateCcw, Play, AlertCircle, Info } from 'lucide-react';
import Button from '../ui/Button';
import { parseOperations, DEFAULT_STACK_OPS_STRING } from '../../lib/stackOperations';

const EXAMPLE_SEQUENCES = [
  {
    label: 'Underflow demo',
    value: 'pop, push 5, peek',
    description: 'Demonstrates underflow on an empty stack',
  },
  {
    label: 'isEmpty demo',
    value: 'isEmpty, push 8, isEmpty',
    description: 'Shows isEmpty returning true then false',
  },
  {
    label: 'Full sequence',
    value: 'push 10, push 20, peek, pop, push 30, isEmpty',
    description: 'Default: push, peek, pop, and isEmpty',
  },
];

export default function StackControls({
  initialOpsString = DEFAULT_STACK_OPS_STRING,
  onLoadOps,
  onPause,
  isPlaying,
}) {
  const [input,      setInput]      = useState(initialOpsString);
  const [error,      setError]      = useState('');
  const [pushValue,  setPushValue]  = useState('');
  const [pushError,  setPushError]  = useState('');

  // ── Apply sequence ────────────────────────────────────────────────────────

  function applySequence(seq = input) {
    const result = parseOperations(seq);
    if (result.error) {
      setError(result.error);
      return false;
    }
    setError('');
    if (isPlaying) onPause();
    onLoadOps(result.ops);
    return true;
  }

  // ── Quick-action helpers ──────────────────────────────────────────────────

  function appendOp(opStr) {
    const next = input.trim()
      ? input.trim() + ', ' + opStr
      : opStr;
    setInput(next);
    setError('');
  }

  function handleQuickPush() {
    const n = Number(pushValue);
    if (!pushValue.trim() || isNaN(n) || !Number.isInteger(n) || n < -99 || n > 999) {
      setPushError('Enter an integer between -99 and 999.');
      return;
    }
    setPushError('');
    appendOp(`push ${n}`);
  }

  function handleReset() {
    setInput(DEFAULT_STACK_OPS_STRING);
    setError('');
    setPushValue('');
    setPushError('');
    if (isPlaying) onPause();
    const result = parseOperations(DEFAULT_STACK_OPS_STRING);
    if (!result.error) onLoadOps(result.ops);
  }

  return (
    <div className="flex-1 overflow-y-auto scrollbar-thin p-md flex flex-col gap-lg">

      {/* ── Operation sequence input ─────────────────────────────────── */}
      <div className="flex flex-col gap-sm">
        <label
          htmlFor="stack-ops-input"
          className="text-label-caps text-text-secondary uppercase tracking-widest"
        >
          Operation Sequence (max 30 operations)
        </label>

        <textarea
          id="stack-ops-input"
          value={input}
          onChange={e => { setInput(e.target.value); if (error) setError(''); }}
          onKeyDown={e => {
            if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); applySequence(); }
          }}
          placeholder="push 10, push 20, peek, pop, isEmpty"
          rows={3}
          aria-describedby={[
            'stack-ops-help',
            error ? 'stack-ops-error' : '',
          ].filter(Boolean).join(' ')}
          aria-invalid={!!error}
          className={[
            'w-full rounded px-md py-sm font-mono text-code-md resize-none',
            'bg-code-surface text-text-primary placeholder:text-text-secondary',
            'transition-colors duration-150 focus:outline-none focus:ring-1',
            error
              ? 'border border-error focus:border-error focus:ring-error/30'
              : 'border border-border hover:border-text-secondary focus:border-primary focus:ring-primary',
          ].join(' ')}
        />

        <p id="stack-ops-help" className="text-body-md text-text-secondary">
          Format: <span className="font-mono">push &lt;value&gt;</span>,{' '}
          <span className="font-mono">pop</span>,{' '}
          <span className="font-mono">peek</span>,{' '}
          <span className="font-mono">isEmpty</span> — comma-separated.
        </p>

        {error && (
          <div
            id="stack-ops-error"
            role="alert"
            className="flex items-start gap-xs text-body-md text-error"
          >
            <AlertCircle size={14} className="shrink-0 mt-0.5" aria-hidden />
            {error}
          </div>
        )}

        <div className="flex gap-sm">
          <Button
            onClick={() => applySequence()}
            className="flex-1 justify-center gap-2"
          >
            <Play size={14} aria-hidden />
            Apply
          </Button>
          <Button
            variant="ghost"
            onClick={handleReset}
            className="border border-border gap-2"
            aria-label="Reset to default sequence"
          >
            <RotateCcw size={14} aria-hidden />
            Reset
          </Button>
        </div>
      </div>

      {/* ── Quick actions ─────────────────────────────────────────────── */}
      <div className="flex flex-col gap-sm">
        <span className="text-label-caps text-text-secondary uppercase tracking-widest">
          Quick Actions
        </span>

        {/* Push with value input */}
        <div className="flex gap-sm">
          <div className="flex flex-col gap-xs flex-1">
            <input
              type="number"
              value={pushValue}
              onChange={e => { setPushValue(e.target.value); if (pushError) setPushError(''); }}
              onKeyDown={e => { if (e.key === 'Enter') handleQuickPush(); }}
              placeholder="-99 to 999"
              aria-label="Value for push operation"
              aria-describedby={pushError ? 'push-error' : undefined}
              aria-invalid={!!pushError}
              className={[
                'h-11 rounded px-md font-mono text-code-md',
                'bg-code-surface text-text-primary placeholder:text-text-secondary',
                'focus:outline-none focus:ring-1 transition-colors',
                '[appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none',
                pushError
                  ? 'border border-error focus:ring-error/30'
                  : 'border border-border hover:border-text-secondary focus:border-primary focus:ring-primary',
              ].join(' ')}
            />
            {pushError && (
              <p id="push-error" role="alert" className="text-body-md text-error flex items-center gap-xs">
                <AlertCircle size={12} aria-hidden /> {pushError}
              </p>
            )}
          </div>
          <Button
            onClick={handleQuickPush}
            variant="secondary"
            className="shrink-0 h-11"
            aria-label="Add push operation to sequence"
          >
            + Push
          </Button>
        </div>

        {/* Pop / Peek / isEmpty buttons */}
        <div className="grid grid-cols-3 gap-sm">
          {[
            { label: '+ Pop',     op: 'pop'     },
            { label: '+ Peek',    op: 'peek'    },
            { label: '+ isEmpty', op: 'isEmpty' },
          ].map(({ label, op }) => (
            <Button
              key={op}
              variant="ghost"
              onClick={() => appendOp(op)}
              className="border border-border justify-center text-xs"
              aria-label={`Add ${op} operation to sequence`}
            >
              {label}
            </Button>
          ))}
        </div>
      </div>

      {/* ── Load example ─────────────────────────────────────────────── */}
      <div className="flex flex-col gap-sm">
        <span className="text-label-caps text-text-secondary uppercase tracking-widest">
          Load Example
        </span>
        {EXAMPLE_SEQUENCES.map(ex => (
          <button
            key={ex.label}
            onClick={() => {
              setInput(ex.value);
              setError('');
              applySequence(ex.value);
            }}
            className={[
              'text-left px-md py-sm rounded border border-border',
              'bg-card hover:bg-elevated transition-colors duration-150',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary',
            ].join(' ')}
          >
            <p className="text-body-md font-semibold text-text-primary">{ex.label}</p>
            <p className="font-mono text-code-md text-text-secondary truncate mt-0.5">{ex.value}</p>
          </button>
        ))}
      </div>

      {/* ── Tips ─────────────────────────────────────────────────────── */}
      <div className="bg-card rounded-lg border border-border p-md flex flex-col gap-xs">
        <p className="text-label-caps text-text-secondary uppercase tracking-widest mb-xs">Tips</p>
        <div className="flex items-start gap-xs text-body-md text-text-body">
          <Info size={13} className="shrink-0 mt-0.5 text-secondary" aria-hidden />
          <span>Try <span className="font-mono">pop</span> on an empty stack to see underflow handling.</span>
        </div>
        <ul className="text-body-md text-text-body space-y-xs list-none mt-xs">
          <li>• Enter <span className="font-mono">Enter</span> or click Apply to load the sequence.</li>
          <li>• Use quick-action buttons to build the sequence step by step.</li>
          <li>• Language switching in Code tab does not reset playback.</li>
        </ul>
      </div>
    </div>
  );
}
