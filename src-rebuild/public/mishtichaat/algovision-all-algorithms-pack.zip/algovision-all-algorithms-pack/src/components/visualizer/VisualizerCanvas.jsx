/**
 * VisualizerCanvas
 *
 * Renders the algorithm bar chart and a dynamic state legend.
 *
 * Props:
 *   step   — current step object (or null while loading)
 *   legend — array of { state, color, label } entries from the algorithm registry
 *
 * Bar state priority (high → low):
 *   completed > swapping > comparing > active > sorted > default
 *
 * The `comparing` > `sorted` ordering is intentional: in Insertion Sort the
 * sorted section is scanned backwards, so those bars should light up yellow
 * (comparing) rather than staying green (sorted) during the comparison step.
 */

const BAR_STYLE = {
  default:   { bg: 'bg-elevated',   glow: '',                                          label: 'text-text-secondary' },
  active:    { bg: 'bg-secondary',  glow: 'shadow-[0_0_10px_rgba(53,208,186,0.4)]',   label: 'text-background'     },
  comparing: { bg: 'bg-tertiary',   glow: 'shadow-[0_0_10px_rgba(246,196,83,0.4)]',   label: 'text-background'     },
  swapping:  { bg: 'bg-error',      glow: 'shadow-[0_0_12px_rgba(255,82,109,0.45)]',  label: 'text-background'     },
  sorted:    { bg: 'bg-success',    glow: '',                                          label: 'text-background'     },
  completed: { bg: 'bg-success',    glow: '',                                          label: 'text-background'     },
};

const DEFAULT_LEGEND = [
  { state: 'default',   color: 'bg-elevated', label: 'Unsorted'  },
  { state: 'comparing', color: 'bg-tertiary', label: 'Comparing' },
  { state: 'swapping',  color: 'bg-error',    label: 'Swapping'  },
  { state: 'sorted',    color: 'bg-success',  label: 'Sorted'    },
];

function getBarState(index, step) {
  if (!step) return 'default';
  if (step.type === 'completed') return 'completed';
  if (step.swapping?.includes(index)) return 'swapping';
  if (step.comparing?.includes(index)) return 'comparing';
  if (step.active?.includes(index)) return 'active';
  if (step.sorted?.includes(index)) return 'sorted';
  return 'default';
}

function barHeight(value, maxValue) {
  if (!value || !maxValue) return 8;
  return Math.round(8 + (value / maxValue) * 88);
}

export default function VisualizerCanvas({ step, legend = DEFAULT_LEGEND }) {
  const array = step?.array ?? [40, 65, 25, 80, 55, 35, 90, 15];
  const maxValue = Math.max(...array);

  const reducedMotion =
    typeof window !== 'undefined' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const transitionClass = reducedMotion ? '' : 'transition-all duration-300 ease-in-out';

  return (
    <section
      className="flex-[1.2] canvas-dot-grid relative flex flex-col items-center justify-center px-lg pt-12 pb-4 bg-background"
      aria-label="Algorithm visualisation canvas"
    >
      {/* ── Step description badge ──────────────────────────────────── */}
      <div
        className="absolute top-4 left-4 right-4 flex items-center gap-2 bg-nav/90 backdrop-blur-sm px-sm py-1.5 rounded-lg border border-border max-w-full"
        aria-hidden="true"
      >
        <span
          className={[
            'w-2 h-2 shrink-0 rounded-full',
            step?.type === 'completed' ? 'bg-success' :
            step?.type === 'swapping'  ? 'bg-error animate-pulse' :
            step?.type === 'shifting'  ? 'bg-error animate-pulse' :
            step?.type === 'comparing' ? 'bg-tertiary animate-pulse' :
            step?.type === 'active'    ? 'bg-secondary animate-pulse' :
            'bg-secondary',
          ].join(' ')}
        />
        <p className="font-mono text-code-md text-text-body truncate">
          {step?.description ?? 'Loading…'}
        </p>
      </div>

      {/* ── Bars ────────────────────────────────────────────────────── */}
      <div
        className="w-full max-w-md h-48 flex items-end justify-center gap-1"
        role="img"
        aria-label={`Bar chart of ${array.length} elements`}
      >
        {array.map((value, i) => {
          const state = getBarState(i, step);
          const { bg, glow, label } = BAR_STYLE[state];
          const h = barHeight(value, maxValue);
          const showLabel = array.length <= 16;

          return (
            <div
              key={i}
              className={[
                'relative flex-1 rounded-t-sm flex flex-col justify-start items-center pt-1 min-w-0',
                bg,
                glow,
                transitionClass,
              ].join(' ')}
              style={{ height: `${h}%` }}
            >
              {showLabel && (
                <span
                  className={[
                    'font-mono text-[10px] font-semibold leading-none select-none',
                    h > 20 ? label : 'text-text-secondary absolute -top-4',
                  ].join(' ')}
                  aria-hidden
                >
                  {value}
                </span>
              )}
            </div>
          );
        })}
      </div>

      {/* ── Legend ──────────────────────────────────────────────────── */}
      <div
        className="mt-4 flex flex-wrap justify-center gap-x-6 gap-y-2"
        aria-label="Colour state legend"
      >
        {legend.map(({ color, label }) => (
          <div key={label} className="flex items-center gap-2">
            <span className={['w-3 h-3 rounded-full shrink-0', color].join(' ')} aria-hidden />
            <span className="text-label-caps text-text-body">{label}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
