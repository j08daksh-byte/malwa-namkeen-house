import { useEffect, useRef } from 'react';

const INDENT_CLASS = ['', 'pl-5', 'pl-10', 'pl-[3.75rem]'];

/**
 * PseudocodePanel
 *
 * Props:
 *   lines      — array of { text, indent } from the algorithm registry
 *   activeLine — 0-based index of the currently active line
 */
export default function PseudocodePanel({ lines = [], activeLine }) {
  const activeRef = useRef(null);

  // Auto-scroll active line into view
  useEffect(() => {
    if (activeRef.current) {
      activeRef.current.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
  }, [activeLine]);

  return (
    <div className="flex-1 overflow-y-auto scrollbar-thin bg-code-surface p-md font-mono">
      <p className="text-label-caps text-text-secondary uppercase tracking-widest mb-sm">
        Pseudocode
      </p>
      <div className="space-y-0">
        {lines.map((line, i) => {
          const isActive = i === activeLine;
          return (
            <div
              key={i}
              ref={isActive ? activeRef : null}
              className={[
                'flex gap-3 py-0.5 leading-relaxed rounded-r',
                isActive
                  ? 'code-line-active -mx-md px-md'
                  : 'opacity-60',
              ].join(' ')}
            >
              <span
                className={[
                  'w-4 text-right shrink-0 text-code-md select-none',
                  isActive ? 'text-secondary font-semibold' : 'text-text-secondary',
                ].join(' ')}
              >
                {i + 1}
              </span>
              <span
                className={[
                  'text-code-md',
                  INDENT_CLASS[Math.min(line.indent, INDENT_CLASS.length - 1)] ?? '',
                  isActive ? 'text-secondary font-semibold' : 'text-text-body',
                ].join(' ')}
              >
                {line.text}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
