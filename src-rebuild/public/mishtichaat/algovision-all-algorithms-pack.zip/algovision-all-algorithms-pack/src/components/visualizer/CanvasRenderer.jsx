import VisualizerCanvas from './VisualizerCanvas.jsx';
import SearchCanvas from './SearchCanvas.jsx';
import TwoPointerCanvas from './TwoPointerCanvas.jsx';
import StackCanvas from './StackCanvas.jsx';
import QueueCanvas from './QueueCanvas.jsx';
import LinkedListCanvas from './LinkedListCanvas.jsx';
import LinkedListCycleCanvas from './LinkedListCycleCanvas.jsx';
import GraphCanvas from './GraphCanvas.jsx';
import BinaryTreeCanvas from './BinaryTreeCanvas.jsx';
import ArrayInspectCanvas from './ArrayInspectCanvas.jsx';
import ArrayMapCanvas from './ArrayMapCanvas.jsx';
import ArrayStackCanvas from './ArrayStackCanvas.jsx';
import CircularQueueCanvas from './CircularQueueCanvas.jsx';
import DualStackCanvas from './DualStackCanvas.jsx';

export default function CanvasRenderer({ algorithm, step }) {
  const props = { step, legend: algorithm?.legend ?? [] };

  switch (algorithm?.visualizationType) {
    case 'sorting':
      return <VisualizerCanvas {...props} />;
    case 'searching':
      return <SearchCanvas {...props} />;
    case 'two-pointers':
      return <TwoPointerCanvas {...props} />;
    case 'stack':
      return <StackCanvas {...props} />;
    case 'queue':
      return <QueueCanvas {...props} />;
    case 'linked-list':
      return <LinkedListCanvas {...props} />;
    case 'linked-list-cycle':
      return <LinkedListCycleCanvas {...props} />;
    case 'graph':
      return <GraphCanvas {...props} />;
    case 'binary-tree':
      return <BinaryTreeCanvas {...props} />;
    case 'array-inspect':
      return <ArrayInspectCanvas {...props} />;
    case 'array-map':
      return <ArrayMapCanvas {...props} />;
    case 'array-stack':
      return <ArrayStackCanvas {...props} />;
    case 'circular-queue':
      return <CircularQueueCanvas {...props} />;
    case 'dual-stack':
      return <DualStackCanvas {...props} />;
    default:
      return (
        <div className="min-h-[280px] flex items-center justify-center text-text-secondary">
          No renderer is registered for {algorithm?.visualizationType ?? 'this algorithm'}.
        </div>
      );
  }
}
