/**
 * LinkedListCycleCanvas
 *
 * SVG-based linked-list visualization that draws a curved "cycle" edge
 * back to the cycle entry node when hasCycle is true.
 *
 * Step fields:
 *   step.nodes          — [{ id, value, nextId }]
 *   step.headId         — id of head node
 *   step.slowNodeId     — SLOW pointer (primary/coral)
 *   step.fastNodeId     — FAST pointer (tertiary/yellow)
 *   step.meetingNodeId  — where they met (secondary/teal, blinks)
 *   step.cycleNodeId    — cycle entry (error/red border)
 *   step.cycleEdgeId    — 'cycle-{tailId}-{entryId}'
 *   step.hasCycle       — bool
 *   step.description
 */

const PALETTE = {
  background: '#08141A',
  elevated:   '#18333E',
  border:     '#244550',
  primary:    '#FF6846',
  secondary:  '#35D0BA',
  tertiary:   '#F6C453',
  error:      '#FF526D',
  success:    '#39D98A',
  textPrimary:'#e2edf0',
  textSecondary:'#8aa4ad',
};

const NODE_R    = 22;
const NODE_GAP  = 72; // center-to-center horizontal
const ARROW_SZ  = 6;

function arrowHead(x, y, dirAngle) {
  const ax = x - ARROW_SZ * Math.cos(dirAngle);
  const ay = y - ARROW_SZ * Math.sin(dirAngle);
  const lx = ax + ARROW_SZ * 0.5 * Math.cos(dirAngle + Math.PI / 2);
  const ly = ay + ARROW_SZ * 0.5 * Math.sin(dirAngle + Math.PI / 2);
  const rx = ax + ARROW_SZ * 0.5 * Math.cos(dirAngle - Math.PI / 2);
  const ry = ay + ARROW_SZ * 0.5 * Math.sin(dirAngle - Math.PI / 2);
  return `M ${x} ${y} L ${lx} ${ly} L ${rx} ${ry} Z`;
}

export default function LinkedListCycleCanvas({ step }) {
  const nodes        = step?.nodes ?? [];
  const headId       = step?.headId ?? null;
  const slowId       = step?.slowNodeId ?? null;
  const fastId       = step?.fastNodeId ?? null;
  const meetId       = step?.meetingNodeId ?? null;
  const cycleNodeId  = step?.cycleNodeId ?? null;
  const cycleEdgeId  = step?.cycleEdgeId ?? null;
  const hasCycle     = step?.hasCycle ?? false;

  if (!nodes.length) {
    return (
      <section className="flex-[1.2] canvas-dot-grid flex items-center justify-center bg-background text-text-secondary text-code-sm">
        No nodes to display.
      </section>
    );
  }

  // Build ordered list starting from headId
  const nodeMap = Object.fromEntries(nodes.map(n => [n.id, n]));
  const ordered = [];
  const seen = new Set();
  let cur = headId;
  while (cur && !seen.has(cur)) {
    const n = nodeMap[cur];
    if (!n) break;
    ordered.push(n);
    seen.add(cur);
    cur = n.nextId;
  }
  // If any nodes weren't reached (shouldn't happen), append
  nodes.forEach(n => { if (!seen.has(n.id)) ordered.push(n); });

  const count = ordered.length;
  const nodeIndex = Object.fromEntries(ordered.map((n, i) => [n.id, i]));

  // SVG layout — horizontal row
  const PADDING = 40;
  const SVG_W = PADDING * 2 + (count - 1) * NODE_GAP + NODE_R * 2;
  const NORMAL_Y = 70;
  const SVG_H = 200;

  // Node center positions
  function cx(i) { return PADDING + NODE_R + i * NODE_GAP; }
  const cy = NORMAL_Y;

  // Parse cycleEdgeId → tailId + entryId
  let cycleTailId = null;
  let cycleEntryId = null;
  if (cycleEdgeId) {
    const parts = cycleEdgeId.replace(/^cycle-/, '').split('-');
    // format: cycle-{tailId}-{entryId}, IDs are like n1, n2, etc.
    // So after removing 'cycle-' prefix we split by '-' but IDs have 'n' prefix
    // Re-parse: "cycle-n3-n1" → parts after removing prefix = ["n3", "n1"]
    const raw = cycleEdgeId.slice('cycle-'.length);
    const match = raw.match(/^(n\d+)-(n\d+)$/);
    if (match) {
      cycleTailId  = match[1];
      cycleEntryId = match[2];
    }
  }

  // Node fill/stroke based on role
  function nodeStyle(id) {
    if (id === meetId)      return { fill: PALETTE.secondary, stroke: PALETTE.secondary, textFill: PALETTE.background };
    if (id === fastId && id === slowId) return { fill: PALETTE.error, stroke: PALETTE.error, textFill: PALETTE.background };
    if (id === fastId)      return { fill: PALETTE.tertiary,  stroke: PALETTE.tertiary,  textFill: PALETTE.background };
    if (id === slowId)      return { fill: PALETTE.primary,   stroke: PALETTE.primary,   textFill: PALETTE.background };
    if (id === cycleNodeId) return { fill: PALETTE.elevated,  stroke: PALETTE.error,     textFill: PALETTE.error };
    return { fill: PALETTE.elevated, stroke: PALETTE.border, textFill: PALETTE.textPrimary };
  }

  // Pointer labels (ordered priority: MEET > FAST+SLOW > FAST > SLOW > ENTRY)
  function pointerLabel(id) {
    const labels = [];
    if (id === meetId)      labels.push('MEET');
    if (id === slowId)      labels.push('SLW');
    if (id === fastId)      labels.push('FST');
    if (id === cycleNodeId && id !== meetId) labels.push('ENTRY');
    return labels.join('/');
  }

  return (
    <section
      className="flex-[1.2] canvas-dot-grid relative flex flex-col items-center justify-start px-md pt-12 pb-4 bg-background overflow-x-auto overflow-y-auto"
      aria-label="Linked list cycle detection visualization"
    >
      {/* Description badge */}
      <div
        className="absolute top-4 left-4 right-4 flex items-center gap-2 bg-nav/90 backdrop-blur-sm px-sm py-1.5 rounded-lg border border-border"
        aria-hidden
      >
        <span className={[
          'w-2 h-2 shrink-0 rounded-full',
          step?.type === 'completed' ? 'bg-success' :
          step?.type === 'cycle-found' ? 'bg-error animate-pulse' :
          step?.type === 'no-cycle' ? 'bg-success' :
          step?.type === 'move' ? 'bg-tertiary animate-pulse' :
          'bg-secondary animate-pulse',
        ].join(' ')} />
        <p className="font-mono text-code-md text-text-body truncate">
          {step?.description ?? 'Loading…'}
        </p>
      </div>

      {/* Cycle/no-cycle badge */}
      {(step?.type === 'cycle-found' || step?.type === 'no-cycle' || step?.type === 'completed') && (
        <div className={[
          'mt-2 px-md py-sm rounded-lg border flex items-center gap-2',
          hasCycle ? 'bg-error/10 border-error/30' : 'bg-success/10 border-success/30',
        ].join(' ')}>
          <span className={['w-2 h-2 rounded-full', hasCycle ? 'bg-error animate-pulse' : 'bg-success'].join(' ')} />
          <span className={['font-bold text-code-md', hasCycle ? 'text-error' : 'text-success'].join(' ')}>
            {hasCycle ? 'Cycle Detected' : 'No Cycle'}
          </span>
          {hasCycle && cycleNodeId && (
            <span className="text-text-secondary text-code-sm">
              — Entry: {nodeMap[cycleNodeId]?.value ?? cycleNodeId}
            </span>
          )}
        </div>
      )}

      {/* SVG list */}
      <svg
        width={SVG_W}
        height={SVG_H}
        viewBox={`0 0 ${SVG_W} ${SVG_H}`}
        className="mt-4 max-w-full"
        aria-label="Linked list nodes"
        overflow="visible"
      >
        <defs>
          <marker id="arrowhead" markerWidth={ARROW_SZ} markerHeight={ARROW_SZ} refX={ARROW_SZ} refY={ARROW_SZ / 2} orient="auto">
            <polygon points={`0 0, ${ARROW_SZ} ${ARROW_SZ / 2}, 0 ${ARROW_SZ}`} fill={PALETTE.border} />
          </marker>
          <marker id="arrowhead-cycle" markerWidth={ARROW_SZ} markerHeight={ARROW_SZ} refX={ARROW_SZ} refY={ARROW_SZ / 2} orient="auto">
            <polygon points={`0 0, ${ARROW_SZ} ${ARROW_SZ / 2}, 0 ${ARROW_SZ}`} fill={PALETTE.error} />
          </marker>
        </defs>

        {/* Normal forward edges */}
        {ordered.map((node, i) => {
          if (!node.nextId) return null;
          const nextIdx = nodeIndex[node.nextId];
          if (nextIdx === undefined) return null;

          // Skip the cycle edge (drawn separately below)
          if (cycleTailId === node.id && cycleEntryId === node.nextId) return null;

          // next is to the right
          const x1 = cx(i) + NODE_R;
          const x2 = cx(nextIdx) - NODE_R;
          const midX = (x1 + x2) / 2;

          return (
            <g key={node.id + '-edge'}>
              <line
                x1={x1} y1={cy}
                x2={x2 - ARROW_SZ} y2={cy}
                stroke={PALETTE.border}
                strokeWidth={1.5}
                markerEnd="url(#arrowhead)"
              />
            </g>
          );
        })}

        {/* Cycle edge — curved arc going below */}
        {hasCycle && cycleTailId && cycleEntryId && (
          (() => {
            const tailIdx  = nodeIndex[cycleTailId];
            const entryIdx = nodeIndex[cycleEntryId];
            if (tailIdx === undefined || entryIdx === undefined) return null;

            const x1 = cx(tailIdx);
            const x2 = cx(entryIdx);
            const arcDepth = 60; // how far down the arc goes
            const cpY = cy + NODE_R + arcDepth;

            const dx = x2 - x1;
            const dy = (cpY - cy);
            const endAngle = Math.atan2(cy - cpY, x2 - x1);

            // Quadratic bezier from bottom of tail to bottom of entry
            const startX = x1;
            const startY = cy + NODE_R;
            const endX   = x2;
            const endY   = cy + NODE_R;
            const cpX    = (x1 + x2) / 2;

            return (
              <g key="cycle-edge">
                <path
                  d={`M ${startX} ${startY} Q ${cpX} ${cpY + 20} ${endX} ${endY}`}
                  fill="none"
                  stroke={PALETTE.error}
                  strokeWidth={2}
                  strokeDasharray="5 3"
                  markerEnd="url(#arrowhead-cycle)"
                />
                {/* "CYCLE" label at midpoint of arc */}
                <text
                  x={cpX}
                  y={cpY + 36}
                  textAnchor="middle"
                  fontSize={9}
                  fontWeight="700"
                  fill={PALETTE.error}
                  letterSpacing="2"
                >
                  CYCLE
                </text>
              </g>
            );
          })()
        )}

        {/* NULL tail if no cycle */}
        {!hasCycle && ordered.length > 0 && (() => {
          const last = ordered[ordered.length - 1];
          if (!last.nextId) {
            const lastX = cx(ordered.length - 1) + NODE_R;
            return (
              <g>
                <line x1={lastX} y1={cy} x2={lastX + 28} y2={cy} stroke={PALETTE.border} strokeWidth={1.5} markerEnd="url(#arrowhead)" />
                <text x={lastX + 32} y={cy + 4} fontSize={10} fill={PALETTE.textSecondary} fontFamily="monospace">NULL</text>
              </g>
            );
          }
        })()}

        {/* Nodes */}
        {ordered.map((node, i) => {
          const style = nodeStyle(node.id);
          const label = pointerLabel(node.id);
          const isHead = node.id === headId;

          return (
            <g key={node.id} aria-label={`Node ${node.value}${label ? ', ' + label : ''}`}>
              {/* HEAD label above */}
              {isHead && (
                <text x={cx(i)} y={cy - NODE_R - 8} textAnchor="middle" fontSize={9} fontWeight="700" fill={PALETTE.primary} letterSpacing="1">
                  HEAD
                </text>
              )}

              {/* Pointer label above node (SLOW/FAST/MEET/ENTRY) */}
              {label && (
                <text x={cx(i)} y={cy - NODE_R - (isHead ? 20 : 8)} textAnchor="middle" fontSize={8} fontWeight="700" fill={style.stroke} letterSpacing="1">
                  {label}
                </text>
              )}

              {/* Node circle */}
              <circle
                cx={cx(i)}
                cy={cy}
                r={NODE_R}
                fill={style.fill}
                stroke={style.stroke}
                strokeWidth={node.id === cycleNodeId ? 3 : 2}
              />

              {/* Value */}
              <text
                x={cx(i)}
                y={cy + 1}
                textAnchor="middle"
                dominantBaseline="middle"
                fontSize={13}
                fontWeight="700"
                fontFamily="monospace"
                fill={style.textFill}
              >
                {node.value}
              </text>

              {/* Index below node */}
              <text x={cx(i)} y={cy + NODE_R + 14} textAnchor="middle" fontSize={9} fill={PALETTE.textSecondary}>
                [{i}]
              </text>
            </g>
          );
        })}
      </svg>

      {/* Legend */}
      <div className="mt-4 flex flex-wrap justify-center gap-x-4 gap-y-2">
        {[
          { color: PALETTE.primary,   label: 'SLOW' },
          { color: PALETTE.tertiary,  label: 'FAST' },
          { color: PALETTE.secondary, label: 'MEET' },
          { color: PALETTE.error,     label: 'CYCLE ENTRY' },
        ].map(({ color, label }) => (
          <div key={label} className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full shrink-0" style={{ background: color }} aria-hidden />
            <span className="text-label-caps text-text-body">{label}</span>
          </div>
        ))}
      </div>

      <p aria-live="polite" aria-atomic="true" className="sr-only">{step?.description ?? ''}</p>
    </section>
  );
}
