import { useState } from 'react';
import { Shuffle, RotateCcw, AlertCircle, Info } from 'lucide-react';
import Button from '../ui/Button';

const DEFAULT_ARRAY  = [42, 17, 8, 31, 25, 63, 11, 49];
const DEFAULT_SIZE   = 8;
const DEFAULT_TARGET = 31;

// ── Validators ────────────────────────────────────────────────────────────

function validateArray(raw, signed = false) {
  const parts = raw.split(',').map((s) => s.trim()).filter(Boolean);
  if (parts.length < 3)  return { error: 'Enter at least 3 values.' };
  if (parts.length > 20) return { error: 'Maximum 20 values allowed.' };
  const nums = parts.map(Number);
  if (nums.some((n) => isNaN(n) || !Number.isFinite(n)))
    return { error: 'All values must be numbers.' };
  if (signed) {
    if (nums.some((n) => n < -100 || n > 100))
      return { error: 'Each value must be between -100 and 100.' };
  } else {
    if (nums.some((n) => n < 1 || n > 100))
      return { error: 'Each value must be between 1 and 100.' };
  }
  return { values: nums };
}

function validateTarget(raw) {
  const n = Number(raw.trim());
  if (raw.trim() === '' || isNaN(n) || !Number.isFinite(n))
    return { error: 'Target must be a number.' };
  if (n < 1 || n > 100)
    return { error: 'Target must be between 1 and 100.' };
  return { value: n };
}

function randomArray(size) {
  const set = new Set();
  while (set.size < size) set.add(Math.floor(Math.random() * 100) + 1);
  return [...set];
}

// ── Target input sub-component ─────────────────────────────────────────────

function TargetInput({ initialTarget, onLoadTarget, onPause, isPlaying, requiresSorted }) {
  const [value, setValue]   = useState(String(initialTarget ?? DEFAULT_TARGET));
  const [error, setError]   = useState('');

  function applyTarget() {
    const result = validateTarget(value);
    if (result.error) { setError(result.error); return; }
    setError('');
    if (isPlaying) onPause();
    onLoadTarget(result.value);
  }

  function handleKey(e) {
    if (e.key === 'Enter') applyTarget();
  }

  return (
    <div className="flex flex-col gap-sm">
      <label
        htmlFor="target-input"
        className="text-label-caps text-text-secondary uppercase tracking-widest"
      >
        Search Target (1–100)
      </label>

      <div className="flex gap-sm">
        <input
          id="target-input"
          type="number"
          min={1}
          max={100}
          value={value}
          onChange={(e) => { setValue(e.target.value); if (error) setError(''); }}
          onKeyDown={handleKey}
          placeholder="e.g. 31"
          aria-describedby={error ? 'target-error' : undefined}
          aria-invalid={!!error}
          className={[
            'flex-1 h-11 rounded px-md font-mono',
            'bg-code-surface text-text-primary text-code-md',
            'placeholder:text-text-secondary',
            'transition-colors duration-150',
            'focus:outline-none focus:ring-1',
            '[appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none',
            error
              ? 'border border-error focus:border-error focus:ring-error/30'
              : 'border border-border hover:border-text-secondary focus:border-primary focus:ring-primary',
          ].join(' ')}
        />
        <Button onClick={applyTarget} size="md" aria-label="Apply target value">
          Search
        </Button>
      </div>

      {error && (
        <div id="target-error" role="alert" className="flex items-center gap-xs text-body-md text-error">
          <AlertCircle size={14} aria-hidden />
          {error}
        </div>
      )}

      {requiresSorted && (
        <div className="flex items-start gap-xs text-body-md text-text-secondary bg-elevated/60 rounded px-sm py-xs border border-border">
          <Info size={14} className="shrink-0 mt-0.5 text-secondary" aria-hidden />
          <span>Binary Search uses a sorted copy of your array.</span>
        </div>
      )}
    </div>
  );
}

// ── Main component ─────────────────────────────────────────────────────────

/**
 * ArrayControls
 *
 * Props:
 *   mode           — 'sorting' | 'searching'
 *   initialArray   — starting number[]
 *   initialTarget  — starting target number (searching only)
 *   requiresSorted — boolean (Binary Search: show sorted-copy notice)
 *   onLoadArray    — (arr: number[]) => void
 *   onLoadTarget   — (target: number) => void  (searching only)
 *   onPause        — () => void
 *   isPlaying      — boolean
 */
export default function ArrayControls({
  mode           = 'sorting',
  initialArray   = DEFAULT_ARRAY,
  initialTarget  = DEFAULT_TARGET,
  requiresSorted = false,
  signed         = false,
  onLoadArray,
  onLoadTarget,
  onPause,
  isPlaying,
}) {
  const [inputValue, setInputValue] = useState(initialArray.join(', '));
  const [arraySize,  setArraySize]  = useState(DEFAULT_SIZE);
  const [arrayError, setArrayError] = useState('');

  function applyInput() {
    const result = validateArray(inputValue, signed);
    if (result.error) { setArrayError(result.error); return; }
    setArrayError('');
    if (isPlaying) onPause();
    onLoadArray(result.values);
  }

  function handleRandomize() {
    if (isPlaying) onPause();
    const arr = randomArray(arraySize);
    setInputValue(arr.join(', '));
    setArrayError('');
    onLoadArray(arr);
  }

  function handleReset() {
    if (isPlaying) onPause();
    setInputValue(DEFAULT_ARRAY.join(', '));
    setArraySize(DEFAULT_SIZE);
    setArrayError('');
    onLoadArray(DEFAULT_ARRAY);
  }

  return (
    <div className="flex-1 overflow-y-auto scrollbar-thin p-md flex flex-col gap-lg">

      {/* ── Target input (search mode only) ────────────────────────── */}
      {mode === 'searching' && (
        <TargetInput
          initialTarget={initialTarget}
          onLoadTarget={onLoadTarget}
          onPause={onPause}
          isPlaying={isPlaying}
          requiresSorted={requiresSorted}
        />
      )}

      {/* ── Custom Array Input ──────────────────────────────────────── */}
      <div className="flex flex-col gap-sm">
        <label
          htmlFor="array-input"
          className="text-label-caps text-text-secondary uppercase tracking-widest"
        >
          Custom Array (comma-separated, 3–20 values, {signed ? '-100–100' : '1–100'})
        </label>

        <div className="flex gap-sm">
          <input
            id="array-input"
            type="text"
            value={inputValue}
            onChange={(e) => { setInputValue(e.target.value); if (arrayError) setArrayError(''); }}
            onKeyDown={(e) => { if (e.key === 'Enter') applyInput(); }}
            placeholder="e.g. 42, 17, 8, 31, 25"
            aria-describedby={arrayError ? 'array-error' : undefined}
            aria-invalid={!!arrayError}
            className={[
              'flex-1 h-11 rounded px-md font-mono',
              'bg-code-surface text-text-primary text-code-md',
              'placeholder:text-text-secondary',
              'transition-colors duration-150 focus:outline-none focus:ring-1',
              arrayError
                ? 'border border-error focus:border-error focus:ring-error/30'
                : 'border border-border hover:border-text-secondary focus:border-primary focus:ring-primary',
            ].join(' ')}
          />
          <Button onClick={applyInput} size="md" aria-label="Apply custom array">
            Apply
          </Button>
        </div>

        {arrayError && (
          <div id="array-error" role="alert" className="flex items-center gap-xs text-body-md text-error">
            <AlertCircle size={14} aria-hidden />
            {arrayError}
          </div>
        )}
      </div>

      {/* ── Array Size ──────────────────────────────────────────────── */}
      <div className="flex flex-col gap-sm">
        <div className="flex justify-between items-center">
          <label
            htmlFor="array-size"
            className="text-label-caps text-text-secondary uppercase tracking-widest"
          >
            Random Array Size
          </label>
          <span className="font-mono text-code-md text-primary font-semibold">
            {arraySize} elements
          </span>
        </div>
        <input
          id="array-size"
          type="range"
          min={3}
          max={20}
          value={arraySize}
          onChange={(e) => setArraySize(Number(e.target.value))}
          className="w-full h-2 rounded-full appearance-none cursor-pointer bg-elevated accent-primary"
          aria-label={`Array size: ${arraySize} elements`}
        />
        <div className="flex justify-between text-label-caps text-text-secondary">
          <span>3</span>
          <span>20</span>
        </div>
      </div>

      {/* ── Action Buttons ──────────────────────────────────────────── */}
      <div className="flex flex-col gap-sm">
        <Button
          onClick={handleRandomize}
          variant="secondary"
          className="w-full justify-center gap-2"
          aria-label={`Generate random array of ${arraySize} elements`}
        >
          <Shuffle size={16} aria-hidden />
          Randomize ({arraySize} elements)
        </Button>

        <Button
          onClick={handleReset}
          variant="ghost"
          className="w-full justify-center gap-2 border border-border"
          aria-label="Reset to default array"
        >
          <RotateCcw size={16} aria-hidden />
          Reset to Default
        </Button>
      </div>

      {/* ── Tips ────────────────────────────────────────────────────── */}
      <div className="bg-card rounded-lg border border-border p-md flex flex-col gap-xs">
        <p className="text-label-caps text-text-secondary uppercase tracking-widest mb-xs">Tips</p>
        <ul className="text-body-md text-text-body space-y-xs list-none">
          {mode === 'searching' ? (
            <>
              <li>• Try a target that does not exist to see the not-found path.</li>
              <li>• Try the first and last elements to see best and worst cases.</li>
              <li>• Switch between Linear and Binary to compare behaviours.</li>
            </>
          ) : (
            <>
              <li>• Try a nearly-sorted array to see early-exit optimisations.</li>
              <li>• Try a reverse-sorted array for the worst case.</li>
              <li>• Switch algorithms above to compare on the same data.</li>
            </>
          )}
        </ul>
      </div>
    </div>
  );
}
