/**
 * CircularQueueControls
 *
 * Controls for Circular Queue visualization.
 * Props:
 *   input        — raw operations string
 *   onInputChange
 *   onRun
 *   disabled
 */

import { useState } from 'react';

const EXAMPLE = 'capacity: 4, enqueue 10, enqueue 20, enqueue 30, dequeue, enqueue 40, enqueue 50';

function validate(str) {
  if (!str.trim()) return { valid: false, error: 'Input cannot be empty.' };
  const lower = str.toLowerCase();
  if (!lower.includes('capacity:')) return { valid: false, error: 'Must start with "capacity: N".' };
  return { valid: true };
}

export default function CircularQueueControls({
  input = EXAMPLE,
  onInputChange,
  onRun,
  disabled = false,
}) {
  const [str, setStr]   = useState(input);
  const [error, setErr] = useState('');

  function handleRun() {
    const result = validate(str);
    if (!result.valid) { setErr(result.error); return; }
    setErr('');
    onInputChange?.(str);
    onRun?.();
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-col gap-1">
        <label className="text-label-caps text-text-secondary uppercase tracking-widest text-[10px]">
          Operations
        </label>
        <textarea
          className="input-field font-mono text-code-sm resize-none"
          rows={4}
          value={str}
          onChange={e => { setStr(e.target.value); setErr(''); }}
          disabled={disabled}
          placeholder={EXAMPLE}
          aria-label="Circular queue operations"
        />
        <p className="text-[10px] text-text-secondary leading-relaxed">
          Format: <code className="text-primary">capacity: N, enqueue V, dequeue, ...</code>
        </p>
      </div>

      {error && <p className="text-error text-code-sm" role="alert">{error}</p>}

      <button className="btn-primary mt-1" onClick={handleRun} disabled={disabled}>
        Visualize
      </button>
    </div>
  );
}
