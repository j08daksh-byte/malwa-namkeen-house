/**
 * QueueCanvas — horizontal FIFO queue renderer.
 *
 * Layout:
 *   FRONT label above index 0 (left), REAR label above last index (right).
 *   Elements render left-to-right; new elements appear at the right (rear).
 *   Dequeue removes from the left (front).
 *
 * Cell color states (per approved palette):
 *   default          — base card color
 *   enqueue          — secondary/mint  (newly added element)
 *   dequeue-highlight — error/red      (element about to be removed)
 *   front-inspect    — tertiary/amber  (element being peeked with front)
 *   completed        — success/green   (final state)
 *   underflow        — error/red       (empty-queue error)
 */

import { ArrowRight } from 'lucide-react';

// ── Cell state resolver ───────────────────────────────────────────────────

function getCellState(index, step, queueLen) {
  const isFront = index === 0;
  const isRear  = index === queueLen - 1;

  switch (step?.type) {
    case 'enqueue':
      return isRear ? 'enqueue' : 'default';

    case 'dequeue-check':
      return isFront ? 'dequeue-highlight' : 'default';

    case 'dequeue':
      return 'default';

    case 'front-check':
    case 'front':
      return isFront ? 'front-inspect' : 'default';

    case 'completed':
      return isFront ? 'completed' : 'default';

    case 'underflow':
      return 'underflow';

    default:
      // initial, operation-read, is-empty
      return 'default';
  }
}

// ── Per-state style map ───────────────────────────────────────────────────

const CELL_STYLES = {
  default:           'bg-elevated border-border text-text-primary',
  enqueue:           'bg-secondary/20 border-secondary text-secondary',
  'dequeue-highlight': 'bg-error/20 border-error text-error',
  'front-inspect':   'bg-tertiary/20 border-tertiary text-tertiary',
  completed:         'bg-success/20 border-success text-success',
  underflow:         'bg-error/20 border-error text-error',
};

// ── Operation pill ────────────────────────────────────────────────────────

function OperationPill({ operation }) {
  if (!operation) return null;

  const PILL_STYLES = {
    enqueue:   'bg-secondary/15 text-secondary border-secondary/40',
    dequeue:   'bg-error/15    text-error    border-error/40',
    front:     'bg-tertiary/15 text-tertiary  border-tertiary/40',
    'is-empty': 'bg-primary/15 text-primary   border-primary/40',
  };

  const labels = {
    enqueue:   operation.value != null ? `ENQUEUE ${operation.value}` : 'ENQUEUE',
    dequeue:   'DEQUEUE',
    front:     'FRONT',
    'is-empty': 'IS EMPTY',
  };

  const style = PILL_STYLES[operation.type] ?? 'bg-elevated text-text-secondary border-border';
  const label = labels[operation.type]     ?? operation.type.toUpperCase();

  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-label-caps font-bold uppercase tracking-widest border ${style}`}
    >
      {label}
    </span>
  );
}

// ── Result panel ──────────────────────────────────────────────────────────

function ResultPanel({ step }) {
  if (!step) return null;
  const { type, dequeuedValue, frontValue, result, errorState } = step;

  if (type === 'underflow') {
    const opName = errorState === 'dequeue' ? 'Dequeue' : 'Front';
    return (
      <div className="mt-3 flex items-center gap-2 rounded-lg border border-error/40 bg-error/10 px-3 py-2">
        <span className="w-2 h-2 rounded-full bg-error shrink-0" aria-hidden />
        <p className="text-body-md font-semibold text-error">
          {opName} Underflow — queue is empty
        </p>
      </div>
    );
  }

  if (type === 'dequeue' && dequeuedValue != null) {
    return (
      <div className="mt-3 flex items-center gap-2 rounded-lg border border-error/40 bg-error/10 px-3 py-2">
        <span className="w-2 h-2 rounded-full bg-error shrink-0" aria-hidden />
        <p className="text-body-md font-semibold text-error">
          Dequeued: <span className="font-mono">{dequeuedValue}</span>
        </p>
      </div>
    );
  }

  if ((type === 'front' || type === 'front-check') && frontValue != null) {
    return (
      <div className="mt-3 flex items-center gap-2 rounded-lg border border-tertiary/40 bg-tertiary/10 px-3 py-2">
        <span className="w-2 h-2 rounded-full bg-tertiary shrink-0" aria-hidden />
        <p className="text-body-md font-semibold text-tertiary">
          Front: <span className="font-mono">{frontValue}</span>
        </p>
      </div>
    );
  }

  if (type === 'is-empty' && result != null) {
    const color = result ? 'text-success' : 'text-primary';
    const dot   = result ? 'bg-success'   : 'bg-primary';
    const border = result ? 'border-success/40 bg-success/10' : 'border-primary/40 bg-primary/10';
    return (
      <div className={`mt-3 flex items-center gap-2 rounded-lg border ${border} px-3 py-2`}>
        <span className={`w-2 h-2 rounded-full ${dot} shrink-0`} aria-hidden />
        <p className={`text-body-md font-semibold ${color}`}>
          Is Empty: <span className="font-mono">{result ? 'true' : 'false'}</span>
        </p>
      </div>
    );
  }

  return null;
}

// ── Main component ────────────────────────────────────────────────────────

export default function QueueCanvas({ step }) {
  const queue   = step?.queue ?? [];
  const queueLen = queue.length;

  return (
    <div
      className="flex flex-col flex-1 min-h-0 overflow-auto bg-background px-md py-md"
      aria-label="Queue visualization"
    >
      {/* Operation description */}
      <div className="flex items-start gap-2 mb-3 min-h-[2.25rem]">
        {step?.operation && <OperationPill operation={step.operation} />}
        <p
          className="text-body-md text-text-secondary leading-snug"
          aria-live="polite"
          aria-atomic="true"
        >
          {step?.description ?? ''}
        </p>
      </div>

      {/* Queue container */}
      <div className="flex flex-col">
        {queueLen === 0 ? (
          /* Empty state */
          <div
            className="flex items-center justify-center rounded-xl border-2 border-dashed border-border bg-code-surface py-8"
            aria-label="Queue is empty"
          >
            <p className="text-body-md text-text-secondary select-none">
              Queue is empty
            </p>
          </div>
        ) : (
          <>
            {/* FRONT / REAR labels row */}
            <div
              className="flex mb-1"
              aria-hidden
            >
              {queue.map((_, i) => {
                const isFront = i === 0;
                const isRear  = i === queueLen - 1;
                const isBoth  = queueLen === 1;

                let label = '';
                if (isBoth)  label = 'FRONT/REAR';
                else if (isFront) label = 'FRONT';
                else if (isRear)  label = 'REAR';

                return (
                  <div
                    key={i}
                    className="flex flex-col items-center shrink-0"
                    style={{ width: 60, marginRight: i < queueLen - 1 ? 4 : 0 }}
                  >
                    <span
                      className={[
                        'text-[9px] font-bold uppercase tracking-widest leading-none',
                        isFront || isBoth ? 'text-secondary' : isRear ? 'text-primary' : 'text-transparent',
                      ].join(' ')}
                    >
                      {label || ' '}
                    </span>
                    <span
                      className={[
                        'text-[9px] leading-none',
                        label ? (isFront || isBoth ? 'text-secondary' : 'text-primary') : 'text-transparent',
                      ].join(' ')}
                    >
                      ▼
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Cell row */}
            <div
              className="flex overflow-x-auto scrollbar-none pb-1"
              role="list"
              aria-label={`Queue with ${queueLen} element${queueLen !== 1 ? 's' : ''}`}
            >
              {queue.map((val, i) => {
                const state = getCellState(i, step, queueLen);
                const isFront = i === 0;
                const isRear  = i === queueLen - 1;

                return (
                  <div
                    key={i}
                    role="listitem"
                    aria-label={`${isFront ? 'Front, ' : ''}${isRear ? 'Rear, ' : ''}value ${val}`}
                    className={[
                      'shrink-0 w-[60px] h-14 flex items-center justify-center',
                      'font-mono text-code-md font-bold',
                      'rounded-lg border-2 transition-colors duration-200',
                      // Connect cells with a small gap
                      i < queueLen - 1 ? 'mr-1' : '',
                      CELL_STYLES[state] ?? CELL_STYLES.default,
                    ].join(' ')}
                  >
                    {val}
                  </div>
                );
              })}

              {/* Direction arrow showing FIFO flow */}
              <div
                className="flex items-center ml-2 shrink-0 text-text-secondary"
                aria-hidden
              >
                <ArrowRight size={16} />
                <span className="text-[9px] ml-1 text-text-secondary">dequeue</span>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Result panel */}
      <ResultPanel step={step} />
    </div>
  );
}
