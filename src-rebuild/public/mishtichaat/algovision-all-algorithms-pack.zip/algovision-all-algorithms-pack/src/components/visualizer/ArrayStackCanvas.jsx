/**
 * ArrayStackCanvas
 *
 * Composite canvas for Next Greater Element.
 * Shows:
 *   - Input array (top) with current index highlighted
 *   - Result array (middle) being filled
 *   - Monotonic stack (right panel) with indices/values
 *
 * Step fields:
 *   step.array          — input array
 *   step.result         — result array (filled so far, -1 for unknowns)
 *   step.currentIndex   — i being processed
 *   step.stackIndices   — current stack contents (array of indices)
 *   step.resolvedIndices — indices whose NGE has been found
 *   step.description
 */

const INPUT_CELL_STYLE = {
  default:   { bg: 'bg-elevated border-border',       text: 'text-text-secondary', label: '' },
  current:   { bg: 'bg-primary border-primary',       text: 'text-background',     label: 'i' },
  resolved:  { bg: 'bg-success/20 border-success',    text: 'text-success',        label: '✓' },
  stacked:   { bg: 'bg-tertiary/20 border-tertiary',  text: 'text-tertiary',       label: 'ST' },
};

function InputCell({ value, index, state }) {
  const style = INPUT_CELL_STYLE[state] ?? INPUT_CELL_STYLE.default;
  return (
    <div
      className={['w-11 shrink-0 flex flex-col items-center rounded border-2 select-none transition-colors duration-200', style.bg].join(' ')}
      aria-label={`Index ${index}: ${value}${style.label ? `, ${style.label}` : ''}`}
    >
      <span className={['text-[9px] font-bold uppercase tracking-wider leading-none pt-1 h-3.5', style.text].join(' ')}>
        {style.label}
      </span>
      <span className={['font-mono text-lg font-bold leading-tight', style.text].join(' ')}>
        {value}
      </span>
      <span className={['font-mono text-[10px] pb-1 leading-none opacity-70', style.text].join(' ')}>
        {index}
      </span>
    </div>
  );
}

function ResultCell({ value, index, state }) {
  const isKnown = value !== -1;
  const bg = state === 'current' ? 'bg-primary/20 border-primary' : isKnown ? 'bg-success/20 border-success' : 'bg-card border-border';
  const text = state === 'current' ? 'text-primary' : isKnown ? 'text-success' : 'text-text-secondary';
  return (
    <div
      className={['w-11 shrink-0 flex flex-col items-center rounded border-2 select-none transition-colors duration-200', bg].join(' ')}
      aria-label={`Result index ${index}: ${value}`}
    >
      <span className="text-[9px] font-bold uppercase tracking-wider leading-none pt-1 h-3.5 text-inherit" />
      <span className={['font-mono text-lg font-bold leading-tight', text].join(' ')}>
        {value}
      </span>
      <span className={['font-mono text-[10px] pb-1 leading-none opacity-70', text].join(' ')}>
        {index}
      </span>
    </div>
  );
}

function MonotonicStack({ arr, stackIndices }) {
  return (
    <div className="flex flex-col min-w-[120px]" aria-label="Monotonic stack">
      <p className="text-[10px] font-bold uppercase tracking-widest text-text-secondary mb-2">
        STACK (indices)
      </p>
      <div className="flex flex-col-reverse gap-1 min-h-[80px]">
        {stackIndices.length === 0 ? (
          <div className="border border-dashed border-border rounded px-3 py-2 text-text-secondary text-code-sm italic text-center">
            empty
          </div>
        ) : (
          stackIndices.map((idx, si) => {
            const isTop = si === stackIndices.length - 1;
            return (
              <div
                key={si}
                className={[
                  'flex items-center justify-between px-3 py-1.5 rounded border transition-colors duration-150',
                  isTop ? 'bg-tertiary/20 border-tertiary' : 'bg-elevated border-border',
                ].join(' ')}
                aria-label={`Stack index: ${idx}, value: ${arr[idx]}`}
              >
                <span className={['font-mono text-code-sm', isTop ? 'text-tertiary font-bold' : 'text-text-secondary'].join(' ')}>
                  [{idx}]
                </span>
                <span className="text-text-secondary text-xs mx-1" aria-hidden>→</span>
                <span className={['font-mono text-code-sm font-bold', isTop ? 'text-tertiary' : 'text-text-primary'].join(' ')}>
                  {arr[idx]}
                </span>
                {isTop && <span className="ml-1 text-[9px] text-tertiary font-bold">TOP</span>}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

export default function ArrayStackCanvas({ step, legend = [] }) {
  const array         = step?.array ?? [];
  const result        = step?.result ?? new Array(array.length).fill(-1);
  const currentIndex  = step?.currentIndex ?? null;
  const stackIndices  = step?.stackIndices ?? [];
  const resolvedIdxs  = step?.resolvedIndices ?? [];

  function getCellState(i) {
    if (i === currentIndex) return 'current';
    if (resolvedIdxs.includes(i)) return 'resolved';
    if (stackIndices.includes(i)) return 'stacked';
    return 'default';
  }

  return (
    <section
      className="flex-[1.2] canvas-dot-grid relative flex flex-col items-center justify-start px-md pt-12 pb-4 bg-background overflow-y-auto"
      aria-label="Array and stack visualization"
    >
      {/* Description badge */}
      <div
        className="absolute top-4 left-4 right-4 flex items-center gap-2 bg-nav/90 backdrop-blur-sm px-sm py-1.5 rounded-lg border border-border"
        aria-hidden
      >
        <span className={[
          'w-2 h-2 shrink-0 rounded-full',
          step?.type === 'completed' ? 'bg-success' :
          step?.type === 'resolve' ? 'bg-secondary animate-pulse' :
          'bg-primary',
        ].join(' ')} />
        <p className="font-mono text-code-md text-text-body truncate">
          {step?.description ?? 'Loading…'}
        </p>
      </div>

      <div className="flex flex-col sm:flex-row items-start justify-center gap-6 mt-4 w-full">
        {/* Left: arrays */}
        <div className="flex flex-col gap-4 items-center">
          {/* Input array */}
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-text-secondary mb-2 text-center">
              INPUT ARRAY
            </p>
            <div className="overflow-x-auto scrollbar-none">
              <div className="flex gap-1.5 min-w-max" role="img" aria-label="Input array">
                {array.map((val, i) => (
                  <InputCell key={i} value={val} index={i} state={getCellState(i)} />
                ))}
              </div>
            </div>
          </div>

          {/* Result array */}
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-text-secondary mb-2 text-center">
              RESULT (NGE)
            </p>
            <div className="overflow-x-auto scrollbar-none">
              <div className="flex gap-1.5 min-w-max" role="img" aria-label="Result array">
                {result.map((val, i) => (
                  <ResultCell key={i} value={val} index={i} state={i === currentIndex ? 'current' : 'default'} />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right: stack */}
        <MonotonicStack arr={array} stackIndices={stackIndices} />
      </div>

      <p aria-live="polite" aria-atomic="true" className="sr-only">{step?.description ?? ''}</p>
    </section>
  );
}
