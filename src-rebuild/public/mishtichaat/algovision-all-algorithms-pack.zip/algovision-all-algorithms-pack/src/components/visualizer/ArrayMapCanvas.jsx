/**
 * ArrayMapCanvas
 *
 * Array + Hash Map composite visualization for:
 *   - Two Sum (array + map showing value→index)
 *   - Frequency Count (array + map showing value→count)
 *
 * Step fields:
 *   step.array        — the array
 *   step.currentIndex — index being processed
 *   step.cellStates   — { [index]: 'default'|'current'|'found'|'completed' }
 *   step.mapEntries   — [{ key, value, state: 'default'|'active'|'found'|'new' }]
 *   step.complement   — number being searched (Two Sum only)
 *   step.target       — target sum (Two Sum only)
 *   step.result       — null | [i,j] | [] | result info
 *   step.description
 */

// ── Cell styles ─────────────────────────────────────────────────────

const CELL_STYLE = {
  default:   { bg: 'bg-elevated border-border',       text: 'text-text-secondary' },
  current:   { bg: 'bg-primary border-primary',       text: 'text-background'     },
  found:     { bg: 'bg-success border-success',       text: 'text-background'     },
  completed: { bg: 'bg-success/20 border-success',    text: 'text-success'        },
};

function ArrayCell({ value, index, state }) {
  const style = CELL_STYLE[state] ?? CELL_STYLE.default;
  const label = state === 'current' ? 'i' : state === 'found' ? '✓' : '';
  return (
    <div
      className={['w-11 shrink-0 flex flex-col items-center rounded border-2 select-none transition-colors duration-200', style.bg].join(' ')}
      aria-label={`Index ${index}: ${value}`}
    >
      <span className={['text-[9px] font-bold uppercase tracking-wider leading-none pt-1 h-3.5', style.text].join(' ')}>
        {label}
      </span>
      <span className={['font-mono text-lg font-bold leading-tight', style.text].join(' ')}>
        {value}
      </span>
      <span className={['font-mono text-[10px] pb-1 leading-none opacity-70', style.text].join(' ')}>
        {index}
      </span>
    </div>
  );
}

// ── Map entry styles ─────────────────────────────────────────────────

const MAP_ROW_STYLE = {
  default: { row: 'bg-elevated/40',             key: 'text-text-secondary', val: 'text-text-primary'  },
  active:  { row: 'bg-primary/15 border-l-2 border-primary', key: 'text-primary font-bold', val: 'text-primary' },
  found:   { row: 'bg-success/15 border-l-2 border-success', key: 'text-success font-bold', val: 'text-success' },
  new:     { row: 'bg-secondary/15 border-l-2 border-secondary', key: 'text-secondary font-bold', val: 'text-secondary' },
};

function MapPanel({ entries = [], complement, mapLabel = 'HASH MAP' }) {
  return (
    <div className="flex flex-col min-w-[160px] max-w-[220px] w-full sm:w-auto">
      <div className="flex items-center gap-2 mb-2">
        <span className="text-label-caps text-text-secondary uppercase tracking-widest text-[10px]">
          {mapLabel}
        </span>
        <span className="text-[10px] text-text-secondary">Key → Value</span>
      </div>
      <div
        className="flex flex-col rounded-lg border border-border overflow-hidden bg-code-surface min-h-[80px]"
        role="table"
        aria-label="Hash map contents"
      >
        {/* Header */}
        <div className="flex border-b border-border bg-nav/60 px-3 py-1">
          <span className="flex-1 text-[9px] font-bold uppercase text-text-secondary tracking-widest">KEY</span>
          <span className="text-[9px] font-bold uppercase text-text-secondary tracking-widest">VALUE</span>
        </div>
        {/* Rows */}
        {entries.length === 0 ? (
          <div className="flex items-center justify-center py-4 text-text-secondary text-code-sm italic">
            ( empty )
          </div>
        ) : (
          <div className="flex flex-col divide-y divide-border overflow-y-auto max-h-[160px] scrollbar-thin">
            {entries.map((entry, i) => {
              const style = MAP_ROW_STYLE[entry.state] ?? MAP_ROW_STYLE.default;
              const isComplement = complement != null && entry.key === complement;
              return (
                <div
                  key={i}
                  className={['flex items-center px-3 py-1.5 gap-2 transition-colors duration-150', style.row, isComplement ? 'ring-1 ring-primary' : ''].join(' ')}
                  role="row"
                  aria-label={`${entry.key} → ${entry.value}${entry.state !== 'default' ? `, ${entry.state}` : ''}`}
                >
                  <span className={['flex-1 font-mono text-code-sm', style.key].join(' ')}>
                    {entry.key}
                  </span>
                  <span className="text-text-secondary text-xs" aria-hidden>→</span>
                  <span className={['font-mono text-code-sm', style.val].join(' ')}>
                    {entry.value}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {complement != null && (
        <div className="mt-2 px-2 py-1 bg-primary/10 rounded border border-primary/30 text-[10px] font-mono text-primary">
          Looking for: {complement}
        </div>
      )}
    </div>
  );
}

// ── Result panel ─────────────────────────────────────────────────────

function ResultPanel({ result, array, target }) {
  if (result == null) return null;
  const isFound = Array.isArray(result) && result.length === 2;
  const notFound = Array.isArray(result) && result.length === 0;
  return (
    <div className={[
      'mt-3 px-md py-sm rounded-lg border flex items-center gap-2',
      isFound ? 'bg-success/10 border-success/30' : 'bg-error/10 border-error/30',
    ].join(' ')} role="status">
      <span className={['w-2 h-2 rounded-full shrink-0', isFound ? 'bg-success' : 'bg-error'].join(' ')} aria-hidden />
      <p className={['text-body-md font-semibold', isFound ? 'text-success' : 'text-error'].join(' ')}>
        {isFound
          ? `Pair found! Indices [${result[0]}, ${result[1]}] → ${array[result[0]]} + ${array[result[1]]} = ${target}`
          : `No pair found that sums to ${target}`
        }
      </p>
    </div>
  );
}

// ── Main component ───────────────────────────────────────────────────

export default function ArrayMapCanvas({ step, legend = [] }) {
  const array       = step?.array ?? [];
  const states      = step?.cellStates ?? {};
  const mapEntries  = step?.mapEntries ?? [];
  const complement  = step?.complement ?? null;
  const target      = step?.target ?? null;
  const result      = step?.result ?? null;
  const isFreq      = step?.target === null || step?.target === undefined;
  const mapLabel    = isFreq ? 'FREQ MAP' : 'HASH MAP';

  return (
    <section
      className="flex-[1.2] canvas-dot-grid relative flex flex-col items-center justify-start px-md pt-12 pb-4 bg-background overflow-y-auto"
      aria-label="Array and map visualization canvas"
    >
      {/* Description badge */}
      <div
        className="absolute top-4 left-4 right-4 flex items-center gap-2 bg-nav/90 backdrop-blur-sm px-sm py-1.5 rounded-lg border border-border"
        aria-hidden
      >
        <span className={[
          'w-2 h-2 shrink-0 rounded-full',
          step?.type === 'found' || step?.type === 'completed' ? 'bg-success' :
          step?.type === 'lookup' || step?.type === 'increment' ? 'bg-primary animate-pulse' :
          'bg-secondary',
        ].join(' ')} />
        <p className="font-mono text-code-md text-text-body truncate">
          {step?.description ?? 'Loading…'}
        </p>
      </div>

      {/* Target badge (Two Sum only) */}
      {target != null && (
        <div className="mb-3 flex items-center gap-2 mt-2">
          <span className="text-label-caps text-text-secondary uppercase tracking-widest">Target</span>
          <span className="font-mono text-code-lg font-bold text-tertiary bg-tertiary/10 border border-tertiary/30 px-sm py-xs rounded">
            {target}
          </span>
        </div>
      )}

      {/* Array row */}
      <div className="w-full overflow-x-auto scrollbar-none py-1 mt-2">
        <div
          className="flex gap-1.5 justify-center min-w-max mx-auto"
          role="img"
          aria-label={`Array of ${array.length} elements`}
        >
          {array.map((val, i) => (
            <ArrayCell
              key={i}
              value={val}
              index={i}
              state={states[i] ?? 'default'}
            />
          ))}
        </div>
      </div>

      {/* Map panel */}
      <div className="mt-4 flex justify-center w-full">
        <MapPanel entries={mapEntries} complement={complement} mapLabel={mapLabel} />
      </div>

      {/* Result panel (Two Sum) */}
      {target != null && <ResultPanel result={result} array={array} target={target} />}

      {/* Legend */}
      {legend.length > 0 && (
        <div className="mt-4 flex flex-wrap justify-center gap-x-6 gap-y-2" aria-label="Legend">
          {legend.map(({ color, label }) => (
            <div key={label} className="flex items-center gap-2">
              <span className={['w-3 h-3 rounded-full shrink-0', color].join(' ')} aria-hidden />
              <span className="text-label-caps text-text-body">{label}</span>
            </div>
          ))}
        </div>
      )}

      <p aria-live="polite" aria-atomic="true" className="sr-only">{step?.description ?? ''}</p>
    </section>
  );
}
