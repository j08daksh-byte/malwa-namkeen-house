import ArrayControls from './ArrayControls.jsx';
import ArrayKControls from './ArrayKControls.jsx';
import StackControls from './StackControls.jsx';
import QueueControls from './QueueControls.jsx';
import LinkedListControls from './LinkedListControls.jsx';
import LinkedListMutateControls from './LinkedListMutateControls.jsx';
import LinkedListCycleControls from './LinkedListCycleControls.jsx';
import GraphControls from './GraphControls.jsx';
import BinaryTreeControls from './BinaryTreeControls.jsx';
import StringInputControls from './StringInputControls.jsx';
import CircularQueueControls from './CircularQueueControls.jsx';
import QueueTwoStacksControls from './QueueTwoStacksControls.jsx';

export default function ControlRenderer({ algorithm, model, player }) {
  const pause = player.pause;
  const disabled = player.isPlaying;
  const controlType = algorithm.controlType ?? (
    algorithm.visualizationType === 'searching' ? 'array-target' : 'array-basic'
  );

  if (controlType === 'array-k') {
    return (
      <ArrayKControls
        array={model.array}
        k={model.k}
        onArrayChange={model.setArray}
        onKChange={model.setK}
        onRun={player.restart}
        disabled={disabled}
        signed={false}
      />
    );
  }

  if (controlType === 'array-basic' || controlType === 'array-signed' || controlType === 'array-target') {
    return (
      <ArrayControls
        mode={controlType === 'array-target' || algorithm.visualizationType === 'searching' ? 'searching' : 'sorting'}
        initialArray={model.array}
        initialTarget={model.target}
        requiresSorted={algorithm.requiresSorted}
        signed={controlType === 'array-signed'}
        onLoadArray={model.setArray}
        onLoadTarget={model.setTarget}
        onPause={pause}
        isPlaying={disabled}
      />
    );
  }

  if (controlType === 'stack-operations') {
    return (
      <StackControls
        initialOpsString={model.stackOpsString}
        onLoadOps={model.setOperationInput}
        onPause={pause}
        isPlaying={disabled}
      />
    );
  }

  if (controlType === 'queue-operations') {
    return (
      <QueueControls
        initialOpsString={model.queueOpsString}
        onLoadOps={model.setOperationInput}
        onPause={pause}
        isPlaying={disabled}
      />
    );
  }

  if (controlType === 'linked-list-values') {
    return (
      <LinkedListControls
        initialValuesString={model.listValues.join(', ')}
        onLoadValues={model.setListValues}
        onPause={pause}
        isPlaying={disabled}
      />
    );
  }

  if (controlType === 'll-insert' || controlType === 'll-delete') {
    return (
      <LinkedListMutateControls
        mode={controlType === 'll-insert' ? 'insert' : 'delete'}
        values={model.listValues}
        position={model.position}
        newValue={model.newValue}
        deleteIndex={model.deleteIndex}
        onValuesChange={model.setListValues}
        onPositionChange={model.setPosition}
        onNewValueChange={model.setNewValue}
        onDeleteIndexChange={model.setDeleteIndex}
        onRun={player.restart}
        disabled={disabled}
      />
    );
  }

  if (controlType === 'll-cycle') {
    return (
      <LinkedListCycleControls
        values={model.listValues}
        cycleEntry={model.cycleEntry}
        onValuesChange={model.setListValues}
        onCycleEntryChange={model.setCycleEntry}
        onRun={player.restart}
        disabled={disabled}
      />
    );
  }

  if (
    controlType === 'graph-bfs-input' ||
    controlType === 'graph-traversal-input' ||
    controlType === 'graph-structure-input'
  ) {
    return (
      <GraphControls
        initialNodesString={model.graphStrings.nodes}
        initialEdgesString={model.graphStrings.edges}
        initialStartString={model.graphStrings.start}
        onLoadGraph={model.setGraphInput}
        onPause={pause}
        isPlaying={disabled}
        controlHelp={
          controlType === 'graph-structure-input'
            ? 'The cycle detector checks all connected components using DFS and parent tracking.'
            : undefined
        }
      />
    );
  }

  if (controlType === 'binary-tree-tokens') {
    return (
      <BinaryTreeControls
        initialTokensString={model.treeTokens.map((value) => value == null ? 'null' : value).join(', ')}
        onLoadTokens={model.setTreeTokens}
        onPause={pause}
        isPlaying={disabled}
      />
    );
  }

  if (controlType === 'string-input') {
    return (
      <StringInputControls
        value={model.stringInput}
        onChange={model.setStringInput}
        onRun={player.restart}
        disabled={disabled}
      />
    );
  }

  if (controlType === 'circular-queue-ops') {
    return (
      <CircularQueueControls
        input={model.circularQueueInput}
        onInputChange={model.setCircularQueueInput}
        onRun={player.restart}
        disabled={disabled}
      />
    );
  }

  if (controlType === 'queue-two-stacks-ops') {
    return (
      <QueueTwoStacksControls
        input={model.twoStacksInput}
        onInputChange={model.setTwoStacksInput}
        onRun={player.restart}
        disabled={disabled}
      />
    );
  }

  return (
    <div className="p-md text-text-secondary">
      No input controls are required for this algorithm.
    </div>
  );
}
