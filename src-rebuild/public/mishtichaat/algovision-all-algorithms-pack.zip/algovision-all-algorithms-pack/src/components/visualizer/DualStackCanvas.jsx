/**
 * DualStackCanvas
 *
 * Two-stack visualization for Queue Using Two Stacks.
 *
 * Step fields:
 *   step.inputStack        — values in input stack (bottom to top)
 *   step.outputStack       — values in output stack (bottom to top)
 *   step.operation         — { type, value }
 *   step.transferDirection — 'in-to-out' | null
 *   step.result            — result value / 'UNDERFLOW' / null
 *   step.description
 */

function StackColumn({ label, values = [], highlightTop = false, transferDir = null, side = 'left' }) {
  const isInput = side === 'left';
  const isEmpty = values.length === 0;

  return (
    <div className="flex flex-col items-center gap-2 min-w-[110px]">
      {/* Label */}
      <div className="flex items-center gap-1">
        <span className={[
          'text-label-caps font-bold uppercase tracking-widest text-[10px]',
          isInput ? 'text-primary' : 'text-secondary',
        ].join(' ')}>
          {label}
        </span>
      </div>

      {/* Transfer arrow */}
      {transferDir === 'in-to-out' && (
        <div className={['text-tertiary text-xs font-bold animate-pulse', isInput ? 'self-end' : 'self-start'].join(' ')}>
          {isInput ? '→ pop' : '← push'}
        </div>
      )}

      {/* Stack elements (top of visual = top of stack) */}
      <div className="flex flex-col-reverse gap-1 w-full min-h-[80px]">
        {isEmpty ? (
          <div className="border border-dashed border-border rounded px-3 py-2 text-text-secondary text-code-sm italic text-center">
            empty
          </div>
        ) : (
          values.map((val, i) => {
            const isTop = i === values.length - 1;
            return (
              <div
                key={i}
                className={[
                  'flex items-center justify-between px-3 py-2 rounded border transition-colors duration-150',
                  isTop && highlightTop
                    ? isInput ? 'bg-primary/20 border-primary' : 'bg-secondary/20 border-secondary'
                    : 'bg-elevated border-border',
                ].join(' ')}
                aria-label={`Value ${val}${isTop ? ', top' : ''}`}
              >
                <span className={[
                  'font-mono text-code-md font-bold',
                  isTop && highlightTop
                    ? isInput ? 'text-primary' : 'text-secondary'
                    : 'text-text-primary',
                ].join(' ')}>
                  {val}
                </span>
                {isTop && <span className="text-[9px] font-bold text-text-secondary">TOP</span>}
              </div>
            );
          })
        )}
      </div>

      {/* Base indicator */}
      <div className="w-full h-0.5 rounded bg-border" aria-hidden />
      <span className="text-[9px] text-text-secondary uppercase tracking-widest">BOTTOM</span>
    </div>
  );
}

function OperationBadge({ operation, result }) {
  if (!operation) return null;
  const isErr = result === 'UNDERFLOW';
  let label = '';
  if (operation.type === 'enqueue') label = `ENQUEUE ${operation.value}`;
  else if (operation.type === 'dequeue') label = 'DEQUEUE';
  else if (operation.type === 'front') label = 'FRONT';
  else if (operation.type === 'isempty') label = 'IS EMPTY';

  return (
    <div className={[
      'flex items-center gap-2 px-md py-sm rounded-lg border',
      isErr ? 'bg-error/10 border-error/30' : 'bg-secondary/10 border-secondary/30',
    ].join(' ')}>
      <span className={['text-label-caps font-bold uppercase tracking-widest', isErr ? 'text-error' : 'text-secondary'].join(' ')}>
        {label}
      </span>
      {result != null && !isErr && (
        <>
          <span className="text-text-secondary">→</span>
          <span className="font-mono text-code-md font-bold text-success">{String(result)}</span>
        </>
      )}
      {isErr && <span className="font-mono text-code-md font-bold text-error">UNDERFLOW</span>}
    </div>
  );
}

export default function DualStackCanvas({ step }) {
  const inputStack  = step?.inputStack ?? [];
  const outputStack = step?.outputStack ?? [];
  const operation   = step?.operation ?? null;
  const transferDir = step?.transferDirection ?? null;
  const result      = step?.result ?? null;

  const isTransfer = transferDir === 'in-to-out';

  // Logical queue order: output reversed + input reversed
  const logicalOrder = [
    ...outputStack.slice().reverse(),
    ...inputStack,
  ];

  return (
    <section
      className="flex-[1.2] canvas-dot-grid relative flex flex-col items-center justify-start px-md pt-12 pb-4 bg-background overflow-y-auto"
      aria-label="Queue using two stacks visualization"
    >
      {/* Description badge */}
      <div
        className="absolute top-4 left-4 right-4 flex items-center gap-2 bg-nav/90 backdrop-blur-sm px-sm py-1.5 rounded-lg border border-border"
        aria-hidden
      >
        <span className={[
          'w-2 h-2 shrink-0 rounded-full',
          result === 'UNDERFLOW' ? 'bg-error animate-pulse' :
          isTransfer ? 'bg-tertiary animate-pulse' :
          step?.type === 'completed' ? 'bg-success' : 'bg-secondary',
        ].join(' ')} />
        <p className="font-mono text-code-md text-text-body truncate">
          {step?.description ?? 'Loading…'}
        </p>
      </div>

      {/* Dual stacks */}
      <div className="flex items-start justify-center gap-8 mt-6">
        <StackColumn
          label="INPUT STACK"
          values={inputStack}
          highlightTop={isTransfer || operation?.type === 'enqueue'}
          transferDir={transferDir}
          side="left"
        />

        {/* Transfer arrow */}
        <div className="flex flex-col items-center justify-center pt-10 gap-1">
          <div className={['text-2xl transition-colors duration-300', isTransfer ? 'text-tertiary' : 'text-border'].join(' ')} aria-hidden>
            →
          </div>
          {isTransfer && (
            <span className="text-[9px] text-tertiary font-bold uppercase tracking-widest animate-pulse">
              transfer
            </span>
          )}
        </div>

        <StackColumn
          label="OUTPUT STACK"
          values={outputStack}
          highlightTop={operation?.type === 'dequeue' || operation?.type === 'front'}
          transferDir={transferDir}
          side="right"
        />
      </div>

      {/* Operation result */}
      <div className="mt-4">
        <OperationBadge operation={operation} result={result} />
      </div>

      {/* Logical queue order */}
      {logicalOrder.length > 0 && (
        <div className="mt-4 flex flex-col items-center gap-2">
          <p className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">
            Logical Queue Order
          </p>
          <div className="flex items-center gap-1.5 flex-wrap justify-center">
            <span className="text-label-caps text-primary">FRONT</span>
            {logicalOrder.map((v, i) => (
              <span key={i} className="flex items-center gap-1.5">
                <span className="font-mono text-code-md font-bold text-text-primary bg-elevated rounded px-2 py-0.5 border border-border">
                  {v}
                </span>
                {i < logicalOrder.length - 1 && <span className="text-text-secondary text-xs" aria-hidden>→</span>}
              </span>
            ))}
            <span className="text-label-caps text-secondary">REAR</span>
          </div>
        </div>
      )}

      <p aria-live="polite" aria-atomic="true" className="sr-only">{step?.description ?? ''}</p>
    </section>
  );
}
