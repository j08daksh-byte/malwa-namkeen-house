/**
 * BinaryTreeControls — input panel for Binary Tree visualizer.
 *
 * Independent of StackControls, QueueControls, and LinkedListControls.
 *
 * Props:
 *   initialTokensString   string   — pre-filled input (comma-separated level-order)
 *   onLoadTokens(tokens)  function — called with number|null[] on Apply
 *   onPause               function — called before loading when playing
 *   isPlaying             boolean  — playback state
 */

import { useState } from 'react';
import { parseLevelOrder } from '../../lib/treePreorderTraversal';

function randomTree() {
  const count = Math.floor(Math.random() * 5) + 4; // 4–8 nodes
  const vals  = [];
  for (let i = 0; i < count; i++) {
    vals.push(Math.floor(Math.random() * 20) + 1);
  }
  return vals.join(', ');
}

const EXAMPLES = [
  {
    label:    'Classic example',
    desc:     '7-node tree',
    sequence: '1, 2, 3, null, null, 4, 5',
  },
  {
    label:    'Balanced BST',
    desc:     'Complete binary tree',
    sequence: '4, 2, 6, 1, 3, 5, 7',
  },
  {
    label:    'Left-skewed',
    desc:     'Each node has only a left child',
    sequence: '5, 4, null, 3, null, 2',
  },
  {
    label:    'Single node',
    desc:     'Root only',
    sequence: '42',
  },
];

export default function BinaryTreeControls({
  initialTokensString,
  onLoadTokens,
  onPause,
  isPlaying,
}) {
  const [input, setInput] = useState(initialTokensString ?? '1, 2, 3, null, null, 4, 5');
  const [error, setError] = useState('');

  // ── Apply ──────────────────────────────────────────────────────────────────

  function applyTokens(seq) {
    if (isPlaying) onPause();
    const result = parseLevelOrder(seq);
    if (result.error) {
      setError(result.error);
      return;
    }
    setError('');
    onLoadTokens(result.tokens);
  }

  // ── Random ─────────────────────────────────────────────────────────────────

  function handleRandom() {
    const seq = randomTree();
    setInput(seq);
    setError('');
    applyTokens(seq);
  }

  return (
    <div className="flex flex-col gap-md overflow-y-auto p-md">

      {/* ── Input ───────────────────────────────────────────────────────── */}
      <div className="flex flex-col gap-xs">
        <label
          htmlFor="bt-tokens-input"
          className="text-label-caps font-semibold text-text-secondary uppercase tracking-widest"
        >
          Level-Order Values
        </label>
        <input
          id="bt-tokens-input"
          type="text"
          value={input}
          onChange={(e) => { setInput(e.target.value); setError(''); }}
          onKeyDown={(e) => { if (e.key === 'Enter') applyTokens(input); }}
          aria-describedby="bt-tokens-help bt-tokens-error"
          placeholder="e.g. 1, 2, 3, null, null, 4, 5"
          className={[
            'w-full rounded-lg bg-code-surface border font-mono text-code-md',
            'text-text-primary px-3 py-2',
            'focus:outline-none focus:ring-2 focus:ring-primary',
            'placeholder:text-text-secondary/50',
            error ? 'border-error' : 'border-border',
          ].join(' ')}
        />
        <p id="bt-tokens-help" className="text-body-sm text-text-secondary">
          Comma-separated level-order values. Use <code className="font-mono">null</code> or <code className="font-mono">N</code> for missing nodes. Values −99 to 999. Max 15 nodes.
        </p>
        {error && (
          <p id="bt-tokens-error" role="alert" className="text-body-sm text-error">
            {error}
          </p>
        )}

        {/* Action buttons */}
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => applyTokens(input)}
            className={[
              'px-md py-xs rounded-lg text-label-caps font-semibold uppercase tracking-widest',
              'bg-primary text-background transition-colors duration-150',
              'hover:bg-primary/80 active:scale-95',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary',
            ].join(' ')}
          >
            Apply
          </button>
          <button
            onClick={handleRandom}
            className={[
              'px-md py-xs rounded-lg text-label-caps font-semibold uppercase tracking-widest',
              'bg-elevated border border-border text-text-primary transition-colors duration-150',
              'hover:border-primary hover:text-primary active:scale-95',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary',
            ].join(' ')}
          >
            Random
          </button>
          <button
            onClick={() => {
              setInput('');
              setError('');
              applyTokens('');
            }}
            className={[
              'px-md py-xs rounded-lg text-label-caps font-semibold uppercase tracking-widest',
              'bg-elevated border border-border text-text-secondary transition-colors duration-150',
              'hover:border-border hover:text-text-primary active:scale-95',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary',
            ].join(' ')}
          >
            Clear
          </button>
        </div>
      </div>

      {/* ── Examples ─────────────────────────────────────────────────────── */}
      <div className="flex flex-col gap-xs">
        <p className="text-label-caps font-semibold text-text-secondary uppercase tracking-widest">
          Examples
        </p>
        <div className="flex flex-col gap-xs">
          {EXAMPLES.map((ex) => (
            <button
              key={ex.label}
              onClick={() => {
                setInput(ex.sequence);
                setError('');
                applyTokens(ex.sequence);
              }}
              className="flex flex-col items-start text-left rounded-lg border border-border bg-card
                         px-3 py-2 gap-0.5 hover:border-primary hover:bg-elevated/30
                         transition-colors duration-150 active:scale-[0.99]
                         focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
            >
              <span className="text-body-md font-semibold text-text-primary">{ex.label}</span>
              <span className="text-body-sm text-text-secondary">{ex.desc}</span>
              <span className="font-mono text-code-sm text-text-secondary/80 mt-0.5">
                {ex.sequence === '' ? '(empty)' : ex.sequence}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* ── Help ─────────────────────────────────────────────────────────── */}
      <div className="rounded-lg border border-border bg-code-surface px-3 py-2">
        <p className="text-body-sm text-text-secondary leading-relaxed">
          <span className="font-semibold text-text-primary">How it works:</span>{' '}
          Values are given in <span className="font-semibold text-text-primary">level-order</span> (BFS order), matching LeetCode&apos;s tree format.
          Preorder visits each node in Root → Left → Right order, shown step by step with the recursion call stack.
        </p>
      </div>
    </div>
  );
}
