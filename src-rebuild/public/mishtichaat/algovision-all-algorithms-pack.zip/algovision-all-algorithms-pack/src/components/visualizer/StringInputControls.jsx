/**
 * StringInputControls
 *
 * Single string input for Valid Parentheses.
 * Props: value, onChange, onRun, disabled, placeholder, label
 */

import { useState } from 'react';

const VALID_CHARS = new Set(['(', ')', '[', ']', '{', '}']);

function validateParens(str) {
  if (!str.length) return { valid: false, error: 'Input cannot be empty.' };
  if (str.length > 40) return { valid: false, error: 'Max 40 characters.' };
  for (const ch of str) {
    if (!VALID_CHARS.has(ch)) return { valid: false, error: `Invalid character: "${ch}". Use (, ), [, ], {, } only.` };
  }
  return { valid: true };
}

export default function StringInputControls({
  value = '',
  onChange,
  onRun,
  disabled = false,
  placeholder = '{[()]}',
  label = 'Bracket String',
}) {
  const [str, setStr]   = useState(value);
  const [error, setErr] = useState('');

  function handleRun() {
    const result = validateParens(str);
    if (!result.valid) { setErr(result.error); return; }
    setErr('');
    onChange?.(str);
    onRun?.();
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-col gap-1">
        <label className="text-label-caps text-text-secondary uppercase tracking-widest text-[10px]">
          {label}
        </label>
        <input
          className="input-field font-mono tracking-widest"
          type="text"
          value={str}
          onChange={e => { setStr(e.target.value); setErr(''); }}
          onKeyDown={e => e.key === 'Enter' && handleRun()}
          disabled={disabled}
          placeholder={placeholder}
          aria-label={label}
          maxLength={40}
        />
        <p className="text-[10px] text-text-secondary">Allowed: ( ) [ ] {'{ }'}</p>
      </div>

      {error && <p className="text-error text-code-sm" role="alert">{error}</p>}

      <button className="btn-primary mt-1" onClick={handleRun} disabled={disabled}>
        Visualize
      </button>
    </div>
  );
}
