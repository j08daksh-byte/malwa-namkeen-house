/**
 * QueueControls — input panel for Queue Operations visualizer.
 *
 * Independent of StackControls. Do NOT couple these two components.
 *
 * Props:
 *   initialOpsString  string   — pre-filled textarea content
 *   onLoadOps(ops)    function — called with parsed op array on Apply
 *   onPause           function — called before loading new ops if playing
 *   isPlaying         boolean  — playback state (used to gate pause call)
 */

import { useState } from 'react';
import { parseOperations } from '../../lib/queueOperations';

const EXAMPLES = [
  {
    label:   'Underflow demo',
    desc:    'Dequeue/front on empty queue',
    sequence: 'dequeue, front',
  },
  {
    label:   'isEmpty demo',
    desc:    'Check empty vs non-empty',
    sequence: 'isEmpty, enqueue 42, isEmpty',
  },
  {
    label:   'Full sequence',
    desc:    'Enqueue, inspect, dequeue',
    sequence: 'enqueue 10, enqueue 20, enqueue 30, front, dequeue, isEmpty',
  },
];

export default function QueueControls({
  initialOpsString,
  onLoadOps,
  onPause,
  isPlaying,
}) {
  const [input,      setInput]      = useState(initialOpsString ?? '');
  const [error,      setError]      = useState('');
  const [enqValue,   setEnqValue]   = useState('');
  const [enqError,   setEnqError]   = useState('');

  // ── Sequence apply ────────────────────────────────────────────────────────

  function applySequence(seq) {
    if (isPlaying) onPause();
    const result = parseOperations(seq);
    if (result.error) {
      setError(result.error);
      return;
    }
    setError('');
    onLoadOps(result.ops);
  }

  // ── Quick action helpers ──────────────────────────────────────────────────

  function appendOp(opStr) {
    const next = input.trim()
      ? `${input.trimEnd().replace(/,\s*$/, '')}, ${opStr}`
      : opStr;
    setInput(next);
  }

  function handleEnqueue() {
    const val = parseInt(enqValue, 10);
    if (isNaN(val) || !Number.isInteger(val) || val < -99 || val > 999) {
      setEnqError('Enter an integer between -99 and 999.');
      return;
    }
    setEnqError('');
    appendOp(`enqueue ${val}`);
    setEnqValue('');
  }

  return (
    <div className="flex flex-col gap-md overflow-y-auto p-md">

      {/* ── Sequence textarea ───────────────────────────────────────────── */}
      <div className="flex flex-col gap-xs">
        <label
          htmlFor="queue-ops-input"
          className="text-label-caps font-semibold text-text-secondary uppercase tracking-widest"
        >
          Operation Sequence
        </label>
        <textarea
          id="queue-ops-input"
          rows={3}
          value={input}
          onChange={(e) => { setInput(e.target.value); setError(''); }}
          aria-describedby={error ? 'queue-ops-error' : undefined}
          placeholder="e.g. enqueue 10, enqueue 20, front, dequeue, isEmpty"
          className={[
            'w-full resize-none rounded-lg bg-code-surface border font-mono text-code-md',
            'text-text-primary px-3 py-2 leading-relaxed',
            'focus:outline-none focus:ring-2 focus:ring-primary',
            'placeholder:text-text-secondary/50',
            error ? 'border-error' : 'border-border',
          ].join(' ')}
        />
        {error && (
          <p id="queue-ops-error" role="alert" className="text-body-sm text-error">
            {error}
          </p>
        )}
        <button
          onClick={() => applySequence(input)}
          className={[
            'self-end px-md py-xs rounded-lg text-label-caps font-semibold uppercase tracking-widest',
            'bg-primary text-background transition-colors duration-150',
            'hover:bg-primary/80 active:scale-95',
            'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary',
          ].join(' ')}
        >
          Apply
        </button>
      </div>

      {/* ── Quick actions ────────────────────────────────────────────────── */}
      <div className="flex flex-col gap-xs">
        <p className="text-label-caps font-semibold text-text-secondary uppercase tracking-widest">
          Quick Actions
        </p>

        {/* Enqueue with value input */}
        <div className="flex gap-2 items-start flex-wrap">
          <div className="flex flex-col gap-xs flex-1 min-w-[140px]">
            <div className="flex gap-2">
              <input
                type="number"
                value={enqValue}
                onChange={(e) => { setEnqValue(e.target.value); setEnqError(''); }}
                onKeyDown={(e) => { if (e.key === 'Enter') handleEnqueue(); }}
                placeholder="-99 to 999"
                min={-99}
                max={999}
                aria-label="Value to enqueue"
                className={[
                  'w-28 rounded-lg bg-code-surface border font-mono text-code-md',
                  'text-text-primary px-2 py-1.5',
                  'focus:outline-none focus:ring-2 focus:ring-secondary',
                  '[appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none',
                  '[&::-webkit-inner-spin-button]:appearance-none',
                  enqError ? 'border-error' : 'border-border',
                ].join(' ')}
              />
              <button
                onClick={handleEnqueue}
                className="px-3 py-1.5 rounded-lg text-label-caps font-semibold uppercase tracking-widest
                           bg-secondary/20 text-secondary border border-secondary/40
                           hover:bg-secondary/30 active:scale-95 transition-colors duration-150
                           focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-secondary"
              >
                Enqueue
              </button>
            </div>
            {enqError && (
              <p role="alert" className="text-body-sm text-error">{enqError}</p>
            )}
          </div>
        </div>

        {/* Dequeue, Front, isEmpty row */}
        <div className="flex gap-2 flex-wrap">
          {[
            { label: 'Dequeue', op: 'dequeue', style: 'bg-error/15 text-error border-error/40 hover:bg-error/25' },
            { label: 'Front',   op: 'front',   style: 'bg-tertiary/15 text-tertiary border-tertiary/40 hover:bg-tertiary/25' },
            { label: 'isEmpty', op: 'isEmpty', style: 'bg-primary/15 text-primary border-primary/40 hover:bg-primary/25' },
          ].map(({ label, op, style }) => (
            <button
              key={op}
              onClick={() => appendOp(op)}
              className={[
                'px-3 py-1.5 rounded-lg text-label-caps font-semibold uppercase tracking-widest',
                'border transition-colors duration-150 active:scale-95',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary',
                style,
              ].join(' ')}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Example sequences ────────────────────────────────────────────── */}
      <div className="flex flex-col gap-xs">
        <p className="text-label-caps font-semibold text-text-secondary uppercase tracking-widest">
          Examples
        </p>
        <div className="flex flex-col gap-xs">
          {EXAMPLES.map((ex) => (
            <button
              key={ex.label}
              onClick={() => {
                setInput(ex.sequence);
                setError('');
                applySequence(ex.sequence);
              }}
              className="flex flex-col items-start text-left rounded-lg border border-border bg-card
                         px-3 py-2 gap-0.5 hover:border-primary hover:bg-elevated/30
                         transition-colors duration-150 active:scale-[0.99]
                         focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
            >
              <span className="text-body-md font-semibold text-text-primary">{ex.label}</span>
              <span className="text-body-sm text-text-secondary">{ex.desc}</span>
              <span className="font-mono text-code-sm text-text-secondary/80 mt-0.5 break-all">
                {ex.sequence}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* ── Accepted syntax hint ─────────────────────────────────────────── */}
      <div className="rounded-lg border border-border bg-code-surface px-3 py-2">
        <p className="text-body-sm text-text-secondary leading-relaxed">
          <span className="font-semibold text-text-primary">Syntax:</span>{' '}
          Comma-separated.{' '}
          <span className="font-mono">enqueue &lt;value&gt;</span>,{' '}
          <span className="font-mono">dequeue</span>,{' '}
          <span className="font-mono">front</span> (alias: peek, getFront),{' '}
          <span className="font-mono">isEmpty</span>.{' '}
          Max 30 ops. Values −99 to 999.
        </p>
      </div>
    </div>
  );
}
