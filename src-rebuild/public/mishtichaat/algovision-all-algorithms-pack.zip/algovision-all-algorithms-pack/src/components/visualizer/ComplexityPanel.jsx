/**
 * ComplexityPanel
 *
 * Props:
 *   complexity  — array of { label, value, color, desc }
 *   properties  — array of { label, value, note }
 */
export default function ComplexityPanel({ complexity = [], properties = [] }) {
  return (
    <div className="flex-1 overflow-y-auto scrollbar-thin p-md flex flex-col gap-lg">

      {/* Time & Space */}
      <div>
        <p className="text-label-caps text-text-secondary uppercase tracking-widest mb-sm">
          Time &amp; Space Complexity
        </p>
        <div className="grid grid-cols-2 gap-sm">
          {complexity.map(({ label, value, color, desc }) => (
            <div
              key={label}
              className="bg-card rounded-lg border border-border p-md flex flex-col gap-xs"
            >
              <span className="text-label-caps text-text-secondary uppercase tracking-widest">
                {label}
              </span>
              <span className={['font-mono text-code-lg font-semibold', color].join(' ')}>
                {value}
              </span>
              <span className="text-body-md text-text-secondary">{desc}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Properties */}
      <div>
        <p className="text-label-caps text-text-secondary uppercase tracking-widest mb-sm">
          Properties
        </p>
        <div className="flex flex-col gap-xs">
          {properties.map(({ label, value, note }) => (
            <div
              key={label}
              className="flex items-center justify-between py-sm border-b border-border last:border-0"
            >
              <div>
                <span className="text-body-md text-text-primary font-semibold">{label}</span>
                <p className="text-body-md text-text-secondary">{note}</p>
              </div>
              <span
                className={[
                  'font-mono text-code-md font-semibold shrink-0 ml-md',
                  value === 'Yes' ? 'text-success' : 'text-text-secondary',
                ].join(' ')}
              >
                {value}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
