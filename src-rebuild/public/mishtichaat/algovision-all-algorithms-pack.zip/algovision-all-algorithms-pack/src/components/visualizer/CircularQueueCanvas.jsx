/**
 * CircularQueueCanvas
 *
 * Circular queue visualization with slots arranged in a circle.
 *
 * Step fields:
 *   step.slots      — array of values (null = empty)
 *   step.slotStates — array of 'empty'|'filled'|'front'|'rear'|'front-rear'|'active'
 *   step.front      — front index (-1 if empty)
 *   step.rear       — rear index (-1 if empty)
 *   step.size       — current number of elements
 *   step.capacity   — max capacity
 *   step.operation  — { type, value } | null
 *   step.result     — result value / 'OVERFLOW' / 'UNDERFLOW' / null
 *   step.description
 */

const SLOT_COLORS = {
  empty:      { ring: 'stroke-border',     fill: 'fill-elevated',     text: 'fill-text-secondary', label: '' },
  filled:     { ring: 'stroke-secondary/60', fill: 'fill-secondary/10', text: 'fill-text-primary',   label: '' },
  front:      { ring: 'stroke-primary',    fill: 'fill-primary/20',   text: 'fill-primary',        label: 'F' },
  rear:       { ring: 'stroke-tertiary',   fill: 'fill-tertiary/20',  text: 'fill-tertiary',       label: 'R' },
  'front-rear':{ ring: 'stroke-secondary', fill: 'fill-secondary/20', text: 'fill-secondary',      label: 'F/R' },
};

const CSS_COLORS = {
  'stroke-border':    '#244550',
  'stroke-secondary/60': 'rgba(53,208,186,0.6)',
  'stroke-primary':   '#FF6846',
  'stroke-tertiary':  '#F6C453',
  'stroke-secondary': '#35D0BA',
  'fill-elevated':    '#18333E',
  'fill-secondary/10':'rgba(53,208,186,0.1)',
  'fill-primary/20':  'rgba(255,104,70,0.2)',
  'fill-tertiary/20': 'rgba(246,196,83,0.2)',
  'fill-secondary/20':'rgba(53,208,186,0.2)',
  'fill-text-secondary':'#8aa4ad',
  'fill-text-primary': '#e2edf0',
  'fill-primary':     '#FF6846',
  'fill-tertiary':    '#F6C453',
  'fill-secondary':   '#35D0BA',
};

function c(cls) { return CSS_COLORS[cls] ?? '#244550'; }

function OperationBadge({ operation, result }) {
  if (!operation) return null;
  const isErr = result === 'OVERFLOW' || result === 'UNDERFLOW';
  const label = operation.type === 'enqueue'
    ? `ENQUEUE ${operation.value}`
    : 'DEQUEUE';
  return (
    <div className={[
      'flex items-center gap-2 px-md py-sm rounded-lg border',
      isErr ? 'bg-error/10 border-error/30' : 'bg-secondary/10 border-secondary/30',
    ].join(' ')}>
      <span className={['text-label-caps font-bold uppercase tracking-widest', isErr ? 'text-error' : 'text-secondary'].join(' ')}>
        {label}
      </span>
      {result != null && (
        <>
          <span className="text-text-secondary">→</span>
          <span className={['font-mono text-code-md font-bold', isErr ? 'text-error' : 'text-success'].join(' ')}>
            {String(result)}
          </span>
        </>
      )}
    </div>
  );
}

export default function CircularQueueCanvas({ step }) {
  const slots     = step?.slots ?? [];
  const states    = step?.slotStates ?? [];
  const front     = step?.front ?? -1;
  const rear      = step?.rear ?? -1;
  const size      = step?.size ?? 0;
  const capacity  = step?.capacity ?? 4;
  const operation = step?.operation ?? null;
  const result    = step?.result ?? null;

  const n = Math.max(capacity, slots.length, 2);
  const SVG_SIZE = 260;
  const CX = SVG_SIZE / 2;
  const CY = SVG_SIZE / 2;
  const RADIUS = 90;
  const SLOT_R = 26;

  const slotPositions = Array.from({ length: n }, (_, i) => {
    const angle = (2 * Math.PI * i) / n - Math.PI / 2;
    return {
      x: CX + RADIUS * Math.cos(angle),
      y: CY + RADIUS * Math.sin(angle),
    };
  });

  return (
    <section
      className="flex-[1.2] canvas-dot-grid relative flex flex-col items-center justify-start px-md pt-12 pb-4 bg-background overflow-y-auto"
      aria-label="Circular queue visualization"
    >
      {/* Description badge */}
      <div
        className="absolute top-4 left-4 right-4 flex items-center gap-2 bg-nav/90 backdrop-blur-sm px-sm py-1.5 rounded-lg border border-border"
        aria-hidden
      >
        <span className={[
          'w-2 h-2 shrink-0 rounded-full',
          result === 'OVERFLOW' || result === 'UNDERFLOW' ? 'bg-error animate-pulse' :
          step?.type === 'completed' ? 'bg-success' : 'bg-secondary animate-pulse',
        ].join(' ')} />
        <p className="font-mono text-code-md text-text-body truncate">
          {step?.description ?? 'Loading…'}
        </p>
      </div>

      {/* SVG Circular display */}
      <svg
        width={SVG_SIZE}
        height={SVG_SIZE}
        viewBox={`0 0 ${SVG_SIZE} ${SVG_SIZE}`}
        className="mt-4"
        aria-label={`Circular queue with capacity ${n}`}
      >
        {/* Track circle */}
        <circle cx={CX} cy={CY} r={RADIUS} fill="none" stroke={c('stroke-border')} strokeWidth={1} strokeDasharray="4 4" />

        {slotPositions.map(({ x, y }, i) => {
          const slotState = states[i] ?? (slots[i] != null ? 'filled' : 'empty');
          const sc = SLOT_COLORS[slotState] ?? SLOT_COLORS.empty;
          const val = slots[i];
          const badgeLabel = sc.label;

          return (
            <g key={i}>
              {/* Slot circle */}
              <circle
                cx={x}
                cy={y}
                r={SLOT_R}
                fill={c(sc.fill)}
                stroke={c(sc.ring)}
                strokeWidth={slotState === 'empty' ? 1 : 2}
              />
              {/* Value */}
              {val != null && (
                <text
                  x={x}
                  y={y + 1}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fontSize={13}
                  fontWeight="700"
                  fontFamily="monospace"
                  fill={c(sc.text)}
                >
                  {val}
                </text>
              )}
              {/* Index label below slot */}
              <text
                x={x}
                y={y + SLOT_R + 11}
                textAnchor="middle"
                fontSize={9}
                fill={c('fill-text-secondary')}
              >
                [{i}]
              </text>
              {/* F/R badge above slot */}
              {badgeLabel && (
                <text
                  x={x}
                  y={y - SLOT_R - 4}
                  textAnchor="middle"
                  fontSize={8}
                  fontWeight="700"
                  fill={c(sc.text)}
                >
                  {badgeLabel}
                </text>
              )}
            </g>
          );
        })}

        {/* Center info */}
        <text x={CX} y={CY - 10} textAnchor="middle" fontSize={10} fill={c('fill-text-secondary')}>
          size: {size}/{n}
        </text>
        <text x={CX} y={CY + 6} textAnchor="middle" fontSize={9} fill={c('fill-text-secondary')}>
          F:{front} R:{rear}
        </text>
      </svg>

      {/* Operation pill */}
      <div className="mt-3">
        <OperationBadge operation={operation} result={result} />
      </div>

      {/* Legend */}
      <div className="mt-4 flex flex-wrap justify-center gap-x-4 gap-y-2">
        {[
          { color: 'bg-secondary/20 border border-secondary/60', label: 'Filled' },
          { color: 'bg-primary/20 border border-primary', label: 'Front (F)' },
          { color: 'bg-tertiary/20 border border-tertiary', label: 'Rear (R)' },
          { color: 'bg-elevated border border-border', label: 'Empty' },
        ].map(({ color, label }) => (
          <div key={label} className="flex items-center gap-2">
            <span className={['w-3 h-3 rounded-full shrink-0', color].join(' ')} aria-hidden />
            <span className="text-label-caps text-text-body">{label}</span>
          </div>
        ))}
      </div>

      <p aria-live="polite" aria-atomic="true" className="sr-only">{step?.description ?? ''}</p>
    </section>
  );
}
