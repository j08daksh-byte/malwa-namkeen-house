/**
 * TwoPointerCanvas
 *
 * Array-cell renderer for two-pointer algorithms (e.g. Reverse Array).
 * Shows each element as a cell with value + index + state label.
 * A pointer row above the cells displays L / R markers.
 *
 * Props:
 *   step   — current step object (or null while loading)
 *   legend — array of { state, color, label } from the registry
 */

const reducedMotion =
  typeof window !== 'undefined' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;

// ── Cell visual style map ──────────────────────────────────────────────────
const CELL_STYLE = {
  default:   { bg: 'bg-elevated border-border',       text: 'text-text-secondary' },
  left:      { bg: 'bg-secondary border-secondary',   text: 'text-background'     },
  right:     { bg: 'bg-primary border-primary',       text: 'text-background'     },
  comparing: { bg: 'bg-tertiary border-tertiary',     text: 'text-background'     },
  swapping:  { bg: 'bg-error border-error',           text: 'text-background'     },
  completed: { bg: 'bg-success border-success',       text: 'text-background'     },
};

// Small state labels shown inside each cell
const STATE_LABEL = {
  default:   '',
  left:      '',
  right:     '',
  comparing: '↔',
  swapping:  '↕',
  completed: '✓',
};

// ── State derivation ───────────────────────────────────────────────────────
function getCellState(i, step) {
  if (!step) return 'default';
  const { type, left, right, comparing, swapping } = step;

  if (type === 'completed')           return 'completed';
  if (swapping?.includes(i))          return 'swapping';
  if (comparing?.includes(i))         return 'comparing';
  if (left === i && right === i)       return 'left';   // same index — teal
  if (left === i)                      return 'left';
  if (right === i)                     return 'right';
  return 'default';
}

// ── Pointer row (L / R labels above cells) ─────────────────────────────────
function PointerRow({ n, left, right }) {
  if (left == null && right == null) return <div className="h-5" aria-hidden />;

  return (
    <div className="flex gap-1.5 justify-center" aria-hidden>
      {Array.from({ length: n }, (_, i) => {
        const isL = left  === i;
        const isR = right === i;
        if (!isL && !isR) return <div key={i} className="w-11 h-5 shrink-0" />;
        return (
          <div key={i} className="w-11 h-5 flex items-center justify-center gap-px shrink-0">
            {isL && (
              <span className="text-[11px] font-bold font-mono text-secondary leading-none">L</span>
            )}
            {isR && (
              <span className="text-[11px] font-bold font-mono text-primary leading-none">R</span>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ── Single cell ────────────────────────────────────────────────────────────
function Cell({ value, index, state, transition }) {
  const { bg, text } = CELL_STYLE[state] ?? CELL_STYLE.default;
  const label = STATE_LABEL[state] ?? '';

  const ariaStates = {
    default:   'unprocessed',
    left:      'left pointer',
    right:     'right pointer',
    comparing: 'comparing',
    swapping:  'swapping',
    completed: 'reversed',
  };

  return (
    <div
      className={[
        'w-11 shrink-0 flex flex-col items-center rounded border-2 select-none',
        bg,
        transition,
      ].join(' ')}
      aria-label={`Value ${value} at index ${index}${label ? `, ${ariaStates[state] ?? state}` : ''}`}
    >
      {/* State label — reserves space to prevent layout shift */}
      <span className={['text-[9px] font-bold uppercase tracking-wider leading-none pt-1 h-3.5', text].join(' ')}>
        {label}
      </span>
      {/* Value */}
      <span className={['font-mono text-lg font-bold leading-tight', text].join(' ')}>
        {value}
      </span>
      {/* Index */}
      <span className={['font-mono text-[10px] pb-1 leading-none opacity-70', text].join(' ')}>
        {index}
      </span>
    </div>
  );
}

// ── Dot color for description badge ───────────────────────────────────────
function badgeDotClass(type) {
  switch (type) {
    case 'swapping':     return 'bg-error animate-pulse';
    case 'comparing':    return 'bg-tertiary animate-pulse';
    case 'completed':    return 'bg-success';
    case 'pointer-move': return 'bg-secondary';
    case 'pointer-init': return 'bg-secondary';
    default:             return 'bg-secondary';
  }
}

// ── Main component ─────────────────────────────────────────────────────────
export default function TwoPointerCanvas({ step, legend = [] }) {
  const array     = step?.array ?? [];
  const left      = step?.left  ?? null;
  const right     = step?.right ?? null;
  const hasPointers = left !== null || right !== null;
  const transition  = reducedMotion ? '' : 'transition-colors duration-200';

  return (
    <section
      className="flex-[1.2] canvas-dot-grid relative flex flex-col items-center justify-center px-lg pt-12 pb-4 bg-background"
      aria-label="Algorithm visualisation canvas"
    >
      {/* ── Step description badge ──────────────────────────────────── */}
      <div
        className="absolute top-4 left-4 right-4 flex items-center gap-2 bg-nav/90 backdrop-blur-sm px-sm py-1.5 rounded-lg border border-border max-w-full"
        aria-hidden
      >
        <span className={['w-2 h-2 shrink-0 rounded-full', badgeDotClass(step?.type)].join(' ')} />
        <p className="font-mono text-code-md text-text-body truncate">
          {step?.description ?? 'Loading…'}
        </p>
      </div>

      {/* ── Pointer row (L / R) ───────────────────────────────────── */}
      <div className="w-full overflow-x-auto scrollbar-none">
        <div className="flex justify-center min-w-max mx-auto">
          {hasPointers ? (
            <PointerRow n={array.length} left={left} right={right} />
          ) : (
            <div className="h-5" aria-hidden />
          )}
        </div>
      </div>

      {/* ── Cell row ────────────────────────────────────────────────── */}
      <div className="w-full overflow-x-auto scrollbar-none py-1">
        <div
          className="flex gap-1.5 justify-center min-w-max mx-auto"
          role="img"
          aria-label={`Array of ${array.length} elements`}
        >
          {array.map((val, i) => (
            <Cell
              key={i}
              value={val}
              index={i}
              state={getCellState(i, step)}
              transition={transition}
            />
          ))}
        </div>
      </div>

      {/* ── Screen-reader pointer announcement ───────────────────── */}
      {hasPointers && (
        <p className="sr-only">
          {left  !== null && `Left pointer at index ${left}, value ${array[left]}. `}
          {right !== null && `Right pointer at index ${right}, value ${array[right]}.`}
        </p>
      )}

      {/* ── Legend ──────────────────────────────────────────────────── */}
      <div
        className="mt-4 flex flex-wrap justify-center gap-x-6 gap-y-2"
        aria-label="Colour state legend"
      >
        {legend.map(({ color, label }) => (
          <div key={label} className="flex items-center gap-2">
            <span className={['w-3 h-3 rounded-full shrink-0', color].join(' ')} aria-hidden />
            <span className="text-label-caps text-text-body">{label}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
