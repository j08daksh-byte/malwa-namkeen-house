import { useEffect, useRef, useState } from 'react';
import { Copy, Check } from 'lucide-react';

/**
 * CodePanel
 *
 * Props:
 *   codeTemplates — { cpp, javascript, python } from the algorithm registry
 *     each entry: { label, lines: [{text}], fullCode, lineMap }
 *   activeLang    — 'cpp' | 'javascript' | 'python'
 *   onLangChange  — (lang: string) => void
 *   activeLine    — 0-based index into the current language's lines (already resolved)
 */

const LANG_ORDER = ['cpp', 'javascript', 'python'];

export default function CodePanel({
  codeTemplates = {},
  activeLang    = 'cpp',
  onLangChange,
  activeLine    = 0,
}) {
  const activeRef = useRef(null);
  const [copied, setCopied]   = useState(false);

  const template = codeTemplates[activeLang] ?? Object.values(codeTemplates)[0];
  const lines    = template?.lines    ?? [];
  const fullCode = template?.fullCode ?? '';
  const label    = template?.label    ?? activeLang;

  // Auto-scroll active line into view
  useEffect(() => {
    if (activeRef.current) {
      activeRef.current.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
  }, [activeLine, activeLang]);

  function handleCopy() {
    if (!fullCode) return;
    navigator.clipboard.writeText(fullCode).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  // The available language keys, in canonical order
  const availableLangs = LANG_ORDER.filter(k => codeTemplates[k]);

  return (
    <div className="flex flex-col flex-1 overflow-hidden bg-code-surface">

      {/* ── Language selector + copy ──────────────────────────────────── */}
      <div className="flex items-center justify-between px-md py-1.5 border-b border-border shrink-0 gap-sm">

        {/* Language tabs */}
        <div
          className="flex gap-0.5 min-w-0"
          role="tablist"
          aria-label="Select programming language"
        >
          {availableLangs.map((lang) => {
            const isActive = lang === activeLang;
            const tmpl     = codeTemplates[lang];
            return (
              <button
                key={lang}
                role="tab"
                aria-selected={isActive}
                onClick={() => onLangChange?.(lang)}
                className={[
                  'px-sm py-0.5 rounded text-label-caps font-semibold uppercase tracking-widest',
                  'transition-colors duration-150 whitespace-nowrap',
                  'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary',
                  'min-h-[2rem] min-w-[2.75rem]',
                  isActive
                    ? 'bg-primary/15 text-primary border border-primary/30'
                    : 'text-text-secondary hover:text-text-primary hover:bg-elevated/50 border border-transparent',
                ].join(' ')}
              >
                {tmpl?.label ?? lang}
              </button>
            );
          })}
        </div>

        {/* Copy button */}
        <button
          onClick={handleCopy}
          aria-label={copied ? `${label} code copied` : `Copy ${label} code`}
          disabled={!fullCode}
          className={[
            'flex items-center gap-1 text-label-caps font-semibold uppercase tracking-widest px-sm py-xs rounded shrink-0',
            'transition-colors duration-150',
            'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary',
            'disabled:opacity-30 disabled:cursor-not-allowed',
            copied
              ? 'text-success'
              : 'text-text-secondary hover:text-text-primary',
          ].join(' ')}
        >
          {copied ? <Check size={14} aria-hidden /> : <Copy size={14} aria-hidden />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>

      {/* ── Code lines ────────────────────────────────────────────────── */}
      {lines.length === 0 ? (
        <div className="flex-1 flex items-center justify-center text-text-secondary text-body-md p-lg">
          No code available for {label}.
        </div>
      ) : (
        <div
          className="flex-1 overflow-y-auto scrollbar-thin p-md font-mono"
          role="region"
          aria-label={`${label} source code`}
        >
          <div className="space-y-0">
            {lines.map((line, i) => {
              const isActive = i === activeLine;
              return (
                <div
                  key={i}
                  ref={isActive ? activeRef : null}
                  aria-current={isActive ? 'true' : undefined}
                  className={[
                    'flex gap-3 py-0.5 leading-relaxed rounded-r',
                    isActive
                      ? 'code-line-active -mx-md px-md'
                      : 'opacity-60',
                  ].join(' ')}
                >
                  <span
                    className={[
                      'w-5 text-right shrink-0 text-code-md select-none',
                      isActive ? 'text-secondary font-semibold' : 'text-text-secondary',
                    ].join(' ')}
                    aria-hidden
                  >
                    {i + 1}
                  </span>
                  <span
                    className={[
                      'text-code-md whitespace-pre',
                      isActive ? 'text-secondary font-semibold' : 'text-text-body',
                    ].join(' ')}
                  >
                    {line.text}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
