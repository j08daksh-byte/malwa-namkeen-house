/**
 * ArrayInspectCanvas
 *
 * Reusable array visualization for inspect-style algorithms:
 *   - Largest Element
 *   - Left Rotate by K
 *   - Kadane's Maximum Subarray
 *
 * Step fields used:
 *   step.array        — the current array
 *   step.cellStates   — { [index]: 'default'|'current'|'max'|'subarray'|'candidate'|'completed'|'swap-a'|'swap-b' }
 *   step.infoItems    — [{ label, value, color }] (shown in info bar)
 *   step.description  — human-readable step description
 */

const CELL_STYLE = {
  default:   { bg: 'bg-elevated border-border',       text: 'text-text-secondary', label: ''      },
  current:   { bg: 'bg-primary border-primary',       text: 'text-background',     label: 'CHECK' },
  max:       { bg: 'bg-secondary border-secondary',   text: 'text-background',     label: 'MAX'   },
  subarray:  { bg: 'bg-tertiary/30 border-tertiary',  text: 'text-tertiary',       label: 'SUB'   },
  candidate: { bg: 'bg-primary/40 border-primary',    text: 'text-text-primary',   label: 'CAND'  },
  completed: { bg: 'bg-success/20 border-success',    text: 'text-success',        label: '✓'     },
  'swap-a':  { bg: 'bg-error/80 border-error',        text: 'text-background',     label: 'SWAP'  },
  'swap-b':  { bg: 'bg-error/60 border-error',        text: 'text-background',     label: 'SWAP'  },
};

function Cell({ value, index, state }) {
  const style = CELL_STYLE[state] ?? CELL_STYLE.default;
  return (
    <div
      className={['w-11 shrink-0 flex flex-col items-center rounded border-2 select-none transition-colors duration-200', style.bg].join(' ')}
      aria-label={`Index ${index}: ${value}${style.label ? `, ${style.label}` : ''}`}
    >
      <span className={['text-[9px] font-bold uppercase tracking-wider leading-none pt-1 h-3.5', style.text].join(' ')}>
        {style.label}
      </span>
      <span className={['font-mono text-lg font-bold leading-tight', style.text].join(' ')}>
        {value}
      </span>
      <span className={['font-mono text-[10px] pb-1 leading-none opacity-70', style.text].join(' ')}>
        {index}
      </span>
    </div>
  );
}

function InfoBar({ items = [] }) {
  if (!items.length) return null;
  return (
    <div className="flex flex-wrap justify-center gap-x-6 gap-y-2 mt-4 px-4">
      {items.map((item, i) => (
        <div key={i} className="flex items-center gap-2 bg-nav/80 rounded-lg px-sm py-xs border border-border">
          <span className="text-label-caps text-text-secondary uppercase tracking-widest whitespace-nowrap">
            {item.label}:
          </span>
          <span className={['font-mono text-code-md font-bold', item.color ?? 'text-text-primary'].join(' ')}>
            {String(item.value)}
          </span>
        </div>
      ))}
    </div>
  );
}

export default function ArrayInspectCanvas({ step, legend = [] }) {
  const array     = step?.array ?? [];
  const states    = step?.cellStates ?? {};
  const infoItems = step?.infoItems ?? [];

  return (
    <section
      className="flex-[1.2] canvas-dot-grid relative flex flex-col items-center justify-center px-lg pt-12 pb-4 bg-background"
      aria-label="Array visualization canvas"
    >
      {/* Description badge */}
      <div
        className="absolute top-4 left-4 right-4 flex items-center gap-2 bg-nav/90 backdrop-blur-sm px-sm py-1.5 rounded-lg border border-border"
        aria-hidden
      >
        <span className={[
          'w-2 h-2 shrink-0 rounded-full',
          step?.type === 'completed' ? 'bg-success' :
          step?.type === 'new-max' || step?.type === 'new-best' ? 'bg-secondary animate-pulse' :
          step?.type === 'swap' ? 'bg-error animate-pulse' :
          'bg-primary animate-pulse',
        ].join(' ')} />
        <p className="font-mono text-code-md text-text-body truncate">
          {step?.description ?? 'Loading…'}
        </p>
      </div>

      {/* Cell row */}
      <div className="w-full overflow-x-auto scrollbar-none py-1">
        <div
          className="flex gap-1.5 justify-center min-w-max mx-auto"
          role="img"
          aria-label={`Array of ${array.length} elements`}
        >
          {array.map((val, i) => (
            <Cell
              key={i}
              value={val}
              index={i}
              state={states[i] ?? 'default'}
            />
          ))}
        </div>
      </div>

      {/* Info bar */}
      <InfoBar items={infoItems} />

      {/* Legend */}
      {legend.length > 0 && (
        <div className="mt-4 flex flex-wrap justify-center gap-x-6 gap-y-2" aria-label="Legend">
          {legend.map(({ color, label }) => (
            <div key={label} className="flex items-center gap-2">
              <span className={['w-3 h-3 rounded-full shrink-0', color].join(' ')} aria-hidden />
              <span className="text-label-caps text-text-body">{label}</span>
            </div>
          ))}
        </div>
      )}

      <p aria-live="polite" aria-atomic="true" className="sr-only">{step?.description ?? ''}</p>
    </section>
  );
}
