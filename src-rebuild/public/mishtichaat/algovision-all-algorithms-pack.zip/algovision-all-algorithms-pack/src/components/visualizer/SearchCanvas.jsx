/**
 * SearchCanvas
 *
 * Renders the search algorithm visualization as a row of value cells.
 * Supports Linear Search and Binary Search with pointer labels (L / M / R).
 *
 * Props:
 *   step   — current step object (or null while loading)
 *   legend — array of { state, color, label } entries from the registry
 */

const reducedMotion =
  typeof window !== 'undefined' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;

// ── Cell visual styles ─────────────────────────────────────────────────────
const CELL_STYLE = {
  unchecked:  { bg: 'bg-card border-border',          text: 'text-text-secondary', dim: ''             },
  comparing:  { bg: 'bg-primary border-primary',      text: 'text-background',     dim: ''             },
  visited:    { bg: 'bg-secondary border-secondary',  text: 'text-background',     dim: ''             },
  eliminated: { bg: 'bg-card border-border',          text: 'text-text-secondary', dim: 'opacity-30'   },
  found:      { bg: 'bg-success border-success',      text: 'text-background',     dim: ''             },
  'not-found-active': { bg: 'bg-error border-error',  text: 'text-background',     dim: ''             },
};

// ── State derivation ───────────────────────────────────────────────────────
function getCellState(index, step) {
  if (!step) return 'unchecked';
  const { type, found, comparing, active, visited, eliminated } = step;

  if (found?.includes(index))       return 'found';
  if (type === 'not-found' && active?.includes(index)) return 'not-found-active';
  if (comparing?.includes(index))   return 'comparing';
  if (active?.includes(index))      return 'comparing';
  if (visited?.includes(index))     return 'visited';
  if (eliminated?.includes(index))  return 'eliminated';
  return 'unchecked';
}

// ── State label for each cell ──────────────────────────────────────────────
const STATE_LABEL = {
  comparing:        'Checking',
  visited:          'Visited',
  eliminated:       'Out',
  found:            'Found',
  'not-found-active': '✕',
  unchecked:        '',
};

// ── Pointer row for Binary Search ──────────────────────────────────────────
function PointerRow({ array, pointers }) {
  if (!array.length) return null;
  const { left, right, middle } = pointers;
  const anyPointer = left !== null || right !== null || middle !== null;
  if (!anyPointer) return null;

  return (
    <div
      className="flex gap-1.5 justify-center"
      aria-hidden="true"
    >
      {array.map((_, i) => {
        const isL = left   === i;
        const isM = middle === i;
        const isR = right  === i;
        if (!isL && !isM && !isR) return <div key={i} className="w-11 h-5 shrink-0" />;
        return (
          <div key={i} className="w-11 h-5 flex items-center justify-center gap-px shrink-0">
            {isL && <span className="text-[11px] font-bold font-mono text-primary leading-none">L</span>}
            {isM && <span className="text-[11px] font-bold font-mono text-tertiary leading-none">M</span>}
            {isR && <span className="text-[11px] font-bold font-mono text-success leading-none">R</span>}
          </div>
        );
      })}
    </div>
  );
}

// ── Single cell ────────────────────────────────────────────────────────────
function Cell({ value, index, state, transition }) {
  const { bg, text, dim } = CELL_STYLE[state] ?? CELL_STYLE.unchecked;
  const label = STATE_LABEL[state] ?? '';

  return (
    <div
      className={['w-11 shrink-0 flex flex-col items-center rounded border-2 select-none', bg, dim, transition].join(' ')}
      aria-label={`Value ${value} at index ${index}${label ? `, ${label}` : ''}`}
    >
      {/* State label — always reserve space so cells don't shift */}
      <span className={['text-[9px] font-bold uppercase tracking-wider leading-none pt-1 h-3.5', text].join(' ')}>
        {label}
      </span>
      {/* Value */}
      <span className={['font-mono text-lg font-bold leading-tight', text].join(' ')}>
        {value}
      </span>
      {/* Index */}
      <span className={['font-mono text-[10px] pb-1 leading-none opacity-70', text].join(' ')}>
        {index}
      </span>
    </div>
  );
}

// ── Main component ─────────────────────────────────────────────────────────
export default function SearchCanvas({ step, legend = [] }) {
  const array    = step?.array    ?? [];
  const pointers = step?.pointers ?? { left: null, right: null, middle: null };
  const hasPointers = pointers.left !== null || pointers.right !== null || pointers.middle !== null;

  const transition = reducedMotion ? '' : 'transition-colors duration-200';

  return (
    <section
      className="flex-[1.2] canvas-dot-grid relative flex flex-col items-center justify-center px-lg pt-12 pb-4 bg-background"
      aria-label="Algorithm visualisation canvas"
    >
      {/* ── Step description badge ──────────────────────────────────── */}
      <div
        className="absolute top-4 left-4 right-4 flex items-center gap-2 bg-nav/90 backdrop-blur-sm px-sm py-1.5 rounded-lg border border-border max-w-full"
        aria-hidden="true"
      >
        <span
          className={[
            'w-2 h-2 shrink-0 rounded-full',
            step?.type === 'found'     ? 'bg-success' :
            step?.type === 'not-found' ? 'bg-error animate-pulse' :
            step?.type === 'comparing' ? 'bg-primary animate-pulse' :
            'bg-secondary',
          ].join(' ')}
        />
        <p className="font-mono text-code-md text-text-body truncate">
          {step?.description ?? 'Loading…'}
        </p>
      </div>

      {/* ── Target badge ──────────────────────────────────────────── */}
      {step?.target != null && (
        <div className="mb-3 flex items-center gap-2">
          <span className="text-label-caps text-text-secondary uppercase tracking-widest">Target</span>
          <span className="font-mono text-code-lg font-bold text-tertiary bg-tertiary/10 border border-tertiary/30 px-sm py-xs rounded">
            {step.target}
          </span>
        </div>
      )}

      {/* ── Pointer labels (Binary Search) ───────────────────────── */}
      {hasPointers && (
        <div className="w-full overflow-x-auto scrollbar-none">
          <div className="flex justify-center min-w-max mx-auto">
            <PointerRow array={array} pointers={pointers} />
          </div>
        </div>
      )}

      {/* ── Cell row ────────────────────────────────────────────────── */}
      <div className="w-full overflow-x-auto scrollbar-none py-1">
        <div
          className="flex gap-1.5 justify-center min-w-max mx-auto"
          role="img"
          aria-label={`Search array of ${array.length} elements`}
        >
          {array.map((val, i) => (
            <Cell
              key={i}
              value={val}
              index={i}
              state={getCellState(i, step)}
              transition={transition}
            />
          ))}
        </div>
      </div>

      {/* ── Pointer legend (screen reader) ───────────────────────── */}
      {hasPointers && (
        <p className="sr-only">
          {pointers.left   !== null && `Left pointer at index ${pointers.left}. `}
          {pointers.middle !== null && `Middle pointer at index ${pointers.middle}. `}
          {pointers.right  !== null && `Right pointer at index ${pointers.right}.`}
        </p>
      )}

      {/* ── Visual legend ───────────────────────────────────────────── */}
      <div
        className="mt-4 flex flex-wrap justify-center gap-x-6 gap-y-2"
        aria-label="Colour state legend"
      >
        {legend.map(({ color, label }) => (
          <div key={label} className="flex items-center gap-2">
            <span className={['w-3 h-3 rounded-full shrink-0', color].join(' ')} aria-hidden />
            <span className="text-label-caps text-text-body">{label}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
