import { useEffect, useMemo, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ALGORITHM_REGISTRY } from '../lib/algorithmRegistry.js';
import { parseBfsInput } from '../lib/graphBfs.js';
import { useAlgorithmPlayer } from '../hooks/useAlgorithmPlayer.js';

import Badge from '../components/ui/Badge.jsx';
import Button from '../components/ui/Button.jsx';
import Card from '../components/ui/Card.jsx';
import CanvasRenderer from '../components/visualizer/CanvasRenderer.jsx';
import ControlRenderer from '../components/visualizer/ControlRenderer.jsx';
import PlaybackControls from '../components/visualizer/PlaybackControls.jsx';
import PseudocodePanel from '../components/visualizer/PseudocodePanel.jsx';
import CodePanel from '../components/visualizer/CodePanel.jsx';
import ComplexityPanel from '../components/visualizer/ComplexityPanel.jsx';

const GRAPH_STRINGS = {
  nodes: '0, 1, 2, 3, 4, 5',
  edges: '0:1, 0:2, 1:3, 1:4, 2:5',
  start: '0',
};

const DEFAULTS_BY_ID = {
  'array-move-zeroes': { array: [0, 1, 0, 3, 12] },
  'array-two-sum': { array: [2, 7, 11, 15], target: 9 },
  'array-kadane': { array: [-2, 1, -3, 4, -1, 2, 1, -5, 4] },
  'array-frequency-count': { array: [2, 3, 2, 5, 3, 2] },
  'array-left-rotate-k': { array: [1, 2, 3, 4, 5], k: 2 },
  'binary-search-lower-bound': { array: [1, 2, 4, 4, 7], target: 4 },
  'binary-search-upper-bound': { array: [1, 2, 4, 4, 7], target: 4 },
  'binary-search-first-last': { array: [1, 2, 2, 2, 3, 4], target: 2 },
  'binary-search-rotated-array': { array: [4, 5, 6, 7, 0, 1, 2], target: 0 },
  'stack-next-greater-element': { array: [4, 5, 2, 10, 8] },
};

function generateSteps(algorithm, model) {
  const type = algorithm.controlType ?? (
    algorithm.visualizationType === 'searching' ? 'array-target' : 'array-basic'
  );

  switch (type) {
    case 'array-target':
      return algorithm.generateSteps(model.array, model.target);
    case 'array-k':
      return algorithm.generateSteps(model.array, model.k);
    case 'array-basic':
    case 'array-signed':
      return algorithm.generateSteps(model.array);
    case 'stack-operations':
    case 'queue-operations':
      return algorithm.generateSteps(model.operationInput);
    case 'linked-list-values':
      return algorithm.generateSteps(model.listValues);
    case 'll-insert':
      return algorithm.generateSteps({ values: model.listValues, position: model.position, newValue: model.newValue });
    case 'll-delete':
      return algorithm.generateSteps({ values: model.listValues, deleteIndex: model.deleteIndex });
    case 'll-cycle':
      return algorithm.generateSteps({ values: model.listValues, cycleEntry: model.cycleEntry });
    case 'graph-bfs-input':
    case 'graph-traversal-input':
    case 'graph-structure-input':
      return algorithm.generateSteps(model.graphInput);
    case 'binary-tree-tokens':
      return algorithm.generateSteps(model.treeTokens);
    case 'string-input':
      return algorithm.generateSteps(model.stringInput);
    case 'circular-queue-ops':
      return algorithm.generateSteps(model.circularQueueInput);
    case 'queue-two-stacks-ops':
      return algorithm.generateSteps(model.twoStacksInput);
    default:
      if (algorithm.visualizationType === 'searching') {
        return algorithm.generateSteps(model.array, model.target);
      }
      return algorithm.generateSteps(model.array);
  }
}

function useInputModel(id) {
  const defaults = DEFAULTS_BY_ID[id] ?? {};
  const [array, setArray] = useState(defaults.array ?? [42, 17, 8, 31, 25]);
  const [target, setTarget] = useState(defaults.target ?? 31);
  const [k, setK] = useState(defaults.k ?? 2);
  const [operationInput, setOperationInput] = useState('push 10, push 20, peek, pop, isEmpty');
  const [listValues, setListValues] = useState([10, 20, 30, 40]);
  const [position, setPosition] = useState(2);
  const [newValue, setNewValue] = useState(25);
  const [deleteIndex, setDeleteIndex] = useState(1);
  const [cycleEntry, setCycleEntry] = useState(1);
  const [stringInput, setStringInput] = useState('({[]})');
  const [treeTokens, setTreeTokens] = useState([1, 2, 3, null, null, 4, 5]);
  const [circularQueueInput, setCircularQueueInput] = useState(
    'capacity: 4, enqueue 10, enqueue 20, enqueue 30, dequeue, enqueue 40, enqueue 50',
  );
  const [twoStacksInput, setTwoStacksInput] = useState(
    'enqueue 10, enqueue 20, front, dequeue, enqueue 30, dequeue',
  );
  const graphStrings = GRAPH_STRINGS;
  const [graphInput, setGraphInput] = useState(() => {
    const parsed = parseBfsInput(graphStrings.nodes, graphStrings.edges, graphStrings.start);
    return { graphData: parsed.graphData, startLabel: parsed.startLabel };
  });

  useEffect(() => {
    const next = DEFAULTS_BY_ID[id] ?? {};
    setArray(next.array ?? [42, 17, 8, 31, 25]);
    setTarget(next.target ?? 31);
    setK(next.k ?? 2);
  }, [id]);

  return {
    array, setArray, target, setTarget, k, setK,
    operationInput, setOperationInput,
    stackOpsString: 'push 10, push 20, peek, pop, isEmpty',
    queueOpsString: 'enqueue 10, enqueue 20, front, dequeue, isEmpty',
    listValues, setListValues,
    position, setPosition, newValue, setNewValue,
    deleteIndex, setDeleteIndex, cycleEntry, setCycleEntry,
    stringInput, setStringInput,
    treeTokens, setTreeTokens,
    graphInput, setGraphInput, graphStrings,
    circularQueueInput, setCircularQueueInput,
    twoStacksInput, setTwoStacksInput,
  };
}

export default function Visualizer() {
  const { id } = useParams();
  const navigate = useNavigate();
  const algorithm = ALGORITHM_REGISTRY[id];
  const model = useInputModel(id);
  const player = useAlgorithmPlayer();
  const [activePanel, setActivePanel] = useState('pseudocode');
  const [language, setLanguage] = useState(algorithm?.defaultLanguage ?? 'cpp');
  const [generationError, setGenerationError] = useState('');

  const inputKey = useMemo(() => JSON.stringify({
    array: model.array,
    target: model.target,
    k: model.k,
    operationInput: model.operationInput,
    listValues: model.listValues,
    position: model.position,
    newValue: model.newValue,
    deleteIndex: model.deleteIndex,
    cycleEntry: model.cycleEntry,
    stringInput: model.stringInput,
    treeTokens: model.treeTokens,
    graphInput: model.graphInput,
    circularQueueInput: model.circularQueueInput,
    twoStacksInput: model.twoStacksInput,
  }), [
    model.array, model.target, model.k, model.operationInput,
    model.listValues, model.position, model.newValue, model.deleteIndex,
    model.cycleEntry, model.stringInput, model.treeTokens, model.graphInput,
    model.circularQueueInput, model.twoStacksInput,
  ]);

  useEffect(() => {
    if (!algorithm) return;
    try {
      const steps = generateSteps(algorithm, model);
      player.loadSteps(Array.isArray(steps) ? steps : []);
      setGenerationError('');
    } catch (error) {
      player.loadSteps([]);
      setGenerationError(error instanceof Error ? error.message : 'Unable to generate steps.');
    }
  // inputKey intentionally represents all model values used by generators.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [algorithm, inputKey]);

  useEffect(() => {
    if (!algorithm) return;
    const supported = algorithm.codeTemplates?.[language];
    if (!supported) setLanguage(algorithm.defaultLanguage ?? Object.keys(algorithm.codeTemplates ?? {})[0] ?? 'cpp');
  }, [algorithm, language]);

  if (!algorithm) {
    return (
      <main className="min-h-screen bg-background text-text-primary flex items-center justify-center px-md">
        <Card className="p-xl text-center max-w-lg">
          <h1 className="text-headline-lg">Algorithm not found</h1>
          <p className="text-text-body mt-sm">The route “{id}” is not registered.</p>
          <Button className="mt-lg" onClick={() => navigate('/algorithms')}>Back to algorithms</Button>
        </Card>
      </main>
    );
  }

  const currentStep = player.currentStep;
  const template = algorithm.codeTemplates?.[language];
  const rawCodeLine = currentStep?.codeLines?.[language] ?? currentStep?.codeLine ?? 0;
  const activeCodeLine = template?.lineMap?.[rawCodeLine] ?? rawCodeLine ?? 0;

  return (
    <main className="min-h-screen bg-background text-text-primary">
      <div className="max-w-7xl mx-auto px-md py-lg">
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-md">
          <div>
            <button onClick={() => navigate('/algorithms')} className="text-secondary hover:text-text-primary">
              ← All algorithms
            </button>
            <div className="mt-sm flex items-center gap-sm flex-wrap">
              <Badge variant={algorithm.difficulty}>{algorithm.category}</Badge>
              <span className="font-mono text-tertiary">{algorithm.subtitle}</span>
              {algorithm.technique && <span className="text-text-secondary">• {algorithm.technique}</span>}
            </div>
            <h1 className="text-headline-lg mt-sm">{algorithm.name}</h1>
            <p className="text-body-md text-text-body mt-xs max-w-3xl">{algorithm.description}</p>
          </div>
          <div className="font-mono text-code-md text-secondary shrink-0">
            Step {player.steps.length ? player.stepIndex + 1 : 0} / {player.steps.length}
          </div>
        </div>

        {generationError && (
          <div role="alert" className="mt-md rounded border border-error/40 bg-error/10 p-md text-error">
            {generationError}
          </div>
        )}

        <div className="mt-lg grid grid-cols-1 lg:grid-cols-[minmax(0,3fr)_minmax(320px,2fr)] gap-md">
          <Card className="min-h-[420px] overflow-hidden">
            <CanvasRenderer algorithm={algorithm} step={currentStep} />
          </Card>

          <Card className="min-h-[420px] overflow-hidden flex flex-col">
            <div className="grid grid-cols-4 border-b border-border">
              {[
                ['input', 'Input'],
                ['pseudocode', 'Pseudo'],
                ['code', 'Code'],
                ['complexity', 'Complexity'],
              ].map(([panel, label]) => (
                <button
                  key={panel}
                  onClick={() => setActivePanel(panel)}
                  className={[
                    'min-h-touch px-sm py-sm text-label-caps uppercase tracking-widest border-b-2',
                    activePanel === panel
                      ? 'text-primary border-primary bg-primary/5'
                      : 'text-text-secondary border-transparent hover:text-text-primary',
                  ].join(' ')}
                >
                  {label}
                </button>
              ))}
            </div>

            <div className="flex-1 min-h-0 overflow-auto">
              {activePanel === 'input' && (
                <ControlRenderer algorithm={algorithm} model={model} player={player} />
              )}
              {activePanel === 'pseudocode' && (
                <PseudocodePanel
                  lines={algorithm.pseudocodeLines ?? []}
                  activeLine={currentStep?.pseudocodeLine ?? 0}
                />
              )}
              {activePanel === 'code' && (
                <CodePanel
                  codeTemplates={algorithm.codeTemplates ?? {}}
                  activeLang={language}
                  onLangChange={setLanguage}
                  activeLine={activeCodeLine}
                />
              )}
              {activePanel === 'complexity' && (
                <ComplexityPanel
                  complexity={algorithm.complexity ?? []}
                  properties={algorithm.properties ?? []}
                />
              )}
            </div>
          </Card>
        </div>

        <PlaybackControls player={player} />
      </div>
    </main>
  );
}
