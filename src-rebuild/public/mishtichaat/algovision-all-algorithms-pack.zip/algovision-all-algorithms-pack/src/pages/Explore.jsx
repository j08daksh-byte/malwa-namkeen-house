import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ALGORITHM_LIST } from '../lib/algorithmRegistry.js';
import Card from '../components/ui/Card.jsx';
import Badge from '../components/ui/Badge.jsx';
import Button from '../components/ui/Button.jsx';

const ALL = 'All';

export default function Explore() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState(ALL);

  const categories = useMemo(
    () => [ALL, ...new Set(ALGORITHM_LIST.map((algorithm) => algorithm.category))],
    [],
  );

  const algorithms = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return ALGORITHM_LIST.filter((algorithm) => {
      const categoryMatches = category === ALL || algorithm.category === category;
      const textMatches =
        !normalized ||
        algorithm.name.toLowerCase().includes(normalized) ||
        algorithm.description.toLowerCase().includes(normalized) ||
        algorithm.technique?.toLowerCase().includes(normalized);
      return categoryMatches && textMatches && algorithm.status !== 'hidden';
    });
  }, [category, query]);

  return (
    <main className="min-h-screen bg-background text-text-primary">
      <div className="max-w-6xl mx-auto px-md py-xl">
        <h1 className="text-headline-lg">Explore Algorithms</h1>
        <p className="text-body-lg text-text-body mt-sm">
          Pick an algorithm, customize its input, and watch every step.
        </p>

        <input
          type="search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search algorithms..."
          className="mt-lg w-full min-h-touch rounded border border-border bg-code-surface px-md py-sm text-text-primary outline-none focus:border-primary"
        />

        <div className="mt-md flex gap-sm overflow-x-auto pb-xs">
          {categories.map((item) => (
            <button
              key={item}
              onClick={() => setCategory(item)}
              className={[
                'min-h-touch whitespace-nowrap rounded px-md py-sm border transition-colors',
                category === item
                  ? 'bg-primary text-background border-primary'
                  : 'bg-card text-text-body border-border hover:border-primary/40',
              ].join(' ')}
            >
              {item}
            </button>
          ))}
        </div>

        <div className="mt-xl grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-md">
          {algorithms.map((algorithm) => (
            <Card key={algorithm.id} className="p-lg flex flex-col" hoverable>
              <div className="flex items-center justify-between gap-sm">
                <Badge variant={algorithm.difficulty}>{algorithm.category}</Badge>
                <span className="font-mono text-code-md text-tertiary">{algorithm.subtitle}</span>
              </div>

              <h2 className="text-headline-sm mt-md">{algorithm.name}</h2>
              <p className="text-body-md text-text-body mt-sm flex-1">{algorithm.description}</p>

              <div className="mt-md flex flex-wrap gap-xs text-label-caps text-text-secondary uppercase tracking-widest">
                {algorithm.technique && <span>{algorithm.technique}</span>}
              </div>

              <Button className="mt-lg" onClick={() => navigate(algorithm.route ?? `/visualizer/${algorithm.id}`)}>
                Visualize
              </Button>
            </Card>
          ))}
        </div>

        {algorithms.length === 0 && (
          <p className="mt-xl text-center text-text-secondary">No matching algorithms found.</p>
        )}
      </div>
    </main>
  );
}
