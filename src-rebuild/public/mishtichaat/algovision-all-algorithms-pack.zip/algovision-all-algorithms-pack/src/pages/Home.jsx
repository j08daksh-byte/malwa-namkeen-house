import { useNavigate } from 'react-router-dom';
import Button from '../components/ui/Button.jsx';
import Card from '../components/ui/Card.jsx';

export default function Home() {
  const navigate = useNavigate();
  return (
    <main className="min-h-screen bg-background text-text-primary flex items-center">
      <div className="max-w-5xl mx-auto px-md py-xl w-full">
        <Card className="p-xl">
          <p className="text-label-caps uppercase tracking-widest text-secondary">Interactive DSA Learning</p>
          <h1 className="text-headline-lg mt-sm">AlgoVision</h1>
          <p className="text-body-lg text-text-body mt-sm max-w-2xl">
            Learn arrays, sorting, searching, linked lists, stacks, queues, trees and graphs through step-by-step visualizations.
          </p>
          <Button className="mt-lg" onClick={() => navigate('/algorithms')}>
            Explore all algorithms
          </Button>
        </Card>
      </div>
    </main>
  );
}
