import { useState, useEffect, useRef, useCallback } from 'react';

/**
 * useAlgorithmPlayer
 *
 * Manages all playback state for a step-based algorithm visualisation.
 * The timer is driven by a single useEffect — never multiple timers.
 *
 * Speed values map to delay in ms:
 *   0.25x → 1600ms
 *   0.5x  →  800ms
 *   1x    →  400ms   (default)
 *   2x    →  200ms
 *   4x    →  100ms
 */

const SPEED_DELAY = {
  0.25: 1600,
  0.5: 800,
  1: 400,
  2: 200,
  4: 100,
};

export function useAlgorithmPlayer() {
  const [steps, setSteps] = useState([]);
  const [stepIndex, setStepIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeedState] = useState(1);

  // Refs so callbacks always see current values without being re-created
  const stepsRef = useRef(steps);
  const stepIndexRef = useRef(0);
  useEffect(() => { stepsRef.current = steps; }, [steps]);
  useEffect(() => { stepIndexRef.current = stepIndex; }, [stepIndex]);

  // ── Single timer effect — drives auto-play ────────────────────────
  useEffect(() => {
    if (!isPlaying) return;
    if (stepIndex >= steps.length - 1) {
      setIsPlaying(false);
      return;
    }

    const delay = SPEED_DELAY[speed] ?? 400;
    const timer = setTimeout(() => {
      setStepIndex((prev) => {
        const next = prev + 1;
        // Stop when we reach the last step
        if (next >= stepsRef.current.length - 1) {
          setIsPlaying(false);
          return stepsRef.current.length - 1;
        }
        return next;
      });
    }, delay);

    return () => clearTimeout(timer);
  }, [isPlaying, stepIndex, steps.length, speed]);

  // ── Cleanup on unmount ────────────────────────────────────────────
  useEffect(() => {
    return () => setIsPlaying(false);
  }, []);

  // ── Derived state ─────────────────────────────────────────────────
  const isComplete = steps.length > 0 && stepIndex >= steps.length - 1;
  const currentStep = steps[stepIndex] ?? null;

  // ── Actions ───────────────────────────────────────────────────────
  const play = useCallback(() => {
    setStepIndex((prev) => {
      if (prev < stepsRef.current.length - 1) {
        setIsPlaying(true);
      }
      return prev;
    });
  }, []);

  const pause = useCallback(() => {
    setIsPlaying(false);
  }, []);

  const togglePlay = useCallback(() => {
    setIsPlaying((prev) => {
      // Don't start playing when already at the last step
      if (!prev && stepIndexRef.current >= stepsRef.current.length - 1) return false;
      return !prev;
    });
  }, []);

  const nextStep = useCallback(() => {
    setIsPlaying(false);
    setStepIndex((prev) => Math.min(prev + 1, stepsRef.current.length - 1));
  }, []);

  const previousStep = useCallback(() => {
    setIsPlaying(false);
    setStepIndex((prev) => Math.max(prev - 1, 0));
  }, []);

  const restart = useCallback(() => {
    setIsPlaying(false);
    setStepIndex(0);
  }, []);

  const skipToEnd = useCallback(() => {
    setIsPlaying(false);
    setStepIndex(stepsRef.current.length - 1);
  }, []);

  const setSpeed = useCallback((newSpeed) => {
    setSpeedState(newSpeed);
    // Speed change takes effect on the next timer tick automatically
    // because `speed` is in the effect dependency array
  }, []);

  const jumpToStep = useCallback((idx) => {
    setIsPlaying(false);
    setStepIndex(Math.max(0, Math.min(idx, stepsRef.current.length - 1)));
  }, []);

  const loadSteps = useCallback((newSteps) => {
    setIsPlaying(false);
    setSteps(newSteps);
    setStepIndex(0);
  }, []);

  return {
    // State
    steps,
    stepIndex,
    currentStep,
    isPlaying,
    speed,
    isComplete,
    // Actions
    play,
    pause,
    togglePlay,
    nextStep,
    previousStep,
    restart,
    skipToEnd,
    jumpToStep,
    setSpeed,
    loadSteps,
  };
}
