# AlgoVision — All Algorithms Pack

This pack contains a registry-driven visualizer with **32 working algorithm entries**, shared playback, input controls, pseudocode, code templates, complexity panels, and renderer components.

## Included algorithm groups

- Sorting: Bubble, Selection, Insertion
- Arrays: Reverse Array, Largest Element, Move Zeroes, Left Rotate by K, Two Sum, Kadane, Frequency Count
- Searching: Linear Search, Binary Search, Lower Bound, Upper Bound, First/Last Occurrence, Rotated Array Search
- Linked List: Traversal, Insert, Delete, Reverse, Middle, Cycle Detection
- Stack: Operations, Valid Parentheses, Next Greater Element
- Queue: Operations, Circular Queue, Queue Using Two Stacks
- Trees: Preorder Traversal
- Graphs: BFS, DFS, Undirected Cycle Detection

## Safest installation

1. Commit your current project first:

   ```powershell
   git add .
   git commit -m "chore: backup before all algorithms pack"
   ```

2. Extract this pack outside your project.
3. Copy the pack's `src` folder into your project root and allow replacement.
4. Confirm these dependencies exist:

   ```powershell
   npm install react-router-dom lucide-react
   ```

5. Run:

   ```powershell
   npm run dev
   ```

6. Open `/algorithms`.

## Important

- This pack uses the advanced named hook export:
  `import { useAlgorithmPlayer } from '../hooks/useAlgorithmPlayer.js'`.
- Replace the hook, registry, visualizer components, `App.jsx`, and pages together. Mixing these files with the earlier simplified two-algorithm version can cause prop/export mismatches.
- Keep your existing `tailwind.config.js` and `src/index.css` theme tokens. The components expect colors such as `background`, `card`, `elevated`, `primary`, `secondary`, `tertiary`, `error`, `success`, and `border`.

## Verification

After copying, run:

```powershell
npm run build
```

Then test:

- `/visualizer/bubble-sort`
- `/visualizer/binary-search`
- `/visualizer/reverse-array`
- `/visualizer/linked-list-cycle`
- `/visualizer/graph-bfs`
